package com.vrstream.client

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.vrstream.client.databinding.ActivityVrBinding
import com.vrstream.client.network.NetworkClient
import com.vrstream.client.sensor.SensorController
import com.vrstream.client.tracking.HandTrackingModule
import com.vrstream.client.ui.VrRenderer

/**
 * Actividad principal del visor VR.
 */
class VrActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "VrActivity"
        private const val PERMISSION_CAMERA = 1001
    }

    private lateinit var binding: ActivityVrBinding
    private lateinit var sensorController: SensorController
    private lateinit var handTrackingModule: HandTrackingModule
    private lateinit var networkClient: NetworkClient
    private lateinit var vrRenderer: VrRenderer

    private var isVRMode = false
    private var isConnectedToPC = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enterImmersiveMode()

        binding = ActivityVrBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Pedir permiso de cámara para Hand Tracking
        requestCameraPermission()

        // Inicializar módulos
        sensorController = SensorController(this)
        handTrackingModule = HandTrackingModule(this)
        networkClient = NetworkClient()
        vrRenderer = VrRenderer(this, binding.vrSurface)

        setupUI()
        setupCallbacks()
    }

    private fun requestCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.CAMERA), PERMISSION_CAMERA
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_CAMERA) {
            if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Hand Tracking no funcionará sin cámara", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun enterImmersiveMode() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
        }
    }

    private fun setupUI() {
        binding.btnStartVR.setOnClickListener { startVRMode() }
        binding.btnConnect.setOnClickListener { connectToPC() }
        binding.btnDisconnect.setOnClickListener { disconnectFromPC() }
        binding.btnSettings.setOnClickListener {
            startActivity(android.content.Intent(this, SettingsActivity::class.java))
        }
    }

    private fun setupCallbacks() {
        sensorController.onOrientationChanged = { quaternion ->
            if (isConnectedToPC) {
                networkClient.sendOrientation(quaternion)
            }
        }

        handTrackingModule.onHandData = { handData ->
            if (isConnectedToPC) {
                networkClient.sendHandData(handData)
            }
        }

        networkClient.onConnectionStateChanged = { connected ->
            runOnUiThread {
                isConnectedToPC = connected
                updateConnectionUI(connected)
            }
        }

        networkClient.onError = { errorMsg ->
            runOnUiThread {
                Toast.makeText(this, "Error: $errorMsg", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun startVRMode() {
        isVRMode = true
        binding.connectionOverlay.visibility = View.GONE
        vrRenderer.startSBSMode()
        sensorController.start()
        handTrackingModule.start()
        Toast.makeText(this, "Modo VR activado", Toast.LENGTH_SHORT).show()
    }

    private fun connectToPC() {
        val prefs = getSharedPreferences("vr_settings", MODE_PRIVATE)
        val ip = prefs.getString("pc_ip", "192.168.1.100") ?: "192.168.1.100"
        val port = prefs.getInt("pc_port", 9999)
        binding.connectionStatusText.text = getString(com.vrstream.client.R.string.connecting)
        networkClient.connect(ip, port)
    }

    private fun disconnectFromPC() {
        networkClient.disconnect()
    }

    private fun updateConnectionUI(connected: Boolean) {
        if (connected) {
            binding.connectionStatusText.text = getString(com.vrstream.client.R.string.connected)
            binding.connectionStatusText.setTextColor(resources.getColor(com.vrstream.client.R.color.vr_success, theme))
            binding.btnConnect.visibility = View.GONE
            binding.btnDisconnect.visibility = View.VISIBLE
        } else {
            binding.connectionStatusText.text = getString(com.vrstream.client.R.string.disconnected)
            binding.connectionStatusText.setTextColor(resources.getColor(com.vrstream.client.R.color.vr_text, theme))
            binding.btnConnect.visibility = View.VISIBLE
            binding.btnDisconnect.visibility = View.GONE
        }
    }

    override fun onResume() {
        super.onResume()
        enterImmersiveMode()
        if (isVRMode) {
            sensorController.start()
            handTrackingModule.start()
        }
    }

    override fun onPause() {
        super.onPause()
        sensorController.stop()
        handTrackingModule.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        networkClient.disconnect()
        vrRenderer.stop()
    }
}
