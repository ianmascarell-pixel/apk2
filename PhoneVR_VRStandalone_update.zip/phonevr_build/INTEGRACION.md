# Cómo integrar esto en tu proyecto PhoneVR

## 1. Copiar archivos
Copia las carpetas `app/src/main/java/com/enjoymy/mr/vr/`,
`app/src/main/java/com/enjoymy/mr/tracking/HandTrackingVR.kt` y los
layouts en `app/src/main/res/layout/` a tu proyecto real.

## 2. AndroidManifest.xml — declarar la activity
```xml
<activity
    android:name="com.enjoymy.mr.vr.VRStandaloneActivity"
    android:exported="false"
    android:screenOrientation="landscape"
    android:configChanges="orientation|screenSize|keyboardHidden" />
```

## 3. build.gradle (module :app) — dependencias necesarias
```gradle
dependencies {
    implementation "androidx.camera:camera-core:1.3.4"
    implementation "androidx.camera:camera-camera2:1.3.4"
    implementation "androidx.camera:camera-lifecycle:1.3.4"
    implementation "androidx.camera:camera-view:1.3.4"
    // MediaPipe ya lo tienes (libmediapipe_tasks_vision_jni.so + hand_landmarker.task)
}
```

## 4. Punto de integración pendiente: conectar tu HandTrackingModule
Esto es lo único que NO pude conectar a ciegas porque no tengo el código
fuente exacto de tu `HandTrackingModule.kt` original (solo vi el .dex
compilado). Necesitas, dentro del callback donde ya procesas los
resultados de MediaPipe HandLandmarker (`onResults` o similar):

```kotlin
// Por cada mano detectada en result.landmarks() / result.handednesses():
val normPoints = landmarksMediaPipe.map { PointF(it.x(), it.y()) } // 21 puntos [0,1]
val handedness = if (label == "Left") Handedness.LEFT else Handedness.RIGHT

val frame = buildHandFrame(
    handedness = handedness,
    normLandmarks = normPoints,
    viewWidthPx = previewView.width,
    viewHeightPx = previewView.height,
    mirror = true, // cámara trasera normalmente NO se espeja; cámara frontal sí
    pinchDetector = pinchDetectorFor(handedness) // guarda un PinchDetector por mano
)

vrStandaloneActivity.processHandFrames(listOf(frameIzquierda, frameDerecha))
```

Importante: crea **un `PinchDetector` por mano** (izquierda y derecha) y
reutilízalo entre frames — si creas uno nuevo cada frame pierdes la
hysteresis y el pinch parpadea.

## 5. Configurar HandLandmarker para 2 manos
Si tu `HandTrackingModule.kt` actual solo detecta 1 mano, en las
`HandLandmarkerOptions` cambia:
```kotlin
.setNumHands(2)
```

## 6. Qué hace cada pieza
- `HeadOrientationTracker`: lee el giroscopio (rotation vector), suaviza
  yaw/pitch/roll.
- `VRSpaceManager`: cada frame, calcula dónde debe aparecer cada panel
  en pantalla según cuánto has girado la cabeza desde que se creó el
  panel. Por eso los paneles "flotan fijos en el espacio" y no se pegan
  a la pantalla.
- `FloatingPanel`: un panel individual (menú, navegador, YouTube, Roblox).
- `VRHandOverlayView`: dibuja el esqueleto de mano, el rayo y el cursor
  de pinch.
- `HandTrackingVR.kt`: pinch detection (pulgar+índice) con hysteresis.
- `VRStandaloneActivity`: arma todo — passthrough de cámara, loop de
  frame (Choreographer), detección de click por pinch, arrastre de
  paneles por su barra de título.

## 7. Limitación honesta sobre Roblox
No existe forma de correr el cliente nativo de Roblox "dentro" de un
panel VR — lo que hace este código es abrir la versión web de Roblox
(roblox.com) en un WebView flotante, igual que el navegador y YouTube.
Roblox en VR nativo real solo existe en su propia app para Quest; no es
algo que se pueda replicar embebiendo su web.

## 8. Próximo paso sugerido
Cuando quieras, migramos el renderer de Canvas 2D a OpenGL real con
paneles como quads texturizados en un espacio 3D verdadero (con
profundidad real, no solo escala de posición). Esto daría más
inmersión pero es un salto de complejidad grande — dímelo cuando
quieras y lo planificamos.
