package com.enjoymy.mr.vr

import android.view.View
import kotlin.math.PI
import kotlin.math.abs

/**
 * Proyecta cada FloatingPanel (con posición fija en el "mundo") a
 * coordenadas de pantalla según la orientación actual de la cabeza.
 * Aproximación de proyección en perspectiva simple (suficiente para
 * el efecto de paneles flotantes tipo Quest, sin necesitar OpenGL).
 */
class VRSpaceManager(
    private val screenWidth: Int,
    private val screenHeight: Int,
    private val horizontalFovDeg: Float = 90f
) {
    private val panels = mutableListOf<FloatingPanel>()

    private val focalLength: Float
        get() {
            val fovRad = Math.toRadians(horizontalFovDeg.toDouble()).toFloat()
            return (screenWidth / 2f) / kotlin.math.tan(fovRad / 2f)
        }

    fun addPanel(panel: FloatingPanel) {
        panels.add(panel)
    }

    fun removePanel(panelId: String) {
        panels.find { it.id == panelId }?.let {
            (it.view.parent as? android.view.ViewGroup)?.removeView(it.view)
        }
        panels.removeAll { it.id == panelId }
    }

    fun panelAt(x: Float, y: Float): FloatingPanel? =
        panels.lastOrNull { it.contains(x, y) } // last = el que está "encima"

    fun allPanels(): List<FloatingPanel> = panels

    /** Mueve un panel para que quede anclado en la dirección actual de la cabeza */
    fun repositionPanelToHead(panel: FloatingPanel, headYaw: Float, headPitch: Float, yawOffset: Float = 0f) {
        panel.worldYaw = headYaw + yawOffset
        panel.worldPitch = headPitch
    }

    /**
     * Llamar cada frame (p.ej. desde onDraw del overlay o un Choreographer)
     * con la orientación actual de la cabeza. Actualiza translationX/Y y
     * visibilidad de cada View de panel.
     */
    fun updateFrame(headYaw: Float, headPitch: Float) {
        val f = focalLength
        val cx = screenWidth / 2f
        val cy = screenHeight / 2f
        val fovRad = Math.toRadians(horizontalFovDeg.toDouble()).toFloat()

        for (panel in panels) {
            val dYaw = HeadOrientationTracker.normalizeAngle(panel.worldYaw - headYaw)
            val dPitch = panel.worldPitch - headPitch

            val inView = abs(dYaw) < fovRad * 0.7f && abs(dPitch) < fovRad * 0.6f

            if (!inView) {
                panel.visible = false
                panel.view.visibility = View.GONE
                continue
            }

            val screenX = cx + dYaw * f
            val screenY = cy - dPitch * f

            panel.view.visibility = View.VISIBLE
            panel.view.translationX = screenX - panel.widthPx / 2f
            panel.view.translationY = screenY - panel.heightPx / 2f

            panel.screenLeft = screenX - panel.widthPx / 2f
            panel.screenTop = screenY - panel.heightPx / 2f
            panel.screenRight = screenX + panel.widthPx / 2f
            panel.screenBottom = screenY + panel.heightPx / 2f
            panel.visible = true
        }
    }
}
