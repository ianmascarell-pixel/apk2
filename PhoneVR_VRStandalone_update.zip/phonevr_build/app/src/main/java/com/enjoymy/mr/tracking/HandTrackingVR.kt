package com.enjoymy.mr.tracking

import android.graphics.PointF

/**
 * Índices de landmarks de MediaPipe Hand Landmarker que usamos.
 */
object HandLm {
    const val WRIST = 0
    const val THUMB_TIP = 4
    const val INDEX_MCP = 5
    const val INDEX_TIP = 8
    const val MIDDLE_MCP = 9
}

enum class Handedness { LEFT, RIGHT }

/**
 * Estado de una mano en un frame, ya en coordenadas de pantalla (px).
 * landmarks[i] = posición del landmark i (21 puntos, protocolo MediaPipe Hands).
 */
data class HandFrame(
    val handedness: Handedness,
    val landmarksPx: List<PointF>,
    val pinchDistanceNorm: Float, // distancia pulgar-índice normalizada por tamaño de mano
    val isPinching: Boolean,
    val pinchJustStarted: Boolean, // true solo en el frame en que empieza el pinch -> disparar click
    val rayOrigin: PointF,   // muñeca, para dibujar el rayo
    val rayTarget: PointF    // punta del índice, dirección del rayo
)

/**
 * Detecta el gesto de "pinch" (pulgar + índice casi juntos) con
 * hysteresis para evitar parpadeo del click, y expone un
 * pinchJustStarted en el frame exacto del toque.
 */
class PinchDetector {
    private var wasPinching = false

    // Umbrales normalizados (distancia pulgar-índice / distancia muñeca-nudillo medio)
    private val pinchStartThreshold = 0.35f
    private val pinchEndThreshold = 0.5f

    fun update(distanceNorm: Float): Pair<Boolean, Boolean> {
        val isPinching = if (wasPinching) {
            distanceNorm < pinchEndThreshold
        } else {
            distanceNorm < pinchStartThreshold
        }
        val justStarted = isPinching && !wasPinching
        wasPinching = isPinching
        return Pair(isPinching, justStarted)
    }
}

/**
 * Construye un HandFrame a partir de los 21 landmarks normalizados (0..1)
 * que devuelve MediaPipe HandLandmarker, convirtiéndolos a píxeles de
 * pantalla (con espejo horizontal para cámara frontal tipo "selfie").
 *
 * NOTA DE INTEGRACIÓN: este helper asume que ya tienes el resultado del
 * HandLandmarker (result.landmarks() / result.handednesses()) del
 * pipeline existente en HandTrackingModule.kt. Llama a esta función por
 * cada mano detectada, con normX/normY en [0,1] tal como los entrega
 * MediaPipe, y con el ancho/alto real de tu PreviewView en píxeles.
 */
fun buildHandFrame(
    handedness: Handedness,
    normLandmarks: List<PointF>, // 21 puntos en [0,1]
    viewWidthPx: Int,
    viewHeightPx: Int,
    mirror: Boolean,
    pinchDetector: PinchDetector
): HandFrame {
    val px = normLandmarks.map { p ->
        val x = if (mirror) (1f - p.x) * viewWidthPx else p.x * viewWidthPx
        val y = p.y * viewHeightPx
        PointF(x, y)
    }

    val thumb = px[HandLm.THUMB_TIP]
    val index = px[HandLm.INDEX_TIP]
    val wrist = px[HandLm.WRIST]
    val middleMcp = px[HandLm.MIDDLE_MCP]

    val handSize = dist(wrist, middleMcp).coerceAtLeast(1f)
    val pinchDist = dist(thumb, index) / handSize

    val (isPinching, justStarted) = pinchDetector.update(pinchDist)

    return HandFrame(
        handedness = handedness,
        landmarksPx = px,
        pinchDistanceNorm = pinchDist,
        isPinching = isPinching,
        pinchJustStarted = justStarted,
        rayOrigin = wrist,
        rayTarget = index
    )
}

private fun dist(a: PointF, b: PointF): Float {
    val dx = a.x - b.x
    val dy = a.y - b.y
    return kotlin.math.sqrt(dx * dx + dy * dy)
}
