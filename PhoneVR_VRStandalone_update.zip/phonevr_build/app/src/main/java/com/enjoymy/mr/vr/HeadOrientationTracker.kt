package com.enjoymy.mr.vr

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager

/**
 * Lee el giroscopio/rotation vector del teléfono y expone yaw/pitch/roll
 * suavizados. Esto es lo que permite que los paneles flotantes se queden
 * "anclados" en el espacio en vez de pegados a la pantalla: cada panel
 * guarda su propio yaw/pitch de creación, y en cada frame calculamos
 * dónde debería aparecer en pantalla según hacia dónde mira ahora el
 * teléfono.
 */
class HeadOrientationTracker(context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

    private val rotationMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)

    // Ángulos suavizados en radianes
    var yaw: Float = 0f
        private set
    var pitch: Float = 0f
        private set
    var roll: Float = 0f
        private set

    private val smoothing = 0.25f // más bajo = más suave, más lag

    fun start() {
        rotationSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return

        SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
        SensorManager.getOrientation(rotationMatrix, orientationAngles)

        val newYaw = orientationAngles[0]   // azimuth
        val newPitch = orientationAngles[1] // pitch
        val newRoll = orientationAngles[2]  // roll

        yaw = lerpAngle(yaw, newYaw, smoothing)
        pitch = pitch + (newPitch - pitch) * smoothing
        roll = roll + (newRoll - roll) * smoothing
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    /** Interpola ángulos manejando correctamente el "wrap" en +-PI */
    private fun lerpAngle(from: Float, to: Float, t: Float): Float {
        var diff = to - from
        while (diff > Math.PI) diff -= (2 * Math.PI).toFloat()
        while (diff < -Math.PI) diff += (2 * Math.PI).toFloat()
        return from + diff * t
    }

    companion object {
        /** Normaliza una diferencia de ángulo al rango [-PI, PI] */
        fun normalizeAngle(angle: Float): Float {
            var a = angle
            while (a > Math.PI) a -= (2 * Math.PI).toFloat()
            while (a < -Math.PI) a += (2 * Math.PI).toFloat()
            return a
        }
    }
}
