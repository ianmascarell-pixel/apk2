package com.enjoymy.mr.vr

import android.graphics.PointF
import android.os.Bundle
import android.view.Choreographer
import android.view.LayoutInflater
import android.view.MotionEvent
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import com.enjoymy.mr.R
import com.enjoymy.mr.tracking.HandFrame
import com.enjoymy.mr.tracking.Handedness
import java.util.UUID

/**
 * Vista "VR standalone" tipo EnjoyMR / Meta Quest Home:
 *  - Passthrough de cámara de fondo.
 *  - Menú flotante anclado al espacio (giroscopio) con Navegador / YouTube / Roblox.
 *  - Hand tracking de 2 manos con esqueleto, rayo y click por pinch (pulgar+índice).
 *  - Los paneles se pueden agarrar por su barra de título y mover; quedan
 *    anclados en el espacio, no pegados a la pantalla.
 */
class VRStandaloneActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var panelContainer: FrameLayout
    private lateinit var handOverlay: VRHandOverlayView

    private lateinit var headTracker: HeadOrientationTracker
    private lateinit var spaceManager: VRSpaceManager

    private var menuPanel: FloatingPanel? = null
    private val choreographer = Choreographer.getInstance()

    // Estado de "agarre" por mano (para arrastrar paneles)
    private data class DragState(var panelId: String, var grabScreenPoint: PointF)
    private val dragByHand = mutableMapOf<Handedness, DragState>()

    // Últimos frames de manos recibidos del pipeline de tracking.
    // processHandFrames(...) debe llamarse desde tu callback existente
    // de MediaPipe (ver nota de integración más abajo).
    private var latestHandFrames: List<HandFrame> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vr_standalone)

        previewView = findViewById(R.id.cameraPreview)
        panelContainer = findViewById(R.id.panelContainer)
        handOverlay = findViewById(R.id.handOverlay)

        headTracker = HeadOrientationTracker(this)

        panelContainer.post {
            spaceManager = VRSpaceManager(panelContainer.width, panelContainer.height)
            spawnMenuBar()
            startFrameLoop()
        }

        startCameraPassthrough()
    }

    override fun onResume() {
        super.onResume()
        headTracker.start()
    }

    override fun onPause() {
        super.onPause()
        headTracker.stop()
    }

    private fun startCameraPassthrough() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            val selector = CameraSelector.DEFAULT_BACK_CAMERA
            cameraProvider.unbindAll()
            cameraProvider.bindToLifecycle(this, selector, preview)

            // NOTA DE INTEGRACIÓN: aquí es donde tu HandTrackingModule
            // existente debería engancharse (ImageAnalysis use case) para
            // recibir cada frame, correrlo por MediaPipe HandLandmarker
            // (numHands = 2) y llamar a processHandFrames(...) de esta
            // Activity con los HandFrame ya construidos via buildHandFrame().
        }, androidx.core.content.ContextCompat.getMainExecutor(this))
    }

    /** Llamar desde el pipeline de MediaPipe con las manos detectadas en el frame actual */
    fun processHandFrames(frames: List<HandFrame>) {
        latestHandFrames = frames
    }

    private fun startFrameLoop() {
        choreographer.postFrameCallback(object : Choreographer.FrameCallback {
            override fun doFrame(frameTimeNanos: Long) {
                spaceManager.updateFrame(headTracker.yaw, headTracker.pitch)
                handOverlay.updateHands(latestHandFrames)
                handleHandInteractions(latestHandFrames)
                choreographer.postFrameCallback(this)
            }
        })
    }

    // ---------------------------------------------------------------
    // Interacción: pinch-click y arrastre de paneles
    // ---------------------------------------------------------------

    private fun handleHandInteractions(frames: List<HandFrame>) {
        for (hand in frames) {
            val cursor = handOverlay.cursorFor(hand)

            val drag = dragByHand[hand.handedness]
            if (drag != null) {
                if (hand.isPinching) {
                    // seguir arrastrando: convertir delta de pantalla a delta de yaw/pitch
                    followDrag(drag, cursor)
                } else {
                    dragByHand.remove(hand.handedness) // soltó el pinch
                }
                continue
            }

            if (hand.pinchJustStarted) {
                val panel = spaceManager.panelAt(cursor.x, cursor.y) ?: continue

                if (isOnTitleBar(panel, cursor)) {
                    dragByHand[hand.handedness] = DragState(panel.id, cursor)
                } else {
                    onPanelClicked(panel, cursor)
                }
            }
        }
    }

    private fun isOnTitleBar(panel: FloatingPanel, point: PointF): Boolean {
        val titleBarHeightPx = 40 * resources.displayMetrics.density
        return point.y <= panel.screenTop + titleBarHeightPx
    }

    private fun followDrag(drag: DragState, cursor: PointF) {
        val panel = spaceManager.allPanels().find { it.id == drag.panelId } ?: return
        val dxPx = cursor.x - drag.grabScreenPoint.x
        val dyPx = cursor.y - drag.grabScreenPoint.y

        // Convertimos el desplazamiento en píxeles a un desplazamiento angular
        val pxPerRadian = (panelContainer.width / 2f) /
            kotlin.math.tan(Math.toRadians(45.0)).toFloat() // aprox focal, mismo criterio que VRSpaceManager
        panel.worldYaw = HeadOrientationTracker.normalizeAngle(panel.worldYaw + dxPx / pxPerRadian)
        panel.worldPitch -= dyPx / pxPerRadian

        drag.grabScreenPoint = cursor
    }

    private fun onPanelClicked(panel: FloatingPanel, point: PointF) {
        when (panel.type) {
            PanelType.MENU_BAR -> handleMenuBarClick(panel, point)
            else -> { /* clicks dentro del WebView los maneja el propio WebView vía touch simulado, ver nota abajo */ }
        }
    }

    private fun handleMenuBarClick(panel: FloatingPanel, point: PointF) {
        val local = point.y - panel.screenTop
        val root = panel.view as? android.view.ViewGroup ?: return

        val browserBtn = root.findViewById<TextView>(R.id.btnBrowser)
        val youtubeBtn = root.findViewById<TextView>(R.id.btnYoutube)
        val robloxBtn = root.findViewById<TextView>(R.id.btnRoblox)

        if (hitsView(browserBtn, point)) openWebPanel(PanelType.BROWSER, "https://www.google.com")
        else if (hitsView(youtubeBtn, point)) openWebPanel(PanelType.YOUTUBE, "https://m.youtube.com")
        else if (hitsView(robloxBtn, point)) openWebPanel(PanelType.ROBLOX, "https://www.roblox.com")
    }

    private fun hitsView(view: android.view.View, screenPoint: PointF): Boolean {
        val loc = IntArray(2)
        view.getLocationOnScreen(loc)
        return screenPoint.x >= loc[0] && screenPoint.x <= loc[0] + view.width &&
            screenPoint.y >= loc[1] && screenPoint.y <= loc[1] + view.height
    }

    // ---------------------------------------------------------------
    // Creación de paneles
    // ---------------------------------------------------------------

    private fun spawnMenuBar() {
        val menuView = LayoutInflater.from(this).inflate(R.layout.view_floating_menu, panelContainer, false)
        panelContainer.addView(menuView)

        val panel = FloatingPanel(
            id = "menu_bar",
            type = PanelType.MENU_BAR,
            worldYaw = headTracker.yaw,
            worldPitch = headTracker.pitch - 0.15f, // ligeramente abajo, como Quest
            view = menuView,
            widthPx = 330,
            heightPx = 70
        )
        spaceManager.addPanel(panel)
        menuPanel = panel
    }

    private fun openWebPanel(type: PanelType, url: String) {
        val panelView = LayoutInflater.from(this)
            .inflate(R.layout.view_floating_panel, panelContainer, false)
        panelContainer.addView(panelView)

        val title = panelView.findViewById<TextView>(R.id.panelTitle)
        title.text = when (type) {
            PanelType.BROWSER -> "Navegador"
            PanelType.YOUTUBE -> "YouTube"
            PanelType.ROBLOX -> "Roblox"
            else -> "Panel"
        }

        val contentContainer = panelView.findViewById<FrameLayout>(R.id.panelContentContainer)
        val webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            loadUrl(url)
        }
        contentContainer.addView(webView)

        val panelId = UUID.randomUUID().toString()
        panelView.findViewById<TextView>(R.id.panelClose).setOnClickListener {
            spaceManager.removePanel(panelId)
        }

        // Ancla el nuevo panel un poco a la derecha de donde estás mirando ahora
        val panel = FloatingPanel(
            id = panelId,
            type = type,
            worldYaw = headTracker.yaw + 0.3f,
            worldPitch = headTracker.pitch,
            view = panelView,
            widthPx = 720,
            heightPx = 520,
            url = url
        )
        spaceManager.addPanel(panel)
    }
}
