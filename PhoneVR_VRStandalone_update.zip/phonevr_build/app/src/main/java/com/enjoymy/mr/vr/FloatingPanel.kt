package com.enjoymy.mr.vr

import android.view.View

enum class PanelType { MENU_BAR, BROWSER, YOUTUBE, ROBLOX, CUSTOM }

/**
 * Un panel flotante anclado en el espacio (no en la pantalla).
 * worldYaw / worldPitch = el ángulo de cabeza en el momento en que el
 * panel fue creado o movido. En cada frame se recalcula su posición en
 * pantalla comparando estos ángulos contra la orientación actual de la
 * cabeza (HeadOrientationTracker), así que si giras la cabeza el panel
 * se queda "quieto" en el mundo, igual que en Quest / EnjoyMR.
 */
data class FloatingPanel(
    val id: String,
    val type: PanelType,
    var worldYaw: Float,
    var worldPitch: Float,
    var view: View,
    var widthPx: Int,
    var heightPx: Int,
    var url: String? = null
) {
    // Rect en pantalla calculado cada frame (para hit-test del pinch)
    var screenLeft = 0f
    var screenTop = 0f
    var screenRight = 0f
    var screenBottom = 0f
    var visible = false

    fun contains(x: Float, y: Float): Boolean =
        visible && x in screenLeft..screenRight && y in screenTop..screenBottom
}
