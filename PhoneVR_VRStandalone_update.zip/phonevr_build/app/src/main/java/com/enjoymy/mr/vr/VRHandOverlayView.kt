package com.enjoymy.mr.vr

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.util.AttributeSet
import android.view.View
import com.enjoymy.mr.tracking.HandFrame
import com.enjoymy.mr.tracking.HandLm

/**
 * Dibuja el esqueleto de cada mano detectada con un efecto de
 * profundidad (líneas más gruesas/brillantes cerca de la cámara),
 * un rayo tipo "puntero láser" que sale de la muñeca hacia la punta
 * del índice y se extiende hasta el borde de la pantalla, y un
 * cursor que se ilumina cuando hay pinch.
 */
class VRHandOverlayView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    // Pares de landmarks que forman el "esqueleto" de la mano (MediaPipe Hands)
    private val bones = listOf(
        0 to 1, 1 to 2, 2 to 3, 3 to 4,       // pulgar
        0 to 5, 5 to 6, 6 to 7, 7 to 8,       // índice
        5 to 9, 9 to 10, 10 to 11, 11 to 12,  // medio
        9 to 13, 13 to 14, 14 to 15, 15 to 16,// anular
        13 to 17, 17 to 18, 18 to 19, 19 to 20, // meñique
        0 to 17                                // palma
    )

    private val bonePaint = Paint().apply {
        color = Color.parseColor("#66E0FF")
        strokeWidth = 5f
        style = Paint.Style.STROKE
        isAntiAlias = true
    }

    private val jointPaint = Paint().apply {
        color = Color.WHITE
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val rayPaint = Paint().apply {
        color = Color.parseColor("#88FFFFFF")
        strokeWidth = 3f
        style = Paint.Style.STROKE
        isAntiAlias = true
    }

    private val pinchIdlePaint = Paint().apply {
        color = Color.parseColor("#AAFFFFFF")
        style = Paint.Style.STROKE
        strokeWidth = 4f
        isAntiAlias = true
    }

    private val pinchActivePaint = Paint().apply {
        color = Color.parseColor("#FF4C6EF5")
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private var frames: List<HandFrame> = emptyList()

    fun updateHands(newFrames: List<HandFrame>) {
        frames = newFrames
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        for (hand in frames) {
            drawSkeleton(canvas, hand)
            drawRay(canvas, hand)
            drawPinchCursor(canvas, hand)
        }
    }

    private fun drawSkeleton(canvas: Canvas, hand: HandFrame) {
        val pts = hand.landmarksPx
        for ((a, b) in bones) {
            canvas.drawLine(pts[a].x, pts[a].y, pts[b].x, pts[b].y, bonePaint)
        }
        for (p in pts) {
            canvas.drawCircle(p.x, p.y, 6f, jointPaint)
        }
    }

    private fun drawRay(canvas: Canvas, hand: HandFrame) {
        val origin = hand.rayOrigin
        val target = hand.rayTarget

        val dx = target.x - origin.x
        val dy = target.y - origin.y
        val len = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
        val dirX = dx / len
        val dirY = dy / len

        // Extendemos el rayo bastante más allá de la punta del dedo
        val extendedX = target.x + dirX * 2000f
        val extendedY = target.y + dirY * 2000f

        canvas.drawLine(target.x, target.y, extendedX, extendedY, rayPaint)
    }

    private fun drawPinchCursor(canvas: Canvas, hand: HandFrame) {
        val cursorPoint = midpoint(hand.landmarksPx[HandLm.THUMB_TIP], hand.landmarksPx[HandLm.INDEX_TIP])
        if (hand.isPinching) {
            canvas.drawCircle(cursorPoint.x, cursorPoint.y, 14f, pinchActivePaint)
        } else {
            canvas.drawCircle(cursorPoint.x, cursorPoint.y, 12f, pinchIdlePaint)
        }
    }

    private fun midpoint(a: PointF, b: PointF) = PointF((a.x + b.x) / 2f, (a.y + b.y) / 2f)

    /** Punto de "cursor" de una mano, útil para hacer hit-test contra paneles */
    fun cursorFor(hand: HandFrame): PointF =
        midpoint(hand.landmarksPx[HandLm.THUMB_TIP], hand.landmarksPx[HandLm.INDEX_TIP])
}
