# NovaMR — launcher espacial para Cardboard (WebXR-lite · Three.js + MediaPipe)

Entorno 360° · manos wireframe cian · pinch para seleccionar/arrastrar · ventanas flotantes · dock · selector de escenarios.

## Por qué Three.js y no Unity
| | Three.js + MediaPipe Tasks (este proyecto) | Unity + Cardboard XR + MediaPipe Unity Plugin |
|---|---|---|
| Iterar | recarga en segundos, se prueba desde el móvil | build de Unity en cada cambio |
| APK | Capacitor (WebView) → APK en ~5 min en CI | necesitas Unity Editor + módulo Android |
| Rendimiento | suficiente para paneles + skybox; hand tracking en GPU (WASM/WebGL) | mejor techo (IL2CPP, Vulkan), pero el plugin de MediaPipe es más frágil |
| Ventanas de apps *reales* | ✗ (una WebView no puede capturar otras apps) | ✗ tampoco: requiere código nativo Android (ver Roadmap) |

Para un launcher de paneles 2D en el espacio, la web gana. Si más adelante necesitas espejar apps reales, el salto es a nativo Android (Kotlin/Java) con VirtualDisplay + MediaProjection/Shizuku, no a Unity.

## Estructura
```
novamr/
├─ index.html                 pantalla de inicio + <canvas>
├─ capacitor.config.json      empaquetado Android
├─ vite.config.js             bundler (+ HTTPS local para cámara/sensores)
├─ scripts/fetch-assets.mjs   copia WASM + descarga modelo hand_landmarker (offline)
├─ .github/workflows/build-apk.yml   CI: genera app-debug.apk
├─ public/skyboxes/           (opcional) tus 360° + manifest.json
└─ src/
   ├─ main.js            bucle principal, arranque, orquestación
   ├─ stereoRig.js       giroscopio + render split-screen (StereoCamera)
   ├─ handTracker.js     cámara trasera + MediaPipe HandLandmarker
   ├─ handModel.js       landmarks → esqueleto 3D wireframe, pinch, rayo; GazePointer (respaldo)
   ├─ panel.js           panel 3D con textura canvas + regiones/botones
   ├─ spatialUI.js       raycast, hover, click, arrastrar, scroll, resize, 2 manos (escala+roll)
   ├─ windowManager.js   abrir/enfocar/cerrar ventanas flotantes
   ├─ panels.js          NovaView (launcher), Dock, Escenarios, Ajustes
   ├─ apps.js            catálogo demo de apps
   └─ environments.js    skyboxes 360° procedurales + fundido + nieve/lluvia
```

## Probar en el móvil (sin APK)
```bash
npm install
npm run fetch-assets     # opcional en dev; si falla usa CDN
npm run dev              # abre https://TU_IP:5173 en Chrome del móvil (acepta el certificado)
```
Horizontal → **Entrar en VR** → permisos de cámara y movimiento → al visor.
PC: `?mono` en la URL = vista simple; arrastra con el ratón para mirar; **Espacio** = pinch.

## Generar el APK
**Opción A — GitHub Actions (sin instalar nada):**
1. Sube la carpeta a un repo de GitHub (rama `main`).
2. Pestaña **Actions → Build APK → Run workflow**.
3. Descarga el artefacto **NovaMR-apk** → `app-debug.apk` → instálalo (permite "orígenes desconocidos").

**Opción B — local (Android Studio + JDK 17):**
```bash
npm install && npm run fetch-assets && npm run build
npx cap add android
# parchea AndroidManifest.xml como en el workflow (CAMERA, sensorLandscape, fullscreen)
npx cap sync android && cd android && ./gradlew assembleDebug
```

## Controles
| Gesto | Acción |
|---|---|
| Apuntar con el dedo (rayo ojo→dedo) | cursor sobre el panel |
| Pellizco (pulgar+índice) sobre botón | clic |
| Pellizco sobre zona vacía / barra de título / barra inferior | mover panel |
| Pellizco y arrastrar en la rejilla | scroll |
| Pellizco en la esquina ◢ | redimensionar |
| **Dos manos** pellizcando la misma ventana | escalar + rotar |
| Sin cámara: mirar + tocar pantalla | puntero de respaldo |

## Ajuste fino
- `handModel.js` → `CAM_VFOV` (FOV de tu cámara trasera), umbrales de pinch `0.32 / 0.5`, `REF_SIZE`.
- `stereoRig.js` → `camera.fov`, `focus`, y la IPD en Ajustes. Para lentes con mucha distorsión, añade un pase de corrección de barril (shader post-proceso).
- Rendimiento: `setPixelRatio(1)` en `main.js`; baja `numHands` a 1 en `handTracker.js`.
- Escenarios propios: imágenes equirectangulares 2:1 en `public/skyboxes/` + `manifest.json`.

## Limitaciones honestas
- Las ventanas/apps son **simuladas** (demo). Una WebView no puede mostrar otras apps.
- El hand tracking usa la cámara trasera monocular: la profundidad se estima por tamaño de la mano (aprox.).
- La inferencia comparte hilo con el render; en móviles modestos verás ~20–30 FPS.

## Roadmap hacia apps reales
Servicio nativo Android (Kotlin) que cree un `VirtualDisplay`, lance apps en él (Shizuku/ADB) y envíe frames por `SurfaceTexture`/WebRTC local a la WebView, mapeados a las texturas de `Panel`. `WindowManager.open(app)` ya es el punto de enganche.
