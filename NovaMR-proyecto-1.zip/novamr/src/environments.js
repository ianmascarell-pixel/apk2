// ─────────────────────────────────────────────────────────────
// EnvironmentManager: skyboxes equirectangulares 360° con fundido cruzado.
// Los escenarios base se pintan por código (sin descargar nada). Para añadir tus propios 360°
// coloca imágenes en /public/skyboxes/ y lista en /public/skyboxes/manifest.json:
//   [{ "id":"mi-playa", "name":"Mi playa", "file":"playa.jpg" }]
// ─────────────────────────────────────────────────────────────
import * as THREE from 'three';

function rng(seed) { // PRNG determinista (mulberry32) → mismos escenarios siempre y costuras limpias
  return () => { seed |= 0; seed = (seed + 0x6D2B79F5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
const lin = (ctx, y0, y1, stops) => { const g = ctx.createLinearGradient(0, y0, 0, y1); stops.forEach(([o, c]) => g.addColorStop(o, c)); return g; };

function paintCity(ctx, W, H, snow) {
  const R = rng(snow ? 7 : 11), hz = H * 0.5;
  ctx.fillStyle = lin(ctx, 0, hz, snow ? [[0, '#232b38'], [1, '#8a909a']] : [[0, '#0d1118'], [1, '#48505e']]); ctx.fillRect(0, 0, W, hz);
  ctx.fillStyle = lin(ctx, hz, H, [[0, snow ? '#454a53' : '#262a31'], [1, '#0b0c0f']]); ctx.fillRect(0, hz, W, H - hz);
  const layers = [[70, 120, 330, 24], [55, 170, 430, 16], [40, 220, 540, 9]]; // [n, altura mín, máx, luminosidad %]
  for (const [n, hMin, hMax, lum] of layers) {
    for (let i = 0; i < n; i++) {
      const b = { x: (i / n) * W + R() * 30, w: (W / n) * (0.9 + R() * 1.1), h: hMin + R() * (hMax - hMin), seed: (R() * 1e9) | 0, l: lum + R() * 5 };
      for (const dx of [0, -W]) { // dibujar también desplazado → el 360° cierra sin costura
        const x = b.x + dx; if (x > W || x + b.w < 0) continue;
        ctx.fillStyle = `hsl(215,12%,${b.l}%)`; ctx.fillRect(x, hz - b.h, b.w, b.h + 6);
        const r = rng(b.seed);
        for (let wy = hz - b.h + 16; wy < hz - 12; wy += 17) for (let wx = x + 7; wx < x + b.w - 9; wx += 13)
          if (r() < 0.26) { ctx.fillStyle = `rgba(255,${185 + r() * 55 | 0},115,${0.35 + r() * 0.55})`; ctx.fillRect(wx, wy, 6, 9); }
      }
    }
  }
  ctx.fillStyle = lin(ctx, hz - 70, hz + 50, [[0, 'rgba(190,195,205,0)'], [0.5, snow ? 'rgba(190,195,205,.4)' : 'rgba(120,130,150,.25)'], [1, 'rgba(190,195,205,0)']]); ctx.fillRect(0, hz - 70, W, 120);
  for (let i = 0; i < 26; i++) { // semáforos / farolas con brillo
    const x = R() * W, y = hz + 14 + R() * 60, red = R() < 0.6, g = ctx.createRadialGradient(x, y, 0, x, y, 34);
    g.addColorStop(0, red ? 'rgba(255,50,40,.95)' : 'rgba(255,190,90,.9)'); g.addColorStop(1, 'rgba(255,50,40,0)');
    ctx.fillStyle = g; ctx.fillRect(x - 40, y - 40, 80, 80);
    ctx.fillStyle = red ? 'rgba(255,40,30,.18)' : 'rgba(255,190,90,.14)'; ctx.fillRect(x - 3, y, 6, 150 + R() * 200); // reflejo en el asfalto mojado
  }
  ctx.fillStyle = snow ? 'rgba(255,255,255,.55)' : 'rgba(150,170,200,.25)';
  for (let i = 0; i < (snow ? 5000 : 2500); i++) { const y = hz + Math.pow(R(), 1.6) * (H - hz); ctx.fillRect(R() * W, y, 1 + R() * 2, 1 + R() * 2); }
}

function paintIsland(ctx, W, H) {
  const R = rng(3), hz = H * 0.5, sx = W * 0.3;
  ctx.fillStyle = lin(ctx, 0, hz, [[0, '#1c4f8f'], [0.6, '#f0a46a'], [1, '#ffd9a0']]); ctx.fillRect(0, 0, W, hz);
  let g = ctx.createRadialGradient(sx, hz - 70, 0, sx, hz - 70, 280); g.addColorStop(0, 'rgba(255,245,210,1)'); g.addColorStop(0.15, 'rgba(255,220,150,.9)'); g.addColorStop(1, 'rgba(255,190,110,0)');
  ctx.fillStyle = g; ctx.fillRect(sx - 300, hz - 370, 600, 400);
  for (let i = 0; i < 26; i++) { ctx.fillStyle = 'rgba(255,215,195,.3)'; ctx.beginPath(); ctx.ellipse(R() * W, 70 + R() * (hz - 190), 90 + R() * 150, 12 + R() * 14, 0, 0, 7); ctx.fill(); }
  ctx.fillStyle = lin(ctx, hz, H * 0.66, [[0, '#2fb6c9'], [1, '#0b5f7d']]); ctx.fillRect(0, hz, W, H * 0.16);
  for (let i = 0; i < 600; i++) { ctx.fillStyle = 'rgba(255,255,255,.16)'; ctx.fillRect(R() * W, hz + R() * H * 0.16, 20 + R() * 70, 2); }
  ctx.fillStyle = 'rgba(255,215,150,.35)'; ctx.fillRect(sx - 40, hz, 80, H * 0.16);
  ctx.fillStyle = lin(ctx, H * 0.66, H, [[0, '#f2dfb0'], [1, '#b99a63']]); ctx.fillRect(0, H * 0.66, W, H * 0.34);
  ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 6; ctx.beginPath();
  for (let x = 0; x <= W; x += 8) ctx.lineTo(x, H * 0.66 + Math.sin((x / W) * Math.PI * 24) * 5); ctx.stroke();
  for (let i = 0; i < 8; i++) { // palmeras
    const x = (i / 8) * W + R() * 60, y = H * 0.74, lean = (R() - 0.5) * 120, top = [x + lean, y - 240 - R() * 60];
    ctx.strokeStyle = '#5a3d22'; ctx.lineWidth = 14; ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x + lean * 0.2, y - 130, top[0], top[1]); ctx.stroke();
    ctx.strokeStyle = '#1f6b3a'; ctx.lineWidth = 9;
    for (let f = 0; f < 8; f++) { const a = (f / 8) * Math.PI * 2, L = 150 + R() * 70; ctx.beginPath(); ctx.moveTo(top[0], top[1]);
      ctx.quadraticCurveTo(top[0] + Math.cos(a) * L * 0.6, top[1] - 50 + Math.sin(a) * 20, top[0] + Math.cos(a) * L, top[1] + 40 + Math.abs(Math.sin(a)) * 50); ctx.stroke(); }
  }
}

function paintOffice(ctx, W, H) {
  const ceil = H * 0.39, floor = H * 0.62, R = rng(5);
  ctx.fillStyle = '#f5f6f8'; ctx.fillRect(0, 0, W, ceil);
  ctx.fillStyle = '#ffffff'; for (let x = 0; x < W; x += W / 12) ctx.fillRect(x + 20, ceil * 0.5, W / 12 - 60, 26); // paneles de luz
  ctx.fillStyle = '#d7dbe2'; ctx.fillRect(0, ceil, W, floor - ceil);
  for (let i = 0; i < 4; i++) { // ventanales con skyline
    const x = (i / 4) * W + W * 0.045, w = W * 0.16, y = ceil + 14, h = floor - ceil - 28;
    ctx.fillStyle = lin(ctx, y, y + h, [[0, '#8ec5ff'], [1, '#e2f1ff']]); ctx.fillRect(x, y, w, h);
    ctx.fillStyle = '#5b6b82'; for (let b = 0; b < 9; b++) ctx.fillRect(x + b * (w / 9), y + h - 30 - R() * 70, w / 9 - 3, 200);
    ctx.strokeStyle = '#9aa3b2'; ctx.lineWidth = 8; ctx.strokeRect(x, y, w, h); ctx.beginPath(); ctx.moveTo(x + w / 2, y); ctx.lineTo(x + w / 2, y + h); ctx.stroke();
  }
  ctx.fillStyle = lin(ctx, floor, H, [[0, '#9a7550'], [1, '#5a4029']]); ctx.fillRect(0, floor, W, H - floor);
  ctx.strokeStyle = 'rgba(0,0,0,.22)'; ctx.lineWidth = 2;
  for (let x = 0; x < W; x += W / 64) { ctx.beginPath(); ctx.moveTo(x, floor); ctx.lineTo(x, H); ctx.stroke(); }
  for (let y = floor; y < H; y += 46) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }
}

function paintSpace(ctx, W, H) {
  const R = rng(9);
  ctx.fillStyle = '#03040a'; ctx.fillRect(0, 0, W, H);
  for (const [c, n] of [['rgba(120,60,200,.35)', 6], ['rgba(40,120,220,.28)', 6]]) for (let i = 0; i < n; i++) {
    const x = R() * W, y = H * (0.2 + R() * 0.6), r = 160 + R() * 260, g = ctx.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, c); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = g; ctx.fillRect(x - r, y - r, r * 2, r * 2); }
  for (let i = 0; i < 3000; i++) { const a = 0.3 + R() * 0.7; ctx.fillStyle = `rgba(255,255,255,${a})`; const s = R() < 0.05 ? 3 : 1.5; ctx.fillRect(R() * W, R() * H, s, s); }
  const px = W * 0.65, py = H * 0.4, g = ctx.createRadialGradient(px - 50, py - 50, 20, px, py, 200); g.addColorStop(0, '#6fb0ff'); g.addColorStop(1, '#0b1b3a');
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(px, py, 190, 0, 7); ctx.fill(); ctx.strokeStyle = 'rgba(120,190,255,.5)'; ctx.lineWidth = 8; ctx.stroke();
}

const BUILTIN = [
  { id: 'city-snow', name: 'Ciudad nevada', paint: (c, w, h) => paintCity(c, w, h, true), fx: 'snow' },
  { id: 'city-rain', name: 'Ciudad lluviosa', paint: (c, w, h) => paintCity(c, w, h, false), fx: 'rain' },
  { id: 'island', name: 'Isla tropical', paint: paintIsland, fx: null },
  { id: 'office', name: 'Oficina virtual', paint: paintOffice, fx: null },
  { id: 'space', name: 'Espacio', paint: paintSpace, fx: null },
];

export class EnvironmentManager {
  constructor(scene, camera) {
    this.scene = scene; this.list = BUILTIN.map((e) => ({ ...e })); this.current = null; this.sphere = null; this.fading = [];
    this.onChange = () => {}; this.t = 0;
    // partículas (nieve / lluvia) que siguen la cabeza
    const N = 700; this.N = N;
    this.snow = new THREE.Points(new THREE.BufferGeometry().setAttribute('position', new THREE.BufferAttribute(new Float32Array(N * 3), 3)),
      new THREE.PointsMaterial({ color: 0xffffff, size: 0.035, transparent: true, opacity: 0.85, depthWrite: false, depthTest: false }));
    this.rain = new THREE.LineSegments(new THREE.BufferGeometry().setAttribute('position', new THREE.BufferAttribute(new Float32Array(N * 6), 3)),
      new THREE.LineBasicMaterial({ color: 0x9db4d6, transparent: true, opacity: 0.35, depthWrite: false, depthTest: false }));
    for (const o of [this.snow, this.rain]) { o.renderOrder = -5; o.frustumCulled = false; o.visible = false; scene.add(o);
      const a = o.geometry.attributes.position; const k = o === this.snow ? 3 : 6;
      for (let i = 0; i < N; i++) { const x = (Math.random() - 0.5) * 10, y = Math.random() * 7 - 3, z = (Math.random() - 0.5) * 10;
        a.setXYZ(i * (k / 3), x, y, z); if (k === 6) a.setXYZ(i * 2 + 1, x, y + 0.4, z + 0.02); } }
    this.cam = camera;
    this._loadManifest();
  }

  async _loadManifest() {
    try {
      const r = await fetch(import.meta.env.BASE_URL + 'skyboxes/manifest.json');
      if (!r.ok || !(r.headers.get('content-type') || '').includes('json')) return;
      for (const it of await r.json()) {
        const img = new Image(); img.onload = () => { entry.canvas = img; this.onChange(); };
        const entry = { id: it.id, name: it.name, custom: true, canvas: null, fx: it.fx || null }; img.src = import.meta.env.BASE_URL + 'skyboxes/' + it.file;
        this.list.push(entry);
      }
      this.onChange();
    } catch { /* sin manifest: solo escenarios base */ }
  }

  ensure(e) { // pinta el canvas equirectangular (2048×1024) la primera vez
    if (!e.canvas && e.paint) { const c = document.createElement('canvas'); c.width = 2048; c.height = 1024; e.paint(c.getContext('2d'), 2048, 1024); e.canvas = c; }
    return e.canvas;
  }
  /** Genera el resto de escenarios en segundo plano para las miniaturas del selector. */
  warmup() { this.list.filter((e) => !e.canvas && e.paint).forEach((e, i) => setTimeout(() => { this.ensure(e); this.onChange(); }, 300 * (i + 1))); }

  set(id) {
    const e = this.list.find((x) => x.id === id); if (!e || e === this.current) return;
    const src = this.ensure(e); if (!src) return;
    const tex = new THREE.CanvasTexture(src); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 4;
    const mat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0, depthWrite: false, depthTest: false, toneMapped: false });
    const geo = new THREE.SphereGeometry(60, 64, 40); geo.scale(-1, 1, 1); // invertir para verlo desde dentro
    const m = new THREE.Mesh(geo, mat); m.renderOrder = -10; this.scene.add(m);
    if (this.sphere) { this.sphere.renderOrder = -11; this.fading.push(this.sphere); } // el anterior queda detrás y se elimina al terminar
    this.sphere = m; this.current = e; this.fadeIn = 0;
    this.snow.visible = e.fx === 'snow'; this.rain.visible = e.fx === 'rain';
    this.onChange();
  }

  update(dt) {
    this.t += dt;
    if (this.sphere && this.fadeIn < 1) {
      this.fadeIn = Math.min(1, this.fadeIn + dt / 0.9); this.sphere.material.opacity = this.fadeIn;
      if (this.fadeIn >= 1) { for (const o of this.fading) { this.scene.remove(o); o.material.map.dispose(); o.material.dispose(); o.geometry.dispose(); } this.fading.length = 0; }
    }
    const camPos = this.cam.getWorldPosition(new THREE.Vector3());
    this.snow.position.copy(camPos); this.rain.position.copy(camPos);
    if (this.snow.visible) { const a = this.snow.geometry.attributes.position;
      for (let i = 0; i < this.N; i++) { let y = a.getY(i) - dt * 0.6; if (y < -3) y += 7; a.setY(i, y); a.setX(i, a.getX(i) + Math.sin(this.t + i) * dt * 0.08); } a.needsUpdate = true; }
    if (this.rain.visible) { const a = this.rain.geometry.attributes.position;
      for (let i = 0; i < this.N; i++) { let y = a.getY(i * 2) - dt * 9; if (y < -3) y += 7; a.setY(i * 2, y); a.setY(i * 2 + 1, y + 0.4); } a.needsUpdate = true; }
  }
}
