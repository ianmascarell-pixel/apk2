// ─────────────────────────────────────────────────────────────
// NovaMR — punto de entrada. Orquesta rig VR, manos, UI espacial y entornos.
// ─────────────────────────────────────────────────────────────
import * as THREE from 'three';
import { StereoRig } from './stereoRig.js';
import { HandTracker } from './handTracker.js';
import { HandModel, GazePointer, assignHands } from './handModel.js';
import { SpatialUI } from './spatialUI.js';
import { EnvironmentManager } from './environments.js';
import { WindowManager } from './windowManager.js';
import { buildPanels } from './panels.js';

const canvas = document.getElementById('c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5)); // menos píxeles = más FPS en móvil
const resize = () => renderer.setSize(innerWidth, innerHeight, false);
addEventListener('resize', resize); resize();

const scene = new THREE.Scene();
const rig = new StereoRig(renderer, scene);
rig.split = !new URLSearchParams(location.search).has('mono'); // ?mono → una sola vista (depuración en PC)

const ui = new SpatialUI(scene, rig.camera);
const env = new EnvironmentManager(scene, rig.camera);
const wm = new WindowManager(ui);
const tracker = new HandTracker();
const hands = [new HandModel(rig.camera, 'hand0'), new HandModel(rig.camera, 'hand1')];
const gaze = new GazePointer(rig.camera);
const settings = { showHands: true };
const state = { handOk: false, handStatus: 'Seguimiento de manos: sin iniciar' };
const A = { ui, rig, env, wm, settings, state };
const panels = buildPanels(A);
const setStatus = (t, ok = false) => { state.handStatus = t; state.handOk = ok; panels.launcher.invalidate(); };

env.onChange = () => { panels.scenes.invalidate(); };
env.set('city-snow');
env.warmup();

// Colocación inicial (delante del usuario)
ui.placeInFront(panels.launcher, { dist: 2.2, y: 0.25 });
ui.placeInFront(panels.dock, { dist: 1.9, y: -0.85 });
panels.dock.mesh.rotateX(-0.35); // el dock se inclina hacia arriba, hacia tus ojos

// ── Bucle principal ──
const clock = new THREE.Clock();
renderer.setAnimationLoop((now) => {
  const dt = Math.min(clock.getDelta(), 0.1);
  rig.update();
  tracker.update(now);
  const assigned = assignHands(tracker.hands, hands);
  hands.forEach((h, i) => h.update(assigned[i], tracker.aspect, dt, settings.showHands));
  const active = hands.filter((h) => h.visible);
  gaze.update();
  // Con manos visibles se usan como punteros; si no, la mirada (toque de pantalla = pellizco)
  ui.update(active.length ? active : [gaze], dt, now);
  env.update(dt);
  rig.render();
});

// ── Arranque (requiere gesto del usuario) ──
document.getElementById('go').onclick = async () => {
  const msg = document.getElementById('msg'), start = document.getElementById('start');
  msg.textContent = 'Solicitando permisos…';
  try { await rig.enableGyro(); } catch (e) { console.warn('Giroscopio:', e); }
  try { await document.documentElement.requestFullscreen?.({ navigationUI: 'hide' }); await screen.orientation?.lock?.('landscape'); } catch { /* opcional */ }
  try { await navigator.wakeLock?.request('screen'); } catch { /* opcional */ }
  start.style.display = 'none';
  rig.recenter();
  setStatus('Cargando seguimiento de manos…');
  tracker.start()
    .then(() => setStatus('Manos activas — pellizca para seleccionar', true))
    .catch((e) => { console.warn('Hand tracking:', e); setStatus('Sin cámara: toca la pantalla para seleccionar'); });
};
