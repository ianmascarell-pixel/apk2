// ─────────────────────────────────────────────────────────────
// HandTracker: cámara trasera + MediaPipe HandLandmarker (tasks-vision, WASM/GPU)
// Devuelve, por frame, hasta 2 manos con 21 landmarks normalizados (x,y ∈ [0,1], z relativa).
// ─────────────────────────────────────────────────────────────
import { FilesetResolver, HandLandmarker } from '@mediapipe/tasks-vision';

const CDN_WASM = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm';
const CDN_MODEL = 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';

async function exists(url) {
  try {
    const r = await fetch(url, { method: 'HEAD' });
    return r.ok && !(r.headers.get('content-type') || '').includes('text/html'); // el dev server devuelve index.html si falta
  } catch { return false; }
}

export class HandTracker {
  constructor() {
    this.video = document.createElement('video');
    this.video.setAttribute('playsinline', ''); this.video.muted = true;
    this.ready = false; this.hands = []; this.aspect = 4 / 3; this._lastT = -1;
  }

  async start() {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: { ideal: 'environment' }, width: { ideal: 640 }, height: { ideal: 480 }, frameRate: { ideal: 30 } },
      audio: false,
    });
    this.video.srcObject = stream;
    await this.video.play();

    const base = import.meta.env.BASE_URL;
    const localWasm = base + 'mediapipe/wasm', localModel = base + 'models/hand_landmarker.task';
    const local = (await exists(localModel)) && (await exists(localWasm + '/vision_wasm_internal.wasm'));
    const fileset = await FilesetResolver.forVisionTasks(local ? localWasm : CDN_WASM);
    const opts = (delegate) => ({
      baseOptions: { modelAssetPath: local ? localModel : CDN_MODEL, delegate },
      runningMode: 'VIDEO', numHands: 2,
      minHandDetectionConfidence: 0.5, minHandPresenceConfidence: 0.5, minTrackingConfidence: 0.5,
    });
    try { this.lm = await HandLandmarker.createFromOptions(fileset, opts('GPU')); }
    catch { this.lm = await HandLandmarker.createFromOptions(fileset, opts('CPU')); }
    this.ready = true;
  }

  /** Llamar cada frame. Solo infiere cuando hay un frame de vídeo nuevo. */
  update(now) {
    if (!this.ready || this.video.readyState < 2) return;
    if (this.video.currentTime === this._lastT) return;
    this._lastT = this.video.currentTime;
    this.aspect = this.video.videoWidth / this.video.videoHeight;
    this.hands = this.lm.detectForVideo(this.video, now).landmarks || [];
  }
}
