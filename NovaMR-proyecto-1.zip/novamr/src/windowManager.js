// ─────────────────────────────────────────────────────────────
// WindowManager: abrir / enfocar / cerrar ventanas flotantes.
// Mover = pellizcar barra de título (o cualquier zona vacía) · Redimensionar = esquina inferior derecha
// Escalar + rotar = pellizcar con las DOS manos la misma ventana.
// ─────────────────────────────────────────────────────────────
import { Panel, rr } from './panel.js';
import { drawAppIcon } from './apps.js';

const BAR = 56;

export class WindowManager {
  constructor(ui) { this.ui = ui; this.wins = new Map(); this.n = 0; }

  open(app) {
    const ex = this.wins.get(app.id);
    if (ex) { this.ui.bringToFront(ex); ex.show(); return ex; }
    const p = new Panel({
      name: 'win:' + app.id, w: 1.7, h: 1.05, ppm: 640, fps: app.kind === 'player' ? 8 : 0,
      draw: (ctx, pn) => drawWindow(ctx, pn, app, () => this.close(app.id)),
    });
    this.ui.add(p);
    const k = this.n++ % 5;
    this.ui.placeInFront(p, { dist: 2.4, y: 0.2, yaw: (k - 2) * 0.22 }); // cascada horizontal
    p.pop = 0; this.wins.set(app.id, p);
    return p;
  }

  close(id) { const p = this.wins.get(id); if (p) { this.ui.remove(p); this.wins.delete(id); } }
}

function drawWindow(ctx, p, app, close) {
  const W = p.canvas.width, H = p.canvas.height, t = performance.now() / 1000;
  rr(ctx, 0, 0, W, H, 30); ctx.fillStyle = '#1b1c21'; ctx.fill();
  ctx.save(); rr(ctx, 0, 0, W, H, 30); ctx.clip();
  ctx.fillStyle = '#121317'; ctx.fillRect(0, 0, W, BAR);
  drawAppIcon(ctx, app, 14, 10, 36);
  ctx.fillStyle = '#e8eaf0'; ctx.font = '600 24px system-ui,sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
  ctx.fillText(app.name, 62, BAR / 2 + 1);
  p.region('title', 0, 0, W - 80, BAR, { kind: 'drag' });
  p.btn('close', W - 66, 8, 48, 40, {
    onClick: close, fill: '#2a2c33', hover: '#e5484d', r: 12,
    draw: (c, x, y, w, h) => { c.strokeStyle = '#fff'; c.lineWidth = 3; c.beginPath(); c.moveTo(x + 15, y + 12); c.lineTo(x + w - 15, y + h - 12); c.moveTo(x + w - 15, y + 12); c.lineTo(x + 15, y + h - 12); c.stroke(); },
  });
  ctx.save(); ctx.translate(0, BAR); ctx.beginPath(); ctx.rect(0, 0, W, H - BAR); ctx.clip();
  ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  ({ chat: drawChat, browser: drawBrowser, player: drawPlayer }[app.kind] || drawGeneric)(ctx, W, H - BAR, app, t);
  ctx.restore();
  // esquina de redimensionado
  ctx.strokeStyle = '#8a90a0'; ctx.lineWidth = 3;
  for (const o of [14, 26, 38]) { ctx.beginPath(); ctx.moveTo(W - 8, H - o); ctx.lineTo(W - o, H - 8); ctx.stroke(); }
  p.region('resize', W - 60, H - 60, 60, 60, { kind: 'resize' });
  ctx.restore();
  // barra de agarre inferior (como en NovaView)
  ctx.fillStyle = p.hoverId === 'grab' ? '#22d3ee' : 'rgba(255,255,255,.55)';
  rr(ctx, W / 2 - 90, H - 14, 180, 6, 3); ctx.fill();
  p.region('grab', W / 2 - 140, H - 30, 280, 30, { kind: 'drag' });
}

function drawChat(ctx, W, H, app, t) {
  ctx.fillStyle = '#1e1f24'; ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = '#151619'; ctx.fillRect(0, 0, 78, H);
  for (let i = 0; i < 6; i++) { ctx.fillStyle = i === 0 ? app.color : '#2b2d33'; ctx.beginPath(); ctx.arc(39, 44 + i * 70, 24, 0, 7); ctx.fill(); }
  ctx.fillStyle = '#17181c'; ctx.fillRect(78, 0, 230, H);
  ctx.fillStyle = '#9aa0ad'; ctx.font = '600 18px system-ui'; ctx.fillText('CANALES', 98, 34);
  ['# general', '# proyectos', '# vr-dev', '# memes', '# música'].forEach((c, i) => { ctx.fillStyle = i === 2 ? '#fff' : '#8b91a0'; ctx.font = '22px system-ui'; ctx.fillText(c, 98, 78 + i * 44); });
  const msgs = [['Lía', '#f59e0b', 'Ya probé el launcher en el visor'], ['Ian', '#22d3ee', 'Se ve genial, falta pulir el pinch'], ['Nico', '#a78bfa', 'La mano cian quedó buenísima'], ['Lía', '#f59e0b', '¿Subes el APK al canal?'], ['Ian', '#22d3ee', 'En un rato lo comparto']];
  msgs.forEach(([n, c, m], i) => {
    const y = 40 + i * 92;
    ctx.fillStyle = c; ctx.beginPath(); ctx.arc(350, y + 22, 24, 0, 7); ctx.fill();
    ctx.fillStyle = c; ctx.font = '700 22px system-ui'; ctx.fillText(n, 392, y + 12);
    ctx.fillStyle = '#d6d9e0'; ctx.font = '22px system-ui'; ctx.fillText(m, 392, y + 46);
  });
  rr(ctx, 336, H - 76, W - 366, 52, 14); ctx.fillStyle = '#2a2c33'; ctx.fill();
  ctx.fillStyle = '#7d8493'; ctx.font = '22px system-ui'; ctx.fillText('Mensaje en #vr-dev' + (Math.floor(t * 2) % 2 ? '|' : ''), 356, H - 50);
}

function drawBrowser(ctx, W, H) {
  ctx.fillStyle = '#f4f5f7'; ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = '#e4e6ea'; ctx.fillRect(0, 0, W, 64);
  rr(ctx, 90, 12, W - 240, 40, 20); ctx.fillStyle = '#fff'; ctx.fill();
  ctx.fillStyle = '#5b6170'; ctx.font = '22px system-ui'; ctx.fillText('https://novamr.dev/inicio', 116, 40);
  ctx.fillStyle = '#2f6df6'; ctx.fillRect(0, 64, W, 200);
  ctx.fillStyle = '#fff'; ctx.font = '700 44px system-ui'; ctx.fillText('Bienvenido a NovaMR', 60, 140);
  ctx.font = '24px system-ui'; ctx.fillText('Tu navegador flotante en realidad mixta', 60, 190);
  for (let i = 0; i < 3; i++) { rr(ctx, 60 + i * ((W - 120) / 3), 300, (W - 120) / 3 - 24, 220, 18); ctx.fillStyle = '#fff'; ctx.fill(); ctx.fillStyle = '#c9ceda'; ctx.fillRect(84 + i * ((W - 120) / 3), 330, 140, 14); ctx.fillRect(84 + i * ((W - 120) / 3), 360, 200, 10); }
}

function drawPlayer(ctx, W, H, app, t) {
  const g = ctx.createLinearGradient(0, 0, W, H);
  g.addColorStop(0, '#0f172a'); g.addColorStop(1, app.color); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  for (let i = 0; i < 28; i++) { // ecualizador animado
    const h = 40 + Math.abs(Math.sin(t * 2.2 + i * 0.7)) * 160 * (0.5 + 0.5 * Math.sin(i * 1.3));
    ctx.fillStyle = 'rgba(255,255,255,.25)'; ctx.fillRect(60 + i * ((W - 120) / 28), H - 150 - h, (W - 120) / 28 - 8, h);
  }
  ctx.fillStyle = 'rgba(255,255,255,.9)'; ctx.beginPath(); ctx.moveTo(W / 2 - 34, H / 2 - 60); ctx.lineTo(W / 2 + 46, H / 2 - 16); ctx.lineTo(W / 2 - 34, H / 2 + 28); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,.25)'; ctx.fillRect(50, H - 60, W - 100, 8);
  ctx.fillStyle = '#fff'; ctx.fillRect(50, H - 60, (W - 100) * ((t / 60) % 1), 8);
}

function drawGeneric(ctx, W, H, app) {
  ctx.fillStyle = '#1e1f24'; ctx.fillRect(0, 0, W, H);
  drawAppIcon(ctx, app, W / 2 - 70, H / 2 - 130, 140);
  ctx.fillStyle = '#e8eaf0'; ctx.font = '700 36px system-ui'; ctx.textAlign = 'center'; ctx.fillText(app.name, W / 2, H / 2 + 60);
  ctx.fillStyle = '#8b91a0'; ctx.font = '22px system-ui'; ctx.fillText('Ventana de demostración', W / 2, H / 2 + 100);
}
