// ─────────────────────────────────────────────────────────────
// SpatialUI: raycasting desde "punteros" (manos o mirada) hacia paneles 3D.
//  · hover / click con pinch
//  · arrastrar paneles (mantén el pinch sobre cualquier zona no interactiva)
//  · scroll (arrastrar en la rejilla), redimensionar (esquina)
//  · dos manos sobre el mismo panel → escala + rotación (roll)
// Un puntero es: { id, visible, down, origin:Vector3, dir:Vector3, tip?:Vector3 }
// ─────────────────────────────────────────────────────────────
import * as THREE from 'three';

const _n = new THREE.Vector3(), _v = new THREE.Vector3(), _v2 = new THREE.Vector3(), _plane = new THREE.Plane();

export class SpatialUI {
  constructor(scene, camera) {
    this.scene = scene; this.camera = camera;
    this.panels = []; this.states = new Map(); this.z = 0;
    this.rc = new THREE.Raycaster(); this.rc.far = 40;
    this.camPos = new THREE.Vector3();
  }

  add(p) { this.scene.add(p.mesh); this.panels.push(p); this.bringToFront(p); return p; }
  remove(p) {
    const i = this.panels.indexOf(p); if (i >= 0) this.panels.splice(i, 1);
    this.scene.remove(p.mesh); p.tex.dispose(); p.mesh.geometry.dispose();
    for (const s of this.states.values()) { if (s.grab?.panel === p) s.grab = null; if (s.pending?.panel === p) s.pending = null; }
  }
  bringToFront(p) { p.mesh.renderOrder = 10 + ++this.z; }

  /** Coloca un panel delante de la mirada actual (yaw = rotación extra en radianes). */
  placeInFront(p, { dist = 2.2, y = 0, yaw = 0 } = {}) {
    this.camera.getWorldPosition(this.camPos);
    this.camera.getWorldDirection(_v);
    const a = Math.atan2(_v.x, _v.z) + yaw;
    p.mesh.position.set(this.camPos.x + Math.sin(a) * dist, this.camPos.y + y, this.camPos.z + Math.cos(a) * dist);
    p.faceUser(this.camPos);
  }

  _state(id) {
    let s = this.states.get(id); if (s) return s;
    const mat = () => new THREE.MeshBasicMaterial({ color: 0x22e5ff, depthTest: false, depthWrite: false, transparent: true, opacity: 0.95, side: THREE.DoubleSide });
    const cursor = new THREE.Group();
    const ring = new THREE.Mesh(new THREE.RingGeometry(0.7, 1, 32), mat());
    const dot = new THREE.Mesh(new THREE.CircleGeometry(0.4, 24), mat());
    ring.renderOrder = dot.renderOrder = 900;
    cursor.add(ring, dot);
    const line = new THREE.Line(
      new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]),
      new THREE.LineBasicMaterial({ color: 0x22e5ff, transparent: true, opacity: 0.55, depthTest: false }));
    line.renderOrder = 899; line.frustumCulled = false;
    this.scene.add(cursor, line);
    s = { cursor, dot, line, prevDown: false, grab: null, pending: null, hoverPanel: null, o: new THREE.Vector3(), d: new THREE.Vector3() };
    this.states.set(id, s); return s;
  }

  update(pointers, dt, now) {
    this.camera.getWorldPosition(this.camPos);
    const seen = new Set();
    for (const p of pointers) { seen.add(p.id); this._pointer(p, this._state(p.id)); }
    for (const [id, s] of this.states) {
      if (seen.has(id)) continue;
      s.grab = null; s.pending = null; s.prevDown = false; s.cursor.visible = false; s.line.visible = false;
    }
    this._twoHand();
    for (const pl of this.panels) pl.update(dt, now);
  }

  _planePoint(panel, ray, out) {
    _plane.setFromNormalAndCoplanarPoint(panel.mesh.getWorldDirection(_n), panel.mesh.position);
    return ray.intersectPlane(_plane, out);
  }
  _planePx(panel, ray) {
    const pt = this._planePoint(panel, ray, _v2); if (!pt) return null;
    return panel.localToPx(panel.mesh.worldToLocal(pt));
  }

  _pointer(p, s) {
    const down = p.down, pressed = down && !s.prevDown, released = !down && s.prevDown;
    s.prevDown = down; s.o.copy(p.origin); s.d.copy(p.dir);
    this.rc.set(p.origin, p.dir);
    const ray = this.rc.ray;
    let hit = null, panel = null, region = null;

    if (!s.grab) {
      const hits = this.rc.intersectObjects(this.panels.filter((x) => x.mesh.visible).map((x) => x.mesh), false);
      hits.sort((a, b) => b.object.renderOrder - a.object.renderOrder || a.distance - b.distance);
      hit = hits[0] || null;
      if (hit) { panel = hit.object.userData.panel; const px = panel.uvToPx(hit.uv); region = panel.regionAt(px.x, px.y); }
      if (s.hoverPanel && s.hoverPanel !== panel && s.hoverPanel.hoverId !== null) { s.hoverPanel.hoverId = null; s.hoverPanel.dirty = true; }
      const hid = region ? region.id : null;
      if (panel && panel.hoverId !== hid) { panel.hoverId = hid; panel.dirty = true; }
      s.hoverPanel = panel;
    }

    if (pressed && hit) {
      this.bringToFront(panel);
      const kind = region ? region.kind : panel.movable ? 'drag' : 'none';
      if (kind === 'button') { s.pending = { panel, region, start: this._planePx(panel, ray) }; panel.pressedId = region.id; panel.dirty = true; }
      else if (kind === 'drag' && panel.movable) s.grab = { mode: 'drag', panel, dist: hit.distance, offset: panel.mesh.position.clone().sub(hit.point) };
      else if (kind === 'scroll') { const pp = this._planePx(panel, ray); s.grab = { mode: 'scroll', panel, region, last: pp ? pp.y : 0 }; }
      else if (kind === 'resize') s.grab = { mode: 'resize', panel, d0: Math.max(0.05, hit.point.distanceTo(panel.mesh.position)), s0: panel.userScale };
    }

    if (down) {
      // un botón dentro de una zona scrolleable se convierte en scroll si arrastras
      if (s.pending?.region.scrollTo) {
        const pp = this._planePx(s.pending.panel, ray), st = s.pending.start;
        if (pp && st && Math.abs(pp.y - st.y) > 22) {
          const sr = s.pending.panel.regions.find((r) => r.id === s.pending.region.scrollTo);
          if (sr) { s.grab = { mode: 'scroll', panel: s.pending.panel, region: sr, last: pp.y }; s.pending.panel.pressedId = null; s.pending.panel.dirty = true; s.pending = null; }
        }
      }
      if (s.grab) this._grab(s, ray);
    }

    if (released) {
      if (s.pending) {
        const pd = s.pending; s.pending = null;
        pd.panel.pressedId = null; pd.panel.dirty = true;
        if (hit && panel === pd.panel && region && region.id === pd.region.id) pd.region.onClick?.();
      }
      s.grab = null;
    }

    // ── cursor y rayo visibles ──
    const target = s.grab ? s.grab.panel : panel;
    let point = null;
    if (target && target.mesh.visible) point = this._planePoint(target, ray, new THREE.Vector3());
    if (point) {
      const dist = point.distanceTo(ray.origin);
      s.cursor.visible = true;
      s.cursor.position.copy(point).addScaledVector(_n, 0.004);
      s.cursor.quaternion.copy(target.mesh.quaternion);
      s.cursor.scale.setScalar(0.012 * dist * (down ? 0.85 : 1));
      s.dot.visible = down;
      s.line.visible = !!p.tip;
      if (p.tip) {
        const a = s.line.geometry.attributes.position;
        a.setXYZ(0, p.tip.x, p.tip.y, p.tip.z); a.setXYZ(1, point.x, point.y, point.z); a.needsUpdate = true;
      }
    } else { s.cursor.visible = false; s.line.visible = false; }
  }

  _partner(s) {
    for (const o of this.states.values())
      if (o !== s && o.grab && o.grab.mode === 'drag' && o.grab.panel === s.grab.panel && o.prevDown) return o;
    return null;
  }

  _grab(s, ray) {
    const g = s.grab, pl = g.panel;
    if (g.mode === 'drag') {
      if (this._partner(s)) return; // lo gestiona _twoHand
      _v.copy(ray.origin).addScaledVector(ray.direction, g.dist).add(g.offset);
      pl.mesh.position.copy(_v); pl.faceUser(this.camPos);
    } else if (g.mode === 'scroll') {
      const pp = this._planePx(pl, ray);
      if (pp) { g.region.onScroll?.(-(pp.y - g.last)); g.last = pp.y; }
    } else if (g.mode === 'resize') {
      const pt = this._planePoint(pl, ray, _v2);
      if (pt) pl.userScale = THREE.MathUtils.clamp(g.s0 * pt.distanceTo(pl.mesh.position) / g.d0, 0.5, 2.5);
    }
  }

  _twoHand() {
    const gs = [...this.states.values()].filter((s) => s.grab && s.grab.mode === 'drag' && s.prevDown);
    const pointOf = (s) => s.o.clone().addScaledVector(s.d, s.grab.dist);
    if (gs.length !== 2 || gs[0].grab.panel !== gs[1].grab.panel) {
      for (const s of gs) if (s.grab.two) { s.grab.two = null; s.grab.offset.copy(s.grab.panel.mesh.position).sub(pointOf(s)); }
      return;
    }
    const pl = gs[0].grab.panel, g = gs[0].grab;
    const wa = pointOf(gs[0]), wb = pointOf(gs[1]);
    const a = this.camera.worldToLocal(wa.clone()), b = this.camera.worldToLocal(wb.clone());
    const dist = a.distanceTo(b), ang = Math.atan2(b.y - a.y, b.x - a.x);
    if (!g.two) g.two = { d0: Math.max(0.05, dist), a0: ang, s0: pl.userScale, r0: pl.roll };
    pl.userScale = THREE.MathUtils.clamp(g.two.s0 * dist / g.two.d0, 0.5, 2.5);
    const da = ang - g.two.a0; pl.roll = g.two.r0 + Math.atan2(Math.sin(da), Math.cos(da));
    // centro entre ambas manos + media de los offsets de agarre
    pl.mesh.position.copy(wa).add(wb).multiplyScalar(0.5).addScaledVector(gs[0].grab.offset.clone().add(gs[1].grab.offset), 0.5);
    gs[1].grab.two = g.two;
    pl.faceUser(this.camPos);
  }
}
