// ─────────────────────────────────────────────────────────────
// HandModel: convierte los landmarks de la imagen a un esqueleto 3D wireframe cian
// (hijo de la cámara), suaviza, detecta el pellizco y expone un puntero (rayo).
// ─────────────────────────────────────────────────────────────
import * as THREE from 'three';

const BONES = [[0,1],[1,2],[2,3],[3,4],[0,5],[5,6],[6,7],[7,8],[5,9],[9,10],[10,11],[11,12],
  [9,13],[13,14],[14,15],[15,16],[13,17],[17,18],[18,19],[19,20],[0,17]];
const TIPS = [4, 8, 12, 16, 20];
const CAM_VFOV = THREE.MathUtils.degToRad(50); // FOV vertical aprox. de la cámara trasera de un móvil (4:3)
const REF_SIZE = 0.2, REF_DEPTH = 0.5;         // una mano a 0.5 m mide ≈0.2 de la altura de la imagen (muñeca→nudillo medio)
const CYAN = new THREE.Color(0x19e6ff), WHITE = new THREE.Color(0xffffff);
const UP = new THREE.Vector3(0, 1, 0), _q = new THREE.Quaternion(), _m = new THREE.Matrix4();
const _a = new THREE.Vector3(), _b = new THREE.Vector3(), _s = new THREE.Vector3(), _id = new THREE.Quaternion();

export class HandModel {
  constructor(camera, id) {
    this.camera = camera; this.id = id;
    this.pts = Array.from({ length: 21 }, () => new THREE.Vector3());
    this.tgt = Array.from({ length: 21 }, () => new THREE.Vector3());
    this.visible = false; this.down = false; this.lost = 0; this.img = { x: 0.5, y: 0.5 };
    // puntero
    this.origin = new THREE.Vector3(); this.dir = new THREE.Vector3(0, 0, -1); this.tip = new THREE.Vector3();

    this.group = new THREE.Group(); this.group.visible = false; camera.add(this.group);
    const mat = () => new THREE.MeshBasicMaterial({ color: CYAN, wireframe: true, depthTest: false, transparent: true, opacity: 0.95 });
    this.mats = [mat(), mat(), mat()];
    // huesos: cilindros de 4 caras en wireframe → malla 3D
    this.bones = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.0032, 0.0032, 1, 4, 1, true), this.mats[0], BONES.length);
    this.joints = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(0.0065, 0), this.mats[1], 21);
    this.bones.instanceMatrix.setUsage(THREE.DynamicDrawUsage); this.joints.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    // palma: abanico de triángulos
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(4 * 9), 3));
    this.palm = new THREE.Mesh(g, this.mats[2]); this.palm.material.opacity = 0.45;
    for (const o of [this.bones, this.joints, this.palm]) { o.frustumCulled = false; o.renderOrder = 1000; this.group.add(o); }
  }

  /** det: array de 21 landmarks o null. */
  update(det, aspect, dt, showMesh) {
    if (det) {
      this.lost = 0;
      const w = det[0], m = det[9];
      const size = Math.hypot((w.x - m.x) * aspect, w.y - m.y);
      const d = THREE.MathUtils.clamp(REF_DEPTH * REF_SIZE / Math.max(size, 0.03), 0.3, 1.0); // profundidad ≈ tamaño aparente
      const halfH = d * Math.tan(CAM_VFOV / 2), halfW = halfH * aspect;
      det.forEach((l, i) => this.tgt[i].set((l.x - 0.5) * 2 * halfW, -(l.y - 0.5) * 2 * halfH, -d - l.z * 2 * halfW));
      const speed = this.pts[0].distanceTo(this.tgt[0]);
      const a = this.visible ? Math.min(0.9, 0.35 + speed * 20) : 1; // suavizado adaptativo (anti-jitter)
      for (let i = 0; i < 21; i++) this.pts[i].lerp(this.tgt[i], a);
      this.img.x = w.x; this.img.y = w.y; this.visible = true;
    } else if ((this.lost += dt) > 0.25) this.visible = false;

    this.group.visible = this.visible && showMesh;
    if (!this.visible) { this.down = false; return; }

    // ── pellizco con histéresis: distancia pulgar–índice relativa al tamaño de la mano ──
    const P = this.pts, hs = P[0].distanceTo(P[9]) || 1, pd = P[4].distanceTo(P[8]) / hs;
    if (!this.down && pd < 0.32) this.down = true; else if (this.down && pd > 0.5) this.down = false;

    // ── rayo: desde el ojo, pasando por el punto de pellizco (estable, estilo Vision Pro) ──
    this.camera.getWorldPosition(this.origin);
    _a.copy(P[4]).add(P[8]).multiplyScalar(0.5);
    this.dir.copy(_a).normalize().transformDirection(this.camera.matrixWorld);
    this.tip.copy(P[8]); this.camera.localToWorld(this.tip);

    // ── malla ──
    BONES.forEach(([i, j], k) => {
      _a.copy(P[i]); _b.copy(P[j]);
      const len = _a.distanceTo(_b) || 1e-4;
      _q.setFromUnitVectors(UP, _b.sub(_a).multiplyScalar(1 / len));
      _m.compose(_a.addScaledVector(_b, len * 0.5), _q, _s.set(1, len, 1));
      this.bones.setMatrixAt(k, _m);
    });
    P.forEach((p, i) => { _m.compose(p, _id, _s.setScalar(TIPS.includes(i) ? 1.5 : 1)); this.joints.setMatrixAt(i, _m); });
    this.bones.instanceMatrix.needsUpdate = this.joints.instanceMatrix.needsUpdate = true;
    const pa = this.palm.geometry.attributes.position, fan = [[0,1,5],[0,5,9],[0,9,13],[0,13,17]];
    fan.forEach((t, k) => t.forEach((idx, v) => pa.setXYZ(k * 3 + v, P[idx].x, P[idx].y, P[idx].z)));
    pa.needsUpdate = true;
    const c = this.down ? WHITE : CYAN;
    this.mats.forEach((mt) => mt.color.copy(c));
  }
}

/** Asigna detecciones a los 2 modelos manteniendo continuidad (vecino más cercano en la imagen). */
export function assignHands(dets, models) {
  const out = [null, null], free = dets.map((_, i) => i);
  for (const mi of [0, 1]) { // 1) las manos ya visibles reclaman su detección más cercana
    if (!models[mi].visible) continue;
    let best = -1, bd = 0.35;
    for (const di of free) {
      const d = Math.hypot(dets[di][0].x - models[mi].img.x, dets[di][0].y - models[mi].img.y);
      if (d < bd) { bd = d; best = di; }
    }
    if (best >= 0) { out[mi] = dets[best]; free.splice(free.indexOf(best), 1); }
  }
  for (const mi of [0, 1]) if (!out[mi] && free.length) out[mi] = dets[free.shift()]; // 2) el resto, a huecos libres
  return out;
}

/** Puntero de respaldo (sin manos): la mirada al centro; pellizco = tocar la pantalla o barra espaciadora. */
export class GazePointer {
  constructor(camera) {
    this.id = 'gaze'; this.camera = camera; this.visible = true; this.down = false;
    this.origin = new THREE.Vector3(); this.dir = new THREE.Vector3(); this.tip = null;
    addEventListener('touchstart', () => (this.down = true), { passive: true });
    addEventListener('touchend', () => (this.down = false), { passive: true });
    addEventListener('keydown', (e) => e.code === 'Space' && (this.down = true));
    addEventListener('keyup', (e) => e.code === 'Space' && (this.down = false));
  }
  update() { this.camera.getWorldPosition(this.origin); this.camera.getWorldDirection(this.dir); }
}
