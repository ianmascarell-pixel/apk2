// Catálogo DEMO de apps (iconos = letra sobre color; sin logos de marca).
// En una versión nativa, esta lista vendría de PackageManager (apps instaladas).
import { rr } from './panel.js';

export const CATS = ['Todos', 'Social', 'Media', 'Juegos', 'Sistema'];

export const APPS = [
  { id: 'discord', name: 'Discord', cat: 'Social', kind: 'chat', color: '#5865f2', glyph: 'D' },
  { id: 'whatsapp', name: 'WhatsApp', cat: 'Social', kind: 'chat', color: '#25d366', glyph: 'W' },
  { id: 'telegram', name: 'Telegram', cat: 'Social', kind: 'chat', color: '#2aabee', glyph: 'T' },
  { id: 'instagram', name: 'Instagram', cat: 'Social', kind: 'app', color: '#e1306c', glyph: 'I' },
  { id: 'youtube', name: 'YouTube', cat: 'Media', kind: 'player', color: '#ff2a3d', glyph: '▶' },
  { id: 'spotify', name: 'Spotify', cat: 'Media', kind: 'player', color: '#1db954', glyph: 'S' },
  { id: 'netflix', name: 'Netflix', cat: 'Media', kind: 'player', color: '#c40812', glyph: 'N' },
  { id: 'twitch', name: 'Twitch', cat: 'Media', kind: 'player', color: '#9146ff', glyph: 'T' },
  { id: 'tiktok', name: 'TikTok', cat: 'Media', kind: 'player', color: '#161823', glyph: '♪' },
  { id: 'vlc', name: 'Reproductor', cat: 'Media', kind: 'player', color: '#ff8800', glyph: 'V' },
  { id: 'minecraft', name: 'Minecraft', cat: 'Juegos', kind: 'app', color: '#5fa236', glyph: 'M' },
  { id: 'roblox', name: 'Roblox', cat: 'Juegos', kind: 'app', color: '#2b2f3a', glyph: 'R' },
  { id: 'genshin', name: 'Genshin', cat: 'Juegos', kind: 'app', color: '#3d7fd9', glyph: 'G' },
  { id: 'freefire', name: 'Free Fire', cat: 'Juegos', kind: 'app', color: '#ff7a1a', glyph: 'F' },
  { id: 'among', name: 'Among Us', cat: 'Juegos', kind: 'app', color: '#c51111', glyph: 'A' },
  { id: 'stumble', name: 'Stumble', cat: 'Juegos', kind: 'app', color: '#ff4fa3', glyph: 'S' },
  { id: 'chrome', name: 'Navegador', cat: 'Sistema', kind: 'browser', color: '#4285f4', glyph: 'C' },
  { id: 'firefox', name: 'Firefox', cat: 'Sistema', kind: 'browser', color: '#ff7139', glyph: 'F' },
  { id: 'maps', name: 'Mapas', cat: 'Sistema', kind: 'browser', color: '#34a853', glyph: 'M' },
  { id: 'files', name: 'Archivos', cat: 'Sistema', kind: 'app', color: '#f5b400', glyph: '▤' },
  { id: 'camera', name: 'Cámara', cat: 'Sistema', kind: 'app', color: '#4b5563', glyph: '◉' },
  { id: 'calc', name: 'Calculadora', cat: 'Sistema', kind: 'app', color: '#0ea5a4', glyph: '±' },
  { id: 'clock', name: 'Reloj', cat: 'Sistema', kind: 'app', color: '#334155', glyph: '◷' },
  { id: 'terminal', name: 'Terminal', cat: 'Sistema', kind: 'app', color: '#111827', glyph: '>_' },
];

export function drawAppIcon(ctx, app, x, y, s) {
  const g = ctx.createLinearGradient(x, y, x + s, y + s);
  g.addColorStop(0, app.color); g.addColorStop(1, '#0009');
  rr(ctx, x, y, s, s, s * 0.24); ctx.fillStyle = app.color; ctx.fill();
  rr(ctx, x, y, s, s, s * 0.24); ctx.fillStyle = g; ctx.globalAlpha = 0.35; ctx.fill(); ctx.globalAlpha = 1;
  ctx.fillStyle = '#fff'; ctx.font = `700 ${s * 0.5}px system-ui,sans-serif`;
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(app.glyph, x + s / 2, y + s / 2 + s * 0.03);
}
