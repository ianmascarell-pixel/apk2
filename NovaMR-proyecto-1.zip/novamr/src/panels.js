// ─────────────────────────────────────────────────────────────
// Paneles del sistema: Launcher (NovaView), Dock, Selector de escenarios, Ajustes.
// A = { ui, rig, env, wm, settings, state }
// ─────────────────────────────────────────────────────────────
import * as THREE from 'three';
import { Panel, rr } from './panel.js';
import { APPS, CATS, drawAppIcon } from './apps.js';

const clamp = THREE.MathUtils.clamp;
const BG = 'rgba(22,23,28,0.96)';

function frame(ctx, W, H, r = 44) {
  rr(ctx, 0, 0, W, H, r); ctx.fillStyle = BG; ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,.08)'; ctx.lineWidth = 2; ctx.stroke();
}
function grabBar(p, ctx, W, H) {
  ctx.fillStyle = p.hoverId === 'grab' ? '#22d3ee' : 'rgba(255,255,255,.55)';
  rr(ctx, W / 2 - 100, H - 22, 200, 7, 3.5); ctx.fill();
  p.region('grab', W / 2 - 150, H - 40, 300, 40, { kind: 'drag' });
}
function title(ctx, text, sub) {
  ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = '#fff'; ctx.font = '700 46px system-ui,sans-serif'; ctx.fillText(text, 52, 84);
  if (sub) { ctx.fillStyle = '#8b91a0'; ctx.font = '22px system-ui,sans-serif'; ctx.fillText(sub, 54, 118); }
}
function closeBtn(p, W, onClick) {
  p.btn('close', W - 96, 30, 56, 56, { onClick, r: 28, hover: '#e5484d',
    draw: (c, x, y, w, h) => { c.strokeStyle = '#fff'; c.lineWidth = 4; c.beginPath(); c.moveTo(x + 18, y + 18); c.lineTo(x + w - 18, y + h - 18); c.moveTo(x + w - 18, y + 18); c.lineTo(x + 18, y + h - 18); c.stroke(); } });
}
export function toggle(A, panel, opts) {
  if (panel.mesh.visible) return panel.hide();
  A.ui.placeInFront(panel, opts); panel.show(); A.ui.bringToFront(panel);
}

// ───────── Launcher "NovaView" ─────────
function makeLauncher(A) {
  let cat = 'Todos';
  const p = new Panel({ name: 'launcher', w: 1.9, h: 1.26, ppm: 780, draw(ctx, p) {
    const W = p.canvas.width, H = p.canvas.height;
    frame(ctx, W, H);
    title(ctx, 'NovaView', 'Apps y juegos del móvil en ventanas flotantes');
    closeBtn(p, W, () => p.hide());
    // estado
    rr(ctx, 52, 138, 640, 44, 22); ctx.fillStyle = 'rgba(255,255,255,.06)'; ctx.fill();
    ctx.fillStyle = A.state.handOk ? '#34d399' : '#f59e0b'; ctx.beginPath(); ctx.arc(80, 160, 8, 0, 7); ctx.fill();
    ctx.fillStyle = '#c7ccd8'; ctx.font = '21px system-ui,sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(A.state.handStatus, 100, 161);
    // filtros de categoría
    CATS.forEach((c, i) => p.btn('cat:' + c, 52 + i * 178, 196, 166, 52, { label: c, active: c === cat, r: 26, font: '600 22px system-ui,sans-serif', onClick: () => { cat = c; p.scroll = 0; p.dirty = true; } }));
    // rejilla con scroll
    const gx = 52, gy = 268, gw = W - 104, gh = H - gy - 60, cols = 6, cw = gw / cols, ch = 214;
    const list = APPS.filter((a) => cat === 'Todos' || a.cat === cat);
    const rows = Math.ceil(list.length / cols), maxScroll = Math.max(0, rows * ch - gh);
    p.scroll = clamp(p.scroll, 0, maxScroll);
    p.region('grid', gx, gy, gw, gh, { kind: 'scroll', onScroll: (dy) => { p.scroll = clamp(p.scroll + dy, 0, maxScroll); p.dirty = true; } });
    ctx.save(); ctx.beginPath(); ctx.rect(gx, gy, gw, gh); ctx.clip();
    list.forEach((a, i) => {
      const x = gx + (i % cols) * cw, y = gy + Math.floor(i / cols) * ch - p.scroll;
      if (y + ch < gy || y > gy + gh) return;
      const vy = Math.max(y, gy), vh = Math.min(y + ch, gy + gh) - vy; // región visible (recortada)
      p.btn('app:' + a.id, x + 8, vy, cw - 16, vh, { fill: 'rgba(0,0,0,0)', hover: 'rgba(255,255,255,.08)', r: 24, scrollTo: 'grid', onClick: () => A.wm.open(a),
        draw: (c) => { drawAppIcon(c, a, x + cw / 2 - 62, y + 14, 124); c.fillStyle = '#e8eaf0'; c.font = '600 22px system-ui,sans-serif'; c.textAlign = 'center'; c.textBaseline = 'alphabetic'; c.fillText(a.name, x + cw / 2, y + 180); } });
    });
    ctx.restore();
    if (maxScroll > 0) { const th = gh * gh / (gh + maxScroll); ctx.fillStyle = 'rgba(255,255,255,.3)'; rr(ctx, W - 40, gy + (p.scroll / maxScroll) * (gh - th), 8, th, 4); ctx.fill(); }
    grabBar(p, ctx, W, H);
  } });
  return p;
}

// ───────── Dock inferior ─────────
function icon(name, c, cx, cy, s) {
  c.strokeStyle = c.fillStyle = '#fff'; c.lineWidth = 4; c.lineCap = 'round';
  if (name === 'grid') { for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) { rr(c, cx - s + i * s * 0.75, cy - s + j * s * 0.75, s * 0.5, s * 0.5, 4); c.fill(); } }
  else if (name === 'scenes') { c.beginPath(); c.moveTo(cx - s, cy + s * 0.7); c.lineTo(cx - s * 0.3, cy - s * 0.3); c.lineTo(cx + s * 0.2, cy + s * 0.3); c.lineTo(cx + s * 0.55, cy - s * 0.1); c.lineTo(cx + s, cy + s * 0.7); c.closePath(); c.stroke(); c.beginPath(); c.arc(cx + s * 0.55, cy - s * 0.7, s * 0.2, 0, 7); c.fill(); }
  else if (name === 'gear') { c.beginPath(); c.arc(cx, cy, s * 0.45, 0, 7); c.stroke(); for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; c.beginPath(); c.moveTo(cx + Math.cos(a) * s * 0.65, cy + Math.sin(a) * s * 0.65); c.lineTo(cx + Math.cos(a) * s * 0.95, cy + Math.sin(a) * s * 0.95); c.stroke(); } }
  else if (name === 'center') { c.beginPath(); c.arc(cx, cy, s * 0.55, 0, 7); c.stroke(); for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { c.beginPath(); c.moveTo(cx + dx * s * 0.7, cy + dy * s * 0.7); c.lineTo(cx + dx * s * 1.05, cy + dy * s * 1.05); c.stroke(); } c.beginPath(); c.arc(cx, cy, 4, 0, 7); c.fill(); }
}

function makeDock(A, getPanels) {
  let battery = null;
  navigator.getBattery?.().then((b) => { battery = b; const up = () => p.invalidate(); b.addEventListener('levelchange', up); b.addEventListener('chargingchange', up); up(); }).catch(() => {});
  const p = new Panel({ name: 'dock', w: 1.9, h: 0.17, ppm: 760, draw(ctx, p) {
    const W = p.canvas.width, H = p.canvas.height;
    rr(ctx, 0, 0, W, H, H / 2); ctx.fillStyle = 'rgba(20,21,26,.93)'; ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,.1)'; ctx.lineWidth = 2; ctx.stroke();
    const items = [['apps', 'grid', () => toggle(A, getPanels().launcher, { dist: 2.2, y: 0.25 })],
      ['scenes', 'scenes', () => toggle(A, getPanels().scenes, { dist: 2, y: 0.15 })],
      ['settings', 'gear', () => toggle(A, getPanels().settings, { dist: 1.9, y: 0.1 })],
      ['recenter', 'center', () => A.rig.recenter()]];
    const s = 96, x0 = 60, y = (H - s) / 2;
    items.forEach(([id, ic, fn], i) => p.btn(id, x0 + i * (s + 26), y, s, s, { r: s / 2, fill: 'rgba(255,255,255,.07)', onClick: fn, draw: (c, x, yy, w, h) => icon(ic, c, x + w / 2, yy + h / 2, 22) }));
    // reloj + batería
    const d = new Date(), hh = String(d.getHours()).padStart(2, '0'), mm = String(d.getMinutes()).padStart(2, '0');
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#fff'; ctx.font = '600 44px system-ui,sans-serif';
    ctx.fillText(`${hh}:${mm}`, W - 300, H / 2 + 2);
    const lvl = battery ? battery.level : 1, bx = W - 250, by = H / 2 - 20;
    ctx.strokeStyle = '#fff'; ctx.lineWidth = 3; rr(ctx, bx, by, 72, 40, 8); ctx.stroke(); ctx.fillStyle = '#fff'; ctx.fillRect(bx + 74, by + 12, 5, 16);
    ctx.fillStyle = lvl < 0.2 ? '#ef4444' : battery?.charging ? '#34d399' : '#fff'; rr(ctx, bx + 5, by + 5, 62 * lvl, 30, 4); ctx.fill();
    ctx.textAlign = 'left'; ctx.fillStyle = '#c7ccd8'; ctx.font = '600 28px system-ui,sans-serif'; ctx.fillText(battery ? Math.round(lvl * 100) + '%' : '—', bx + 96, H / 2 + 2);
  } });
  setInterval(() => p.invalidate(), 15000); // refrescar reloj
  return p;
}

// ───────── Selector de escenarios ─────────
function makeScenes(A) {
  const p = new Panel({ name: 'scenes', w: 1.6, h: 0.95, ppm: 760, draw(ctx, p) {
    const W = p.canvas.width, H = p.canvas.height;
    frame(ctx, W, H); title(ctx, 'Escenarios', 'Elige tu entorno 360°'); closeBtn(p, W, () => p.hide());
    const cols = 3, gap = 22, cw = (W - 104 - gap * (cols - 1)) / cols, chh = 250;
    A.env.list.forEach((e, i) => {
      const x = 52 + (i % cols) * (cw + gap), y = 150 + Math.floor(i / cols) * (chh + gap), on = A.env.current === e;
      p.btn('env:' + e.id, x, y, cw, chh, { r: 22, fill: '#22242b', onClick: () => A.env.set(e.id),
        draw: (c, xx, yy, w, h, hov) => {
          c.save(); rr(c, xx, yy, w, h, 22); c.clip();
          const src = e.canvas; if (src) c.drawImage(src, 0, src.height * 0.18, src.width * 0.5, src.height * 0.64, xx, yy, w, h); else { c.fillStyle = '#2a2c33'; c.fillRect(xx, yy, w, h); }
          c.fillStyle = 'rgba(0,0,0,.55)'; c.fillRect(xx, yy + h - 56, w, 56); c.restore();
          c.fillStyle = '#fff'; c.font = '600 26px system-ui,sans-serif'; c.textAlign = 'left'; c.textBaseline = 'middle'; c.fillText(e.name, xx + 18, yy + h - 28);
          if (on || hov) { rr(c, xx, yy, w, h, 22); c.lineWidth = on ? 6 : 3; c.strokeStyle = on ? '#22e5ff' : 'rgba(34,229,255,.6)'; c.stroke(); }
        } });
    });
    grabBar(p, ctx, W, H);
  } });
  p.hide(); return p;
}

// ───────── Ajustes ─────────
function makeSettings(A) {
  const p = new Panel({ name: 'settings', w: 1.15, h: 0.95, ppm: 760, draw(ctx, p) {
    const W = p.canvas.width, H = p.canvas.height, S = A.settings;
    frame(ctx, W, H); title(ctx, 'Ajustes'); closeBtn(p, W, () => p.hide());
    const row = (i, label, right) => { const y = 150 + i * 104; ctx.fillStyle = '#e8eaf0'; ctx.font = '600 28px system-ui,sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(label, 56, y + 36); right(y); };
    const sw = (id, val, fn) => (y) => p.btn(id, W - 200, y + 6, 140, 60, { r: 30, fill: val ? '#22c55e' : '#3a3d47', onClick: fn, draw: (c, x, yy, w, h) => { c.fillStyle = '#fff'; c.beginPath(); c.arc(val ? x + w - 32 : x + 32, yy + h / 2, 22, 0, 7); c.fill(); } });
    row(0, 'Mostrar mano', sw('hands', S.showHands, () => { S.showHands = !S.showHands; p.dirty = true; }));
    row(1, 'Pantalla dividida (Cardboard)', sw('split', A.rig.split, () => { A.rig.split = !A.rig.split; p.dirty = true; }));
    row(2, `Distancia entre ojos: ${Math.round(A.rig.stereo.eyeSep * 1000)} mm`, (y) => {
      p.btn('ipd-', W - 260, y + 6, 90, 60, { label: '−', r: 16, font: '700 36px system-ui', onClick: () => { A.rig.stereo.eyeSep = clamp(A.rig.stereo.eyeSep - 0.002, 0.05, 0.075); p.dirty = true; } });
      p.btn('ipd+', W - 150, y + 6, 90, 60, { label: '+', r: 16, font: '700 36px system-ui', onClick: () => { A.rig.stereo.eyeSep = clamp(A.rig.stereo.eyeSep + 0.002, 0.05, 0.075); p.dirty = true; } }); });
    row(3, 'Recentrar vista', (y) => p.btn('rc', W - 260, y + 6, 200, 60, { label: 'Recentrar', r: 16, font: '600 24px system-ui', onClick: () => A.rig.recenter() }));
    grabBar(p, ctx, W, H);
  } });
  p.hide(); return p;
}

export function buildPanels(A) {
  const panels = {};
  panels.launcher = makeLauncher(A); panels.dock = makeDock(A, () => panels); panels.scenes = makeScenes(A); panels.settings = makeSettings(A);
  for (const p of Object.values(panels)) A.ui.add(p);
  return panels;
}
