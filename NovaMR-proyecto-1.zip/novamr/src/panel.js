// ─────────────────────────────────────────────────────────────
// Panel: plano 3D con textura de <canvas>. Cada panel registra "regiones"
// (botones, zonas de scroll/arrastre) en coordenadas de píxel del canvas.
// ─────────────────────────────────────────────────────────────
import * as THREE from 'three';

export function rr(ctx, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

export class Panel {
  /**
   * @param w,h    tamaño físico en metros
   * @param ppm    píxeles por metro de la textura
   * @param draw   (ctx, panel) => void — dibuja y registra regiones
   * @param fps    >0 para paneles animados (se redibujan a ese ritmo)
   */
  constructor({ w, h, ppm = 760, draw, movable = true, fps = 0, name = 'panel' }) {
    Object.assign(this, { w, h, movable, fps, name, drawFn: draw });
    this.canvas = document.createElement('canvas');
    this.canvas.width = Math.round(w * ppm);
    this.canvas.height = Math.round(h * ppm);
    this.ctx = this.canvas.getContext('2d');
    this.tex = new THREE.CanvasTexture(this.canvas);
    this.tex.colorSpace = THREE.SRGBColorSpace;
    this.tex.anisotropy = 4;
    this.mesh = new THREE.Mesh(
      new THREE.PlaneGeometry(w, h),
      // depthTest=false: el orden lo decide renderOrder (el último panel tocado queda encima)
      new THREE.MeshBasicMaterial({ map: this.tex, transparent: true, depthTest: false, depthWrite: false, toneMapped: false }),
    );
    this.mesh.userData.panel = this;
    this.regions = [];
    this.hoverId = null; this.pressedId = null;
    this.dirty = true; this.userScale = 1; this.roll = 0; this.pop = 0; this._last = 0; this.scroll = 0;
  }

  invalidate() { this.dirty = true; }
  show() { this.mesh.visible = true; this.pop = 0; this.dirty = true; }
  hide() { this.mesh.visible = false; }

  region(id, x, y, w, h, opts = {}) { this.regions.push({ id, x, y, w, h, kind: 'button', ...opts }); }
  regionAt(px, py) {
    for (let i = this.regions.length - 1; i >= 0; i--) {
      const r = this.regions[i];
      if (px >= r.x && px <= r.x + r.w && py >= r.y && py <= r.y + r.h) return r;
    }
    return null;
  }
  uvToPx(uv) { return { x: uv.x * this.canvas.width, y: (1 - uv.y) * this.canvas.height }; }
  localToPx(v) { return { x: (v.x / this.w + 0.5) * this.canvas.width, y: (0.5 - v.y / this.h) * this.canvas.height }; }

  /** Botón: dibuja (con estados hover/pressed) y registra su región. */
  btn(id, x, y, w, h, o = {}) {
    const { label = '', onClick, fill = '#2a2c33', hover = '#3a3d47', active = false, activeFill = '#2f6df6',
      r = 16, font = '600 24px system-ui,sans-serif', color = '#fff', draw, scrollTo } = o;
    const ctx = this.ctx, hov = this.hoverId === id, prs = this.pressedId === id;
    rr(ctx, x, y, w, h, r);
    ctx.fillStyle = active ? activeFill : prs ? '#4a4f5c' : hov ? hover : fill; ctx.fill();
    if (hov) { ctx.lineWidth = 3; ctx.strokeStyle = '#22d3ee'; ctx.stroke(); }
    if (draw) draw(ctx, x, y, w, h, hov);
    else if (label) {
      ctx.fillStyle = color; ctx.font = font; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(label, x + w / 2, y + h / 2 + 1);
    }
    this.region(id, x, y, w, h, { kind: 'button', onClick, scrollTo });
  }

  faceUser(camPos) {
    this.mesh.lookAt(camPos);
    this.mesh.rotateZ(this.roll);
    this.mesh.updateMatrixWorld();
  }

  redraw(now) {
    this.regions.length = 0;
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    this.ctx.save();
    this.drawFn(this.ctx, this);
    this.ctx.restore();
    this.tex.needsUpdate = true;
    this.dirty = false; this._last = now;
  }

  update(dt, now) {
    if (this.fps && now - this._last > 1000 / this.fps) this.dirty = true;
    if (this.dirty && this.mesh.visible) this.redraw(now);
    if (this.pop < 1) this.pop = Math.min(1, this.pop + dt * 4);
    const t = this.pop - 1, s = this.userScale * (1 + 2.70158 * t * t * t + 1.70158 * t * t); // easeOutBack
    this.mesh.scale.setScalar(Math.max(0.001, s));
    this.mesh.updateMatrixWorld();
  }
}
