// ─────────────────────────────────────────────────────────────
// StereoRig: cámara VR con giroscopio + render split-screen (Cardboard)
// ─────────────────────────────────────────────────────────────
import * as THREE from 'three';

const Z_AXIS = new THREE.Vector3(0, 0, 1);
const EULER = new THREE.Euler();
const Q_CAM = new THREE.Quaternion(-Math.sqrt(0.5), 0, 0, Math.sqrt(0.5)); // la cámara mira por detrás del móvil
const Q_ORIENT = new THREE.Quaternion();

export class StereoRig {
  constructor(renderer, scene) {
    this.renderer = renderer;
    this.scene = scene;
    this.camera = new THREE.PerspectiveCamera(75, 1, 0.05, 200);
    this.camera.focus = 3; // distancia de convergencia (m)
    scene.add(this.camera); // necesario: la mano y otros hijos cuelgan de la cámara
    this.stereo = new THREE.StereoCamera();
    this.stereo.eyeSep = 0.064; // IPD en metros (ajustable en Ajustes)
    this.split = true;

    this.dev = { alpha: 0, beta: 0, gamma: 0 };
    this.gyroActive = false;
    this.qDevice = new THREE.Quaternion();
    this.yawOffset = 0;
    this.drag = { yaw: 0, pitch: 0 }; // fallback de escritorio (arrastrar con el ratón)
    this._bindMouse();
  }

  /** Debe llamarse dentro de un gesto del usuario (iOS exige permiso explícito). */
  async enableGyro() {
    const D = window.DeviceOrientationEvent;
    if (D && typeof D.requestPermission === 'function') {
      const r = await D.requestPermission();
      if (r !== 'granted') return false;
    }
    window.addEventListener('deviceorientation', (e) => {
      if (e.alpha == null) return;
      this.dev.alpha = e.alpha; this.dev.beta = e.beta; this.dev.gamma = e.gamma;
      this.gyroActive = true;
    }, true);
    return true;
  }

  _bindMouse() {
    let down = false, lx = 0, ly = 0;
    addEventListener('pointerdown', (e) => { if (e.pointerType === 'mouse') { down = true; lx = e.clientX; ly = e.clientY; } });
    addEventListener('pointerup', () => (down = false));
    addEventListener('pointermove', (e) => {
      if (!down || this.gyroActive) return;
      this.drag.yaw -= (e.clientX - lx) * 0.004;
      this.drag.pitch = THREE.MathUtils.clamp(this.drag.pitch - (e.clientY - ly) * 0.004, -1.5, 1.5);
      lx = e.clientX; ly = e.clientY;
    });
  }

  /** Pone "delante" hacia donde miras ahora mismo. */
  recenter() {
    const e = new THREE.Euler().setFromQuaternion(this.qDevice, 'YXZ');
    this.yawOffset = -e.y;
    this.drag.yaw = 0;
  }

  update() {
    if (this.gyroActive) {
      const orient = THREE.MathUtils.degToRad(screen.orientation?.angle ?? window.orientation ?? 0);
      const { alpha, beta, gamma } = this.dev;
      EULER.set(THREE.MathUtils.degToRad(beta), THREE.MathUtils.degToRad(alpha), -THREE.MathUtils.degToRad(gamma), 'YXZ');
      this.qDevice.setFromEuler(EULER).multiply(Q_CAM).multiply(Q_ORIENT.setFromAxisAngle(Z_AXIS, -orient));
      const yaw = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), this.yawOffset);
      this.camera.quaternion.copy(yaw).multiply(this.qDevice);
    } else {
      this.camera.quaternion.setFromEuler(EULER.set(this.drag.pitch, this.drag.yaw, 0, 'YXZ'));
      this.qDevice.copy(this.camera.quaternion);
    }
    this.camera.updateMatrixWorld(true);
  }

  render() {
    const r = this.renderer;
    const { x: w, y: h } = r.getSize(new THREE.Vector2());
    if (!this.split) {
      this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
      r.setScissorTest(false); r.setViewport(0, 0, w, h); r.render(this.scene, this.camera);
      return;
    }
    // Cada ojo ocupa media pantalla → aspecto (w/2)/h
    const aspect = (w / 2) / h;
    this.camera.aspect = aspect; this.camera.updateProjectionMatrix();
    this.stereo.aspect = aspect;
    this.stereo.update(this.camera);
    r.setScissorTest(true);
    r.setViewport(0, 0, w / 2, h); r.setScissor(0, 0, w / 2, h); r.render(this.scene, this.stereo.cameraL);
    r.setViewport(w / 2, 0, w / 2, h); r.setScissor(w / 2, 0, w / 2, h); r.render(this.scene, this.stereo.cameraR);
    r.setScissorTest(false);
  }
}
