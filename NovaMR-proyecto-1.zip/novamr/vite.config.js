import { defineConfig } from 'vite';
import basicSsl from '@vitejs/plugin-basic-ssl';

// HTTPS local: getUserMedia (cámara) y sensores de movimiento exigen contexto seguro
// cuando abres el dev server desde el móvil por la red local.
export default defineConfig({
  base: './',
  plugins: [basicSsl()],
  build: { target: 'es2020', chunkSizeWarningLimit: 1500 },
});
