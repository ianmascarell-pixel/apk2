// Copia el WASM de MediaPipe y descarga el modelo de manos para que la app funcione OFFLINE dentro del APK.
// Si falla, la app cae al CDN en tiempo de ejecución (necesita internet).
import { cpSync, mkdirSync, existsSync, writeFileSync } from 'node:fs';

const wasmSrc = 'node_modules/@mediapipe/tasks-vision/wasm';
if (existsSync(wasmSrc)) {
  mkdirSync('public/mediapipe', { recursive: true });
  cpSync(wasmSrc, 'public/mediapipe/wasm', { recursive: true });
  console.log('✔ WASM copiado a public/mediapipe/wasm');
} else console.warn('⚠ Ejecuta `npm install` primero');

const MODEL = 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';
try {
  const r = await fetch(MODEL);
  if (!r.ok) throw new Error(r.status);
  mkdirSync('public/models', { recursive: true });
  writeFileSync('public/models/hand_landmarker.task', Buffer.from(await r.arrayBuffer()));
  console.log('✔ Modelo hand_landmarker.task descargado');
} catch (e) {
  console.warn('⚠ No se pudo descargar el modelo (' + e + '). Se usará el CDN en runtime.');
}
