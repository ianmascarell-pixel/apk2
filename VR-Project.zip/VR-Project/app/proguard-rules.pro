# Add project specific ProGuard rules here.
-keep class com.vrstream.client.** { *; }
-keep class org.vrstream.** { *; }
-dontwarn javax.microedition.khronos.**
