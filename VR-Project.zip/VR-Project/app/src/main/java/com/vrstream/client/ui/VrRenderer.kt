package com.vrstream.client.ui

import android.content.Context
import android.opengl.GLSurfaceView
import android.util.Log
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * Renderer OpenGL ES para el modo VR.
 * Renderiza la escena 3D standalone y el formato SBS (Side-by-Side).
 */
class VrRenderer(
    private val context: Context,
    private val surfaceView: GLSurfaceView
) {

    companion object {
        private const val TAG = "VrRenderer"
    }

    private var isSBSMode = false
    private var renderer: GLSurfaceView.Renderer? = null

    init {
        setupGLSurface()
    }

    /**
     * Configura el SurfaceView para OpenGL ES 2.0.
     */
    private fun setupGLSurface() {
        surfaceView.setEGLContextClientVersion(2)
        surfaceView.setRenderer(createRenderer())
        surfaceView.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
    }

    /**
     * Crea el renderer principal con soporte SBS.
     */
    private fun createRenderer(): GLSurfaceView.Renderer {
        return object : GLSurfaceView.Renderer {
            override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
                Log.d(TAG, "Superficie GL creada")
                gl?.glClearColor(0.05f, 0.07f, 0.09f, 1.0f)  // Color de fondo VR oscuro
                gl?.glEnable(GL10.GL_DEPTH_TEST)
                gl?.glEnable(GL10.GL_LIGHTING)
                gl?.glEnable(GL10.GL_LIGHT0)
            }

            override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
                Log.d(TAG, "Superficie GL cambiada: ${width}x${height}")

                if (isSBSMode) {
                    // En modo SBS, cada ojo tiene la mitad del ancho
                    val eyeWidth = width / 2
                    gl?.glViewport(0, 0, eyeWidth, height)
                } else {
                    gl?.glViewport(0, 0, width, height)
                }

                gl?.glMatrixMode(GL10.GL_PROJECTION)
                gl?.glLoadIdentity()
                val aspect = if (isSBSMode) {
                    (width.toFloat() / 2) / height.toFloat()
                } else {
                    width.toFloat() / height.toFloat()
                }
                javax.microedition.khronos.glu.GLU.gluPerspective(
                    gl, 60f, aspect, 0.1f, 100f
                )
                gl?.glMatrixMode(GL10.GL_MODELVIEW)
                gl?.glLoadIdentity()
            }

            override fun onDrawFrame(gl: GL10?) {
                gl?.glClear(GL10.GL_COLOR_BUFFER_BIT or GL10.GL_DEPTH_BUFFER_BIT)

                if (isSBSMode) {
                    // Renderizar ojo izquierdo
                    gl?.glViewport(0, 0, (context.resources.displayMetrics.widthPixels / 2),
                        context.resources.displayMetrics.heightPixels)
                    gl?.glLoadIdentity()
                    javax.microedition.khronos.glu.GLU.gluLookAt(
                        gl,
                        -0.0325f, 0f, 0f,   // Posición ojo izquierdo (offset IPD/2)
                        0f, 0f, -1f,          // Mirando al frente
                        0f, 1f, 0f            // Arriba
                    )
                    renderScene(gl)

                    // Renderizar ojo derecho
                    gl?.glViewport(
                        (context.resources.displayMetrics.widthPixels / 2), 0,
                        (context.resources.displayMetrics.widthPixels / 2),
                        context.resources.displayMetrics.heightPixels
                    )
                    gl?.glLoadIdentity()
                    javax.microedition.khronos.glu.GLU.gluLookAt(
                        gl,
                        0.0325f, 0f, 0f,    // Posición ojo derecho (offset IPD/2)
                        0f, 0f, -1f,
                        0f, 1f, 0f
                    )
                    renderScene(gl)
                } else {
                    // Modo standalone - renderizar vista única
                    gl?.glLoadIdentity()
                    javax.microedition.khronos.glu.GLU.gluLookAt(
                        gl,
                        0f, 0f, 0f,
                        0f, 0f, -1f,
                        0f, 1f, 0f
                    )
                    renderScene(gl)
                }
            }

            /**
             * Renderiza la escena 3D (placeholder con una cuadrícula).
             */
            private fun renderScene(gl: GL10?) {
                gl?.glEnableClientState(GL10.GL_VERTEX_ARRAY)

                // Dibujar cuadrícula de referencia
                gl?.glColor4f(0.33f, 0.65f, 1.0f, 0.3f)  // Color VR accent

                for (i in -5..5) {
                    val vertices = floatArrayOf(
                        i.toFloat(), 0f, -5f,
                        i.toFloat(), 0f, 5f
                    )
                    gl?.glVertexPointer(3, GL10.GL_FLOAT, 0,
                        java.nio.ByteBuffer.wrap(vertices.toByteArray()))
                    gl?.glDrawArrays(GL10.GL_LINES, 0, 2)

                    val vertices2 = floatArrayOf(
                        -5f, 0f, i.toFloat(),
                        5f, 0f, i.toFloat()
                    )
                    gl?.glVertexPointer(3, GL10.GL_FLOAT, 0,
                        java.nio.ByteBuffer.wrap(vertices2.toByteArray()))
                    gl?.glDrawArrays(GL10.GL_LINES, 0, 2)
                }

                // Dibujar ejes de referencia
                // Eje X (rojo)
                gl?.glColor4f(1f, 0f, 0f, 1f)
                val xAxis = floatArrayOf(0f, 0f, 0f, 1f, 0f, 0f)
                gl?.glVertexPointer(3, GL10.GL_FLOAT, 0,
                    java.nio.ByteBuffer.wrap(xAxis.toByteArray()))
                gl?.glDrawArrays(GL10.GL_LINES, 0, 2)

                // Eje Y (verde)
                gl?.glColor4f(0f, 1f, 0f, 1f)
                val yAxis = floatArrayOf(0f, 0f, 0f, 0f, 1f, 0f)
                gl?.glVertexPointer(3, GL10.GL_FLOAT, 0,
                    java.nio.ByteBuffer.wrap(yAxis.toByteArray()))
                gl?.glDrawArrays(GL10.GL_LINES, 0, 2)

                // Eje Z (azul)
                gl?.glColor4f(0f, 0f, 1f, 1f)
                val zAxis = floatArrayOf(0f, 0f, 0f, 0f, 0f, -1f)
                gl?.glVertexPointer(3, GL10.GL_FLOAT, 0,
                    java.nio.ByteBuffer.wrap(zAxis.toByteArray()))
                gl?.glDrawArrays(GL10.GL_LINES, 0, 2)

                gl?.glDisableClientState(GL10.GL_VERTEX_ARRAY)
            }
        }
    }

    /**
     * Activa el modo SBS (Side-by-Side) para visores Cardboard.
     */
    fun startSBSMode() {
        isSBSMode = true
        surfaceView.requestRender()
    }

    /**
     * Desactiva el modo SBS y vuelve a vista única.
     */
    fun stopSBSMode() {
        isSBSMode = false
        surfaceView.requestRender()
    }

    /**
     * Detiene el renderer.
     */
    fun stop() {
        surfaceView.queueEvent {
            Log.d(TAG, "Renderer detenido")
        }
    }
}
