package com.vrstream.client.sensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.HandlerThread
import android.util.Log

/**
 * Controlador seguro del giroscopio y acelerómetro.
 *
 * CRÍTICO para MediaTek Dimensity 8200-Ultra (Xiaomi 13T):
 * El registro del SensorManager se realiza en un HandlerThread en segundo plano
 * para evitar saturar el Main Thread y causar crashes fatales.
 *
 * Implementa un sistema de fallback:
 * 1. Intenta SENSOR_DELAY_FASTEST (máxima frecuencia)
 * 2. Si lanza excepción o el dispositivo no lo soporta estable,
 *    hace downgrade automático a SENSOR_DELAY_GAME
 *
 * Esto es especialmente importante en SoCs MediaTek que tienden a
 * saturarse con SENSOR_DELAY_FASTEST en algunos dispositivos.
 */
class SensorController(private val context: Context) : SensorEventListener {

    companion object {
        private const val TAG = "SensorController"

        // Factores de filtro para suavizar la orientación
        private const val FILTER_FACTOR = 0.15f
        private const val ALPHA = 0.98f
    }

    private val sensorManager: SensorManager =
        context.getSystemService(Context.SENSOR_SERVICE) as SensorManager

    private var gyroscope: Sensor? = null
    private var accelerometer: Sensor? = null
    private var rotationVector: Sensor? = null

    // HandlerThread en segundo plano para evitar saturar el Main Thread
    private var sensorThread: HandlerThread? = null
    private var sensorHandler: Handler? = null

    // Quaternion actual (w, x, y, z)
    var currentQuaternion = FloatArray(4)
        private set

    // Valores filtrados para suavizar
    private var filteredQuaternion = FloatArray(4) { if (it == 0) 1f else 0f }

    // Velocidad angular para detección de movimiento rápido
    private var angularVelocity = FloatArray(3)

    // Callback para notificar cambios de orientación
    var onOrientationChanged: ((FloatArray) -> Unit)? = null

    // Estado del sensor
    private var isRunning = false
    private var currentDelay = SensorManager.SENSOR_DELAY_GAME
    private var failedFastestAttempt = false

    /**
     * Intenta registrar el sensor con la frecuencia solicitada.
     * Si falla con SENSOR_DELAY_FASTEST, intenta SENSOR_DELAY_GAME como fallback.
     *
     * PREVENCIÓN DE CRASHES:
     * - Usa HandlerThread dedicado (no el Main Thread)
     * - Captura IllegalArgumentException y SecurityException
     * - Implementa retry con frecuencia reducida
     */
    fun start() {
        if (isRunning) return

        // Crear HandlerThread en segundo plano
        sensorThread = HandlerThread("SensorThread").apply {
            start()
        }
        sensorHandler = Handler(sensorThread!!.looper)

        // Obtener sensores disponibles
        gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        rotationVector = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

        if (rotationVector == null && gyroscope == null) {
            Log.e(TAG, "No hay sensores de orientación disponibles")
            return
        }

        // Intentar registro con SENSOR_DELAY_FASTEST primero
        // Esto es lo que causa problemas en MediaTek Dimensity 8200-Ultra
        if (!failedFastestAttempt) {
            try {
                registerSensors(SensorManager.SENSOR_DELAY_FASTEST)
                currentDelay = SensorManager.SENSOR_DELAY_FASTEST
                Log.d(TAG, "Sensores registrados con SENSOR_DELAY_FASTEST")
            } catch (e: Exception) {
                Log.w(TAG, "SENSOR_DELAY_FASTEST falló: ${e.message}")
                Log.w(TAG, "Haciendo downgrade automático a SENSOR_DELAY_GAME")
                failedFastestAttempt = true
                try {
                    registerSensors(SensorManager.SENSOR_DELAY_GAME)
                    currentDelay = SensorManager.SENSOR_DELAY_GAME
                } catch (e2: Exception) {
                    Log.e(TAG, "SENSOR_DELAY_GAME también falló: ${e2.message}")
                    return
                }
            }
        } else {
            try {
                registerSensors(currentDelay)
            } catch (e: Exception) {
                Log.e(TAG, "Error registrando sensores: ${e.message}")
                return
            }
        }

        isRunning = true
        Log.d(TAG, "Sensores iniciados correctamente")
    }

    /**
     * Registra los sensores con el delay especificado.
     * Utiliza el Handler del HandlerThread dedicado.
     */
    private fun registerSensors(delay: Int) {
        // Registrar rotation vector (el más estable si está disponible)
        rotationVector?.let { sensor ->
            val success = sensorManager.registerListener(
                this,
                sensor,
                delay,
                sensorHandler  // CRÍTICO: Usa Handler del thread dedicado, NO el Main Thread
            )
            if (!success) {
                Log.w(TAG, "registerListener retornó false para ROTATION_VECTOR")
            }
        }

        // Registrar giroscopio como complemento
        gyroscope?.let { sensor ->
            val success = sensorManager.registerListener(
                this,
                sensor,
                delay,
                sensorHandler
            )
            if (!success) {
                Log.w(TAG, "registerListener retornó false para GYROSCOPE")
            }
        }

        // Registrar acelerómetro para referencia gravitacional
        accelerometer?.let { sensor ->
            val success = sensorManager.registerListener(
                this,
                sensor,
                delay,
                sensorHandler
            )
            if (!success) {
                Log.w(TAG, "registerListener retornó false para ACCELEROMETER")
            }
        }
    }

    /**
     * Detiene la escucha de sensores y libera recursos del HandlerThread.
     */
    fun stop() {
        if (!isRunning) return

        sensorManager.unregisterListener(this)
        sensorThread?.quitSafely()
        try {
            sensorThread?.join(100)
        } catch (e: InterruptedException) {
            Log.w(TAG, "Interrupted while joining sensor thread")
        }
        sensorThread = null
        sensorHandler = null
        isRunning = false

        Log.d(TAG, "Sensores detenidos")
    }

    /**
     * Cambia la frecuencia de muestreo dinámicamente.
     * Útil cuando el usuario selecciona una tasa de refresco diferente en settings.
     */
    fun setRefreshRate(rate: Int) {
        val newDelay = when {
            rate >= 120 -> SensorManager.SENSOR_DELAY_FASTEST
            rate >= 90 -> SensorManager.SENSOR_DELAY_GAME
            else -> SensorManager.SENSOR_DELAY_UI
        }

        if (newDelay != currentDelay && isRunning) {
            sensorManager.unregisterListener(this)
            currentDelay = newDelay
            try {
                registerSensors(currentDelay)
            } catch (e: Exception) {
                Log.e(TAG, "Error cambiando frecuencia: ${e.message}")
            }
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_ROTATION_VECTOR -> {
                handleRotationVector(event)
            }
            Sensor.TYPE_GYROSCOPE -> {
                handleGyroscope(event)
            }
            Sensor.TYPE_ACCELEROMETER -> {
                handleAccelerometer(event)
            }
        }
    }

    /**
     * Procesa el vector de rotación (el más preciso para orientación).
     * Convierte a cuaternion y aplica filtro suavizador.
     */
    private fun handleRotationVector(event: SensorEvent) {
        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]
        val w: Float

        // Calcular w (el componente w no siempre viene en el evento)
        if (event.values.size > 3) {
            w = event.values[3]
        } else {
            w = Math.sqrt((1.0 - x * x - y * y - z * z).toDouble()).toFloat()
        }

        // Cuaternion raw
        currentQuaternion[0] = w
        currentQuaternion[1] = x
        currentQuaternion[2] = y
        currentQuaternion[3] = z

        // Aplicar filtro de suavizado (low-pass filter)
        applySmoothingFilter()

        // Notificar cambio de orientación
        onOrientationChanged?.invoke(filteredQuaternion.clone())
    }

    /**
     * Procesa datos del giroscopio para detección de movimiento rápido.
     */
    private fun handleGyroscope(event: SensorEvent) {
        angularVelocity[0] = event.values[0]
        angularVelocity[1] = event.values[1]
        angularVelocity[2] = event.values[2]
    }

    /**
     * Procesa datos del acelerómetro para referencia de gravedad.
     */
    private fun handleAccelerometer(event: SensorEvent) {
        // Solo se usa como referencia, la orientación viene del rotation vector
    }

    /**
     * Aplica filtro de suavizado al cuaternion para evitar jitter.
     * Usa interpolación lineal (LERP) entre el valor anterior y el nuevo.
     */
    private fun applySmoothingFilter() {
        for (i in 0..3) {
            filteredQuaternion[i] = filteredQuaternion[i] * (1 - FILTER_FACTOR) +
                    currentQuaternion[i] * FILTER_FACTOR
        }

        // Normalizar el cuaternion filtrado
        val norm = Math.sqrt(
            filteredQuaternion.sumOf { (it * it).toDouble() }
        ).toFloat()

        if (norm > 0.0001f) {
            for (i in 0..3) {
                filteredQuaternion[i] /= norm
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        Log.d(TAG, "Precisión cambiada para ${sensor?.name}: $accuracy")
    }

    /**
     * Indica si el dispositivo soporta SENSOR_DELAY_FASTEST de forma estable.
     * Útil para mostrar en la UI o ajustar comportamiento.
     */
    fun isFastestSupported(): Boolean = !failedFastestAttempt
}
