package com.vrstream.client

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.vrstream.client.databinding.ActivityVrBinding
import com.vrstream.client.network.NetworkClient
import com.vrstream.client.sensor.SensorController
import com.vrstream.client.tracking.HandTrackingModule
import com.vrstream.client.ui.VrRenderer

/**
 * Actividad principal del visor VR.
 * Maneja el ciclo de vida, la interfaz 3D standalone, la conexión
 * al driver de SteamVR y la coordinación entre módulos.
 */
class VrActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "VrActivity"
        private const val PERMISSION_REQUEST_CODE = 1001
    }

    private lateinit var binding: ActivityVrBinding
    private lateinit var sensorController: SensorController
    private lateinit var handTrackingModule: HandTrackingModule
    private lateinit var networkClient: NetworkClient
    private lateinit var vrRenderer: VrRenderer

    private var isVRMode = false
    private var isConnectedToPC = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Mantener pantalla encendida y modo inmersivo
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enterImmersiveMode()

        binding = ActivityVrBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Solicitar permisos necesarios ANTES de inicializar módulos
        requestRequiredPermissions()

        // Inicializar módulos
        sensorController = SensorController(this)
        handTrackingModule = HandTrackingModule(this)
        networkClient = NetworkClient()
        vrRenderer = VrRenderer(this, binding.vrSurface)

        setupUI()
        setupCallbacks()
    }

    /**
     * Solicita todos los permisos necesarios para el funcionamiento correcto.
     *
     * PERMISOS CRÍTICOS:
     * - HIGH_SAMPLING_RATE_SENSORS: Requerido por Android 12+ para SENSOR_DELAY_FASTEST
     *   Sin este permiso, Google lanza SecurityException al usar frecuencias > 200Hz
     * - CAMERA: Necesario para Hand Tracking (MediaPipe)
     * - INTERNET: Para conexión UDP/TCP al driver de SteamVR
     */
    private fun requestRequiredPermissions() {
        val permissionsNeeded = mutableListOf<String>()

        // Permiso CRÍTICO para sensores de alta frecuencia (Android 12+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.HIGH_SAMPLING_RATE_SENSORS)
                != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(Manifest.permission.HIGH_SAMPLING_RATE_SENSORS)
                Log.d(TAG, "Permiso HIGH_SAMPLING_RATE_SENSORS necesario (Android 12+)")
            }
        }

        // Permiso de cámara para Hand Tracking
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.CAMERA)
        }

        if (permissionsNeeded.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                permissionsNeeded.toTypedArray(),
                PERMISSION_REQUEST_CODE
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        when (requestCode) {
            PERMISSION_REQUEST_CODE -> {
                permissions.forEachIndexed { index, permission ->
                    val granted = grantResults[index] == PackageManager.PERMISSION_GRANTED
                    when (permission) {
                        Manifest.permission.HIGH_SAMPLING_RATE_SENSORS -> {
                            if (granted) {
                                Log.d(TAG, "HIGH_SAMPLING_RATE_SENSORS concedido")
                                Toast.makeText(this,
                                    "Frecuencia alta de sensores habilitada",
                                    Toast.LENGTH_SHORT).show()
                            } else {
                                Log.w(TAG, "HIGH_SAMPLING_RATE_SENSORS denegado")
                                Toast.makeText(this,
                                    "Sin permiso de alta frecuencia. Usando modo compatibilidad.",
                                    Toast.LENGTH_LONG).show()
                            }
                        }
                        Manifest.permission.CAMERA -> {
                            if (granted) {
                                Log.d(TAG, "Permiso de cámara concedido")
                            } else {
                                Log.w(TAG, "Permiso de cámara denegado")
                                Toast.makeText(this,
                                    "Hand Tracking no funcionará sin cámara",
                                    Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Entra en modo inmersivo ocultando barras del sistema.
     * Esto es esencial para la experiencia VR en el Xiaomi 13T
     * ya que aprovecha toda la pantalla including notch/cutout.
     */
    private fun enterImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                it.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                )
        }
    }

    /**
     * Configura los botones de la interfaz: dock inferior y overlay de conexión.
     * El botón "Iniciar Vista VR" divide la pantalla en SBS y conecta al servidor.
     */
    private fun setupUI() {
        // Botón principal: Iniciar modo VR SBS
        binding.btnStartVR.setOnClickListener {
            startVRMode()
        }

        // Botón conectar a PC
        binding.btnConnect.setOnClickListener {
            connectToPC()
        }

        // Botón desconectar
        binding.btnDisconnect.setOnClickListener {
            disconnectFromPC()
        }

        // Botón configuración
        binding.btnSettings.setOnClickListener {
            val intent = android.content.Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }
    }

    /**
     * Configura los callbacks entre módulos:
     * - Cuando el sensor detecta rotación -> enviar a la PC
     * - Cuando MediaPipe detecta manos -> renderizar y enviar input
     * - Cuando la red recibe datos -> actualizar UI
     */
    private fun setupCallbacks() {
        // Callback del giroscopio: envía cuaterniones a la PC
        sensorController.onOrientationChanged = { quaternion ->
            if (isConnectedToPC) {
                networkClient.sendOrientation(quaternion)
            }
        }

        // Callback de hand tracking: envía datos de manos a la PC
        handTrackingModule.onHandData = { handData ->
            if (isConnectedToPC) {
                networkClient.sendHandData(handData)
            }
        }

        // Callback de conexión
        networkClient.onConnectionStateChanged = { connected ->
            runOnUiThread {
                isConnectedToPC = connected
                updateConnectionUI(connected)
            }
        }

        networkClient.onError = { errorMsg ->
            runOnUiThread {
                Toast.makeText(this, "Error: $errorMsg", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * Activa el modo VR dividiendo la pantalla en formato SBS (Side-by-Side).
     * Inicia la captura del giroscopio y hand tracking.
     */
    private fun startVRMode() {
        isVRMode = true
        binding.connectionOverlay.visibility = View.GONE

        // Iniciar renderer VR SBS
        vrRenderer.startSBSMode()

        // Iniciar sensores con manejo seguro de errores
        // CRÍTICO: Esto previene crasheos en MediaTek Dimensity 8200-Ultra
        sensorController.start()

        // Iniciar hand tracking si está habilitado
        handTrackingModule.start()

        Toast.makeText(this, "Modo VR activado", Toast.LENGTH_SHORT).show()
    }

    /**
     * Conecta al driver de SteamVR en la PC por UDP.
     */
    private fun connectToPC() {
        val prefs = getSharedPreferences("vr_settings", MODE_PRIVATE)
        val ip = prefs.getString("pc_ip", "192.168.1.100") ?: "192.168.1.100"
        val port = prefs.getInt("pc_port", 9999)

        binding.connectionStatusText.text = getString(com.vrstream.client.R.string.connecting)
        networkClient.connect(ip, port)
    }

    /**
     * Desconecta del driver de SteamVR.
     */
    private fun disconnectFromPC() {
        networkClient.disconnect()
    }

    /**
     * Actualiza la UI según el estado de conexión.
     */
    private fun updateConnectionUI(connected: Boolean) {
        if (connected) {
            binding.connectionStatusText.text = getString(com.vrstream.client.R.string.connected)
            binding.connectionStatusText.setTextColor(
                resources.getColor(com.vrstream.client.R.color.vr_success, theme)
            )
            binding.btnConnect.visibility = View.GONE
            binding.btnDisconnect.visibility = View.VISIBLE
        } else {
            binding.connectionStatusText.text = getString(com.vrstream.client.R.string.disconnected)
            binding.connectionStatusText.setTextColor(
                resources.getColor(com.vrstream.client.R.color.vr_text, theme)
            )
            binding.btnConnect.visibility = View.VISIBLE
            binding.btnDisconnect.visibility = View.GONE
        }
    }

    override fun onResume() {
        super.onResume()
        enterImmersiveMode()
        if (isVRMode) {
            sensorController.start()
            handTrackingModule.start()
        }
    }

    override fun onPause() {
        super.onPause()
        sensorController.stop()
        handTrackingModule.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        networkClient.disconnect()
        vrRenderer.stop()
    }
}
