package com.vrstream.client.ui

import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.vrstream.client.R
import com.vrstream.client.databinding.ActivitySettingsBinding

/**
 * Activity de configuración del visor VR.
 * Permite ajustar IP/Puerto, IPD, tasa de refresco y modo de control.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = getSharedPreferences("vr_settings", MODE_PRIVATE)
        loadSettings()
        setupSaveButton()
    }

    /**
     * Carga las configuraciones guardadas.
     */
    private fun loadSettings() {
        binding.etIpAddress.setText(prefs.getString("pc_ip", "192.168.1.100"))
        binding.etPort.setText(prefs.getInt("pc_port", 9999).toString())
        binding.sliderIPD.value = prefs.getFloat("ipd", 63.0f)
        binding.sliderRefreshRate.value = prefs.getFloat("refresh_rate", 90.0f)

        val useHandTracking = prefs.getBoolean("use_hand_tracking", true)
        binding.chipHandTracking.isChecked = useHandTracking
        binding.chipGamepad.isChecked = !useHandTracking
    }

    /**
     * Configura el botón de guardar.
     */
    private fun setupSaveButton() {
        binding.btnSaveSettings.setOnClickListener {
            saveSettings()
            Toast.makeText(this, "Configuración guardada", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    /**
     * Guarda las configuraciones en SharedPreferences.
     */
    private fun saveSettings() {
        val editor = prefs.edit()

        editor.putString("pc_ip", binding.etIpAddress.text.toString())
        editor.putInt("pc_port", binding.etPort.text.toString().toIntOrNull() ?: 9999)
        editor.putFloat("ipd", binding.sliderIPD.value)
        editor.putFloat("refresh_rate", binding.sliderRefreshRate.value)
        editor.putBoolean("use_hand_tracking", binding.chipHandTracking.isChecked)

        editor.apply()
    }
}
