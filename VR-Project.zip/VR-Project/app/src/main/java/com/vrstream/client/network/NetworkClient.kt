package com.vrstream.client.network

import android.util.Log
import kotlinx.coroutines.*
import java.io.*
import java.net.*
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Cliente de red para comunicación con el driver de SteamVR.
 *
 * Protocolo UDP de baja latencia para enviar:
 * - Cuaterniones de orientación del giroscopio (3DOF)
 * - Datos de hand tracking (landmarks, pellizco)
 * - Eventos de gamepad (botones, triggers)
 *
 * También soporta TCP para conexión USB via ADB forward.
 */
class NetworkClient {

    companion object {
        private const val TAG = "NetworkClient"

        // Protocolo de mensajes
        private const val MSG_ORIENTATION = 0x01
        private const val MSG_HAND_DATA = 0x02
        private const val MSG_GAMEPAD = 0x03
        private const val MSG_PING = 0x04
        private const val MSG_PONG = 0x05
        private const val MSG_CONNECT = 0x10
        private const val MSG_DISCONNECT = 0x11

        // Tamaño máximo de paquete UDP
        private const val MAX_PACKET_SIZE = 1024
    }

    // Variables de conexión
    private var udpSocket: DatagramSocket? = null
    private var tcpSocket: Socket? = null
    private var serverAddress: InetAddress? = null
    private var serverPort: Int = 9999
    private var isConnected = false

    // Coroutines
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var pingJob: Job? = null
    private var receiveJob: Job? = null

    // Callbacks
    var onConnectionStateChanged: ((Boolean) -> Unit)? = null
    var onError: ((String) -> Unit)? = null
    var onDataReceived: ((ByteArray) -> Unit)? = null

    // Estadísticas de latencia
    var latencyMs: Long = 0
        private set

    /**
     * Conecta al driver de SteamVR por UDP.
     *
     * @param ip Dirección IP del PC (ej: "192.168.1.100")
     * @param port Puerto UDP (default: 9999)
     */
    fun connect(ip: String, port: Int) {
        if (isConnected) return

        serverPort = port

        try {
            serverAddress = InetAddress.getByName(ip)
        } catch (e: UnknownHostException) {
            onError?.invoke("IP inválida: $ip")
            return
        }

        try {
            // Crear socket UDP
            udpSocket = DatagramSocket()
            udpSocket?.soTimeout = 5000  // 5 segundos timeout

            // Enviar mensaje de conexión
            val connectMsg = byteArrayOf(MSG_CONNECT, 0x00)
            val packet = DatagramPacket(
                connectMsg,
                connectMsg.size,
                serverAddress,
                serverPort
            )
            udpSocket?.send(packet)

            isConnected = true
            onConnectionStateChanged?.invoke(true)
            Log.d(TAG, "Conectado a $ip:$port")

            // Iniciar ping para medir latencia
            startPing()

            // Iniciar receptor de datos
            startReceiver()

        } catch (e: SocketException) {
            onError?.invoke("Error de socket: ${e.message}")
            Log.e(TAG, "Error de socket: ${e.message}")
        } catch (e: IOException) {
            onError?.invoke("Error de conexión: ${e.message}")
            Log.e(TAG, "Error de conexión: ${e.message}")
        }
    }

    /**
     * Conecta por TCP (para USB via ADB forward).
     * Usa adb forward tcp:9999 tcp:9999 para redirigir el tráfico.
     */
    fun connectTCP(ip: String = "127.0.0.1", port: Int = 9999) {
        if (isConnected) return

        serverPort = port

        scope.launch {
            try {
                tcpSocket = Socket()
                tcpSocket?.connect(InetSocketAddress(ip, port), 5000)
                isConnected = true
                onConnectionStateChanged?.invoke(true)
                Log.d(TAG, "Conectado por TCP a $ip:$port")

                startTcpReceiver()
            } catch (e: Exception) {
                onError?.invoke("Error TCP: ${e.message}")
                Log.e(TAG, "Error TCP: ${e.message}")
            }
        }
    }

    /**
     * Desconecta del servidor.
     */
    fun disconnect() {
        if (!isConnected) return

        try {
            // Enviar mensaje de desconexión
            val disconnectMsg = byteArrayOf(MSG_DISCONNECT, 0x00)
            val packet = DatagramPacket(
                disconnectMsg,
                disconnectMsg.size,
                serverAddress,
                serverPort
            )
            udpSocket?.send(packet)
        } catch (e: Exception) {
            Log.w(TAG, "Error enviando desconexión: ${e.message}")
        }

        isConnected = false
        pingJob?.cancel()
        receiveJob?.cancel()

        udpSocket?.close()
        tcpSocket?.close()

        udpSocket = null
        tcpSocket = null

        onConnectionStateChanged?.invoke(false)
        Log.d(TAG, "Desconectado")
    }

    /**
     * Envía datos de orientación (cuaternion) al driver de SteamVR.
     *
     * @param quaternion FloatArray con [w, x, y, z]
     */
    fun sendOrientation(quaternion: FloatArray) {
        if (!isConnected || quaternion.size < 4) return

        try {
            val buffer = ByteBuffer.allocate(MAX_PACKET_SIZE).apply {
                order(ByteOrder.LITTLE_ENDIAN)
                put(MSG_ORIENTATION.toByte())
                put(quaternion[0])  // w
                put(quaternion[1])  // x
                put(quaternion[2])  // y
                put(quaternion[3])  // z
            }

            val data = buffer.array().sliceArray(0..buffer.position() - 1)
            val packet = DatagramPacket(data, data.size, serverAddress, serverPort)
            udpSocket?.send(packet)

        } catch (e: IOException) {
            Log.e(TAG, "Error enviando orientación: ${e.message}")
        }
    }

    /**
     * Envía datos de hand tracking al driver de SteamVR.
     *
     * @param handData Datos de la mano detectada
     */
    fun sendHandData(handData: Any) {
        if (!isConnected) return

        try {
            // Convertir HandData a bytes
            // Formato: [MSG_HAND_DATA, isPinching, pinchStrength, numLandmarks, ...landmarks(xyz), ...rayDir(xyz)]
            val buffer = ByteBuffer.allocate(MAX_PACKET_SIZE).apply {
                order(ByteOrder.LITTLE_ENDIAN)
                put(MSG_HAND_DATA.toByte())

                // Aquí se serializarían los datos reales de hand tracking
                // Por simplicidad, enviamos un placeholder
                put(0.toByte())  // isPinching
                putFloat(0f)     // pinchStrength
                putFloat(0f)     // handCenter x
                putFloat(0f)     // handCenter y
                putFloat(0f)     // handCenter z
                putFloat(0f)     // rayDirection x
                putFloat(0f)     // rayDirection y
                putFloat(-1f)    // rayDirection z
            }

            val data = buffer.array().sliceArray(0..buffer.position() - 1)
            val packet = DatagramPacket(data, data.size, serverAddress, serverPort)
            udpSocket?.send(packet)

        } catch (e: IOException) {
            Log.e(TAG, "Error enviando hand data: ${e.message}")
        }
    }

    /**
     * Envía eventos de gamepad al driver de SteamVR.
     *
     * @param buttons Estado de botones (mascara de bits)
     * @param xAxis Eje X del stick izquierdo (-1.0 a 1.0)
     * @param yAxis Eje Y del stick izquierdo (-1.0 a 1.0)
     * @param trigger Valor del gatillo (0.0 a 1.0)
     */
    fun sendGamepadEvent(
        buttons: Int,
        xAxis: Float,
        yAxis: Float,
        trigger: Float
    ) {
        if (!isConnected) return

        try {
            val buffer = ByteBuffer.allocate(MAX_PACKET_SIZE).apply {
                order(ByteOrder.LITTLE_ENDIAN)
                put(MSG_GAMEPAD.toByte())
                putInt(buttons)
                putFloat(xAxis)
                putFloat(yAxis)
                putFloat(trigger)
            }

            val data = buffer.array().sliceArray(0..buffer.position() - 1)
            val packet = DatagramPacket(data, data.size, serverAddress, serverPort)
            udpSocket?.send(packet)

        } catch (e: IOException) {
            Log.e(TAG, "Error enviando gamepad: ${e.message}")
        }
    }

    /**
     * Envía ping para medir latencia.
     */
    private fun sendPing() {
        if (!isConnected) return

        try {
            val timestamp = System.currentTimeMillis()
            val buffer = ByteBuffer.allocate(9).apply {
                order(ByteOrder.LITTLE_ENDIAN)
                put(MSG_PING.toByte())
                putLong(timestamp)
            }

            val data = buffer.array()
            val packet = DatagramPacket(data, data.size, serverAddress, serverPort)
            udpSocket?.send(packet)
        } catch (e: IOException) {
            Log.w(TAG, "Error enviando ping: ${e.message}")
        }
    }

    /**
     * Inicia el loop de ping periódico.
     */
    private fun startPing() {
        pingJob = scope.launch {
            while (isActive && isConnected) {
                sendPing()
                delay(1000)  // Ping cada segundo
            }
        }
    }

    /**
     * Inicia el receptor de mensajes UDP en un hilo dedicado.
     */
    private fun startReceiver() {
        receiveJob = scope.launch {
            val buffer = ByteArray(MAX_PACKET_SIZE)

            while (isActive && isConnected) {
                try {
                    val packet = DatagramPacket(buffer, buffer.size)
                    udpSocket?.receive(packet)

                    // Procesar mensaje recibido
                    val data = packet.data.copyOf(packet.length)
                    processReceivedMessage(data)

                } catch (e: SocketTimeoutException) {
                    // Timeout normal, continuar
                } catch (e: IOException) {
                    if (isConnected) {
                        Log.e(TAG, "Error recibiendo datos: ${e.message}")
                    }
                }
            }
        }
    }

    /**
     * Inicia el receptor TCP.
     */
    private fun startTcpReceiver() {
        receiveJob = scope.launch {
            val socket = tcpSocket ?: return@launch
            val inputStream = socket.getInputStream() ?: return@launch

            while (isActive && isConnected) {
                try {
                    val data = ByteArray(MAX_PACKET_SIZE)
                    val bytesRead = inputStream.read(data)

                    if (bytesRead > 0) {
                        processReceivedMessage(data.copyOf(bytesRead))
                    } else if (bytesRead == -1) {
                        // Conexión cerrada
                        withContext(Dispatchers.Main) {
                            disconnect()
                        }
                        break
                    }
                } catch (e: IOException) {
                    if (isConnected) {
                        Log.e(TAG, "Error TCP leyendo: ${e.message}")
                    }
                }
            }
        }
    }

    /**
     * Procesa un mensaje recibido del servidor.
     */
    private fun processReceivedMessage(data: ByteArray) {
        if (data.isEmpty()) return

        when (data[0].toInt() and 0xFF) {
            MSG_PONG -> {
                if (data.size >= 9) {
                    val buffer = ByteBuffer.wrap(data).apply {
                        order(ByteOrder.LITTLE_ENDIAN)
                        get()  // Skip message type
                        val sentTime = long
                    }
                    latencyMs = System.currentTimeMillis() - sentTime
                }
            }
            MSG_CONNECT -> {
                Log.d(TAG, "Servidor confirmó conexión")
            }
            else -> {
                onDataReceived?.invoke(data)
            }
        }
    }
}
