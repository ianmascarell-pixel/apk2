package com.vrstream.client.tracking

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.nio.ByteBuffer

/**
 * Módulo de Hand Tracking usando Google MediaPipe Tasks Vision.
 *
 * Implementa:
 * - Hand Landmarker para detectar y seguir manos en tiempo real
 * - Detección del gesto de pellizco (dedo índice + pulgar)
 * - Cálculo de distancia entre landmarks 8 y 4
 * - Raycasting desde la mano detectada
 * - Renderizado de contorno/malla estilo Meta Quest
 */
class HandTrackingModule(private val context: Context) {

    companion object {
        private const val TAG = "HandTracking"

        // Landmarks de MediaPipe para dedos
        // 4 = Pulgar (tip), 8 = Índice (tip)
        private const val THUMB_TIP = 4
        private const val INDEX_TIP = 8

        // Umbral de distancia para detectar pellizco (en normalizado 0-1)
        private const val PINCH_THRESHOLD = 0.05f

        // Resolución de captura optimizada para hand tracking
        private const val CAPTURE_WIDTH = 640
        private const val CAPTURE_HEIGHT = 480
    }

    // MediaPipe Hand Landmarker
    private var handLandmarker: HandLandmarker? = null

    // Camera2 API
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var imageReader: ImageReader? = null
    private var cameraThread: HandlerThread? = null
    private var cameraHandler: Handler? = null

    // Estado del tracking
    private var isRunning = false
    private var isPinching = false
    private var lastHandLandmarks: List<com.google.mediapipe.tasks.components.containers.NormalizedLandmark>? = null

    // Callbacks
    var onHandData: ((HandData) -> Unit)? = null
    var onPinchDetected: ((Boolean, FloatArray) -> Unit)? = null

    /**
     * Datos de la mano procesada, listos para enviar al driver de SteamVR.
     */
    data class HandData(
        val landmarks: List<FloatArray>,   // Posiciones normalizadas (x, y, z)
        val isPinching: Boolean,           // Estado del gesto pellizco
        val pinchStrength: Float,          // Fuerza del pellizco (0-1)
        val handCenter: FloatArray,        // Centro de la mano
        val rayDirection: FloatArray       // Dirección del rayo para raycasting
    )

    /**
     * Inicializa MediaPipe Hand Landmarker con el modelo pre-entrenado.
     * Usa el GPU delegate para mejor rendimiento en el celular.
     */
    fun start() {
        if (isRunning) return

        // Crear handler dedicado para cámara
        cameraThread = HandlerThread("CameraThread").apply {
            start()
        }
        cameraHandler = Handler(cameraThread!!.looper)

        // Inicializar MediaPipe Hand Landmarker
        try {
            val baseOptions = BaseOptions.builder()
                .setModelAssetPath("hand_landmarker.task")
                .build()

            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setNumHands(2)  // Detectar ambas manos
                .setMinHandDetectionConfidence(0.5f)
                .setMinHandPresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setRunningMode(com.google.mediapipe.tasks.vision.core.RunningMode.LIVE_STREAM)
                .setResultListener { result, _ ->
                    processHandResult(result)
                }
                .setErrorListener { error ->
                    Log.e(TAG, "Error en MediaPipe: ${error.message}")
                }
                .build()

            handLandmarker = HandLandmarker.createFromOptions(context, options)
            Log.d(TAG, "MediaPipe Hand Landmarker inicializado")
        } catch (e: Exception) {
            Log.e(TAG, "Error inicializando MediaPipe: ${e.message}")
            return
        }

        // Iniciar cámara
        startCamera()
        isRunning = true
    }

    /**
     * Inicia la cámara frontal para capturar frames para hand tracking.
     * Usa la cámara frontal (FACING_FRONT) para ver las manos del usuario.
     */
    private fun startCamera() {
        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

        try {
            // Buscar cámara frontal
            var cameraId: String? = null
            for (id in cameraManager.cameraIdList) {
                val characteristics = cameraManager.getCameraCharacteristics(id)
                val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
                if (facing == CameraCharacteristics.LENS_FACING_FRONT) {
                    cameraId = id
                    break
                }
            }

            if (cameraId == null) {
                Log.e(TAG, "No se encontró cámara frontal")
                return
            }

            // Configurar ImageReader para recibir frames
            imageReader = ImageReader.newInstance(
                CAPTURE_WIDTH,
                CAPTURE_HEIGHT,
                ImageFormat.YUV_420_888,
                2  // Max images
            )

            imageReader?.setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                processImage(image)
                image.close()
            }, cameraHandler)

            // Abrir cámara
            cameraManager.openCamera(
                cameraId,
                object : CameraDevice.StateCallback() {
                    override fun onOpened(camera: CameraDevice) {
                        cameraDevice = camera
                        createCaptureSession()
                    }

                    override fun onDisconnected(camera: CameraDevice) {
                        camera.close()
                        cameraDevice = null
                    }

                    override fun onError(camera: CameraDevice, error: Int) {
                        Log.e(TAG, "Error de cámara: $error")
                        camera.close()
                        cameraDevice = null
                    }
                },
                cameraHandler
            )
        } catch (e: SecurityException) {
            Log.e(TAG, "Sin permisos de cámara: ${e.message}")
        } catch (e: Exception) {
            Log.e(TAG, "Error abriendo cámara: ${e.message}")
        }
    }

    /**
     * Crea la sesión de captura de cámara con configuración automática.
     */
    private fun createCaptureSession() {
        val camera = cameraDevice ?: return
        val reader = imageReader ?: return

        try {
            val request = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                addTarget(reader.surface)
                set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
                set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
            }

            camera.createCaptureSession(
                listOf(reader.surface),
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(session: CameraCaptureSession) {
                        captureSession = session
                        session.setRepeatingRequest(
                            request.build(),
                            null,
                            cameraHandler
                        )
                        Log.d(TAG, "Sesión de cámara configurada")
                    }

                    override fun onConfigureFailed(session: CameraCaptureSession) {
                        Log.e(TAG, "Error configurando sesión de cámara")
                    }
                },
                cameraHandler
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error creando sesión: ${e.message}")
        }
    }

    /**
     * Procesa cada frame de la cámara con MediaPipe.
     * Convierte YUV a Bitmap y lo envía al Hand Landmarker.
     */
    private fun processImage(image: Image) {
        if (!isRunning) return

        try {
            // Convertir Image a Bitmap
            val bitmap = yuv420ToBitmap(image) ?: return

            // Crear timestamp para MediaPipe
            val timestampMs = System.currentTimeMillis()

            // Enviar frame a MediaPipe
            val mpImage = BitmapImageBuilder(bitmap).build()
            handLandmarker?.detectAsync(mpImage, timestampMs)
        } catch (e: Exception) {
            Log.e(TAG, "Error procesando imagen: ${e.message}")
        }
    }

    /**
     * Convierte imagen YUV_420_888 a Bitmap para MediaPipe.
     */
    private fun yuv420ToBitmap(image: Image): Bitmap? {
        try {
            val yBuffer = image.planes[0].buffer
            val uBuffer = image.planes[1].buffer
            val vBuffer = image.planes[2].buffer

            val ySize = yBuffer.remaining()
            val uSize = uBuffer.remaining()
            val vSize = vBuffer.remaining()

            val nv21 = ByteArray(ySize + uSize + vSize)

            // Copiar planos Y
            yBuffer.get(nv21, 0, ySize)

            // Interleavar U y V para NV21
            var pos = ySize
            val vp = vBuffer.position()
            val up = uBuffer.position()
            for (i in 0 until uSize / 2) {
                nv21[pos++] = vBuffer.get(vp + i * 2)
                nv21[pos++] = uBuffer.get(up + i * 2)
            }

            val yuvImage = android.graphics.YuvImage(
                nv21,
                ImageFormat.NV21,
                image.width,
                image.height,
                null
            )

            val out = java.io.ByteArrayOutputStream()
            yuvImage.compressToJpeg(
                android.graphics.Rect(0, 0, image.width, image.height),
                90,
                out
            )

            val bytes = out.toByteArray()
            return android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (e: Exception) {
            Log.e(TAG, "Error convirtiendo YUV: ${e.message}")
            return null
        }
    }

    /**
     * Procesa el resultado de MediaPipe Hand Landmarker.
     * Detecta el gesto de pellizco y calcula la dirección del rayo.
     */
    private fun processHandResult(result: HandLandmarkerResult) {
        if (result.landmarks().isEmpty()) {
            lastHandLandmarks = null
            return
        }

        // Tomar la primera mano detectada
        val handLandmarks = result.landmarks()[0]
        lastHandLandmarks = handLandmarks

        // Obtener landmarks del pulgar e índice para pellizco
        val thumbTip = handLandmarks[THUMB_TIP]
        val indexTip = handLandmarks[INDEX_TIP]

        // Calcular distancia entre pulgar e índice (normalizado 0-1)
        val pinchDistance = Math.sqrt(
            Math.pow(
                (thumbTip.x() - indexTip.x()).toDouble(), 2.0
            ) +
            Math.pow(
                (thumbTip.y() - indexTip.y()).toDouble(), 2.0
            ) +
            Math.pow(
                (thumbTip.z() - indexTip.z()).toDouble(), 2.0
            )
        ).toFloat()

        // Detectar gesto de pellizco
        val wasPinching = isPinching
        isPinching = pinchDistance < PINCH_THRESHOLD

        // Calcular fuerza del pellizco (inversa de la distancia)
        val pinchStrength = if (isPinching) {
            (1.0f - (pinchDistance / PINCH_THRESHOLD)).coerceIn(0f, 1f)
        } else {
            0f
        }

        // Centro de la mano (promedio de todos los landmarks)
        val handCenter = calculateHandCenter(handLandmarks)

        // Dirección del rayo desde la muñeca hacia los dedos
        val rayDirection = calculateRayDirection(handLandmarks)

        // Convertir landmarks a formato FloatArray
        val landmarkPositions = handLandmarks.map { landmark ->
            floatArrayOf(landmark.x(), landmark.y(), landmark.z())
        }

        // Crear datos de mano
        val handData = HandData(
            landmarks = landmarkPositions,
            isPinching = isPinching,
            pinchStrength = pinchStrength,
            handCenter = handCenter,
            rayDirection = rayDirection
        )

        // Notificar callback
        onHandData?.invoke(handData)

        // Notificar cambio en el estado de pellizco
        if (isPinching != wasPinching) {
            onPinchDetected?.invoke(isPinching, handCenter)
        }
    }

    /**
     * Calcula el centro promedio de la mano.
     */
    private fun calculateHandCenter(
        landmarks: List<com.google.mediapipe.tasks.components.containers.NormalizedLandmark>
    ): FloatArray {
        var x = 0f
        var y = 0f
        var z = 0f

        for (landmark in landmarks) {
            x += landmark.x()
            y += landmark.y()
            z += landmark.z()
        }

        val count = landmarks.size.toFloat()
        return floatArrayOf(x / count, y / count, z / count)
    }

    /**
     * Calcula la dirección del rayo para raycasting.
     * El rayo sale desde la muñeca (landmark 0) hacia el dedo índice (landmark 8).
     */
    private fun calculateRayDirection(
        landmarks: List<com.google.mediapipe.tasks.components.containers.NormalizedLandmark>
    ): FloatArray {
        val wrist = landmarks[0]
        val indexTip = landmarks[INDEX_TIP]

        val dirX = indexTip.x() - wrist.x()
        val dirY = indexTip.y() - wrist.y()
        val dirZ = indexTip.z() - wrist.z()

        // Normalizar
        val length = Math.sqrt(
            (dirX * dirX + dirY * dirY + dirZ * dirZ).toDouble()
        ).toFloat()

        return if (length > 0.0001f) {
            floatArrayOf(dirX / length, dirY / length, dirZ / length)
        } else {
            floatArrayOf(0f, 0f, -1f)
        }
    }

    /**
     * Detiene el hand tracking y libera recursos.
     */
    fun stop() {
        isRunning = false

        captureSession?.close()
        cameraDevice?.close()
        imageReader?.close()

        captureSession = null
        cameraDevice = null
        imageReader = null

        cameraThread?.quitSafely()
        try {
            cameraThread?.join(100)
        } catch (e: InterruptedException) {
            Log.w(TAG, "Interrupted joining camera thread")
        }
        cameraThread = null
        cameraHandler = null

        handLandmarker?.close()
        handLandmarker = null

        Log.d(TAG, "Hand tracking detenido")
    }
}
