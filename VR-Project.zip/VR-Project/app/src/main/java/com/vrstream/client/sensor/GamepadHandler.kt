package com.vrstream.client.sensor

import android.content.Context
import android.hardware.InputDevice
import android.view.InputDevice as AndroidInputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import com.vrstream.client.network.NetworkClient

/**
 * Manejador de gamepads Bluetooth (PS4/DualShock 4).
 *
 * Captura eventos de controles usando la API InputDevice de Android
 * y los mapea para enviar al driver de SteamVR:
 *
 * Mapeo PS4 -> SteamVR:
 * - Cross (X) -> Button A
 * - Circle -> Button B
 * - Square -> Button X
 * - Triangle -> Button Y
 * - L1/R1 -> Grip
 * - L2/R2 -> Trigger
 * - Left Stick -> Trackpad X/Y
 * - Share -> Capture
 * - Options -> Menu
 * - PS -> System
 *
 * Los eventos se envían por la red UDP para que SteamVR los interprete.
 */
class GamepadHandler(private val context: Context) {

    companion object {
        private const val TAG = "GamepadHandler"

        // Mascaras de botones PS4 (bit positions)
        const val PS4_CROSS    = 0x0001
        const val PS4_CIRCLE   = 0x0002
        const val PS4_SQUARE   = 0x0004
        const val PS4_TRIANGLE = 0x0008
        const val PS4_L1       = 0x0010
        const val PS4_R1       = 0x0020
        const val PS4_L2       = 0x0040
        const val PS4_R2       = 0x0080
        const val PS4_OPTIONS  = 0x0100
        const val PS4_SHARE    = 0x0200
        const val PS4_L3       = 0x0400
        const val PS4_R3       = 0x0800
        const val PS4_PS       = 0x1000
        const val PS4_TOUCHPAD = 0x2000
    }

    // Estado actual del gamepad
    private var buttonState = 0
    private var leftStickX = 0f
    private var leftStickY = 0f
    private var rightStickX = 0f
    private var rightStickY = 0f
    private var leftTrigger = 0f
    private var rightTrigger = 0f

    // Network client para enviar datos
    private var networkClient: NetworkClient? = null

    // Callback de estado
    var onGamepadStateChanged: ((Int, Float, Float, Float) -> Unit)? = null

    /**
     * Configura el network client para enviar eventos de gamepad.
     */
    fun setNetworkClient(client: NetworkClient) {
        networkClient = client
    }

    /**
     * Procesa un evento de movimiento (MotionEvent) del gamepad.
     * Maneja los sticks analógicos y triggers.
     */
    fun onMotionEvent(event: MotionEvent) {
        when (event.source and InputDevice.SOURCE_CLASS_MASK) {
            InputDevice.SOURCE_CLASS_JOYSTICK -> {
                // Sticks analógicos
                val xAxis = event.getAxisValue(MotionEvent.AXIS_X)
                val yAxis = event.getAxisValue(MotionEvent.AXIS_Y)
                val zAxis = event.getAxisValue(MotionEvent.AXIS_Z)
                val rzAxis = event.getAxisValue(MotionEvent.AXIS_RZ)

                // Left stick (X, Y)
                leftStickX = xAxis
                leftStickY = yAxis

                // Right stick (Z, RZ)
                rightStickX = zAxis
                rightStickY = rzAxis

                // Triggers (L2, R2)
                leftTrigger = event.getAxisValue(MotionEvent.AXIS_LTRIGGER)
                rightTrigger = event.getAxisValue(MotionEvent.AXIS_RTRIGGER)

                // Normalizar triggers a 0-1
                if (leftTrigger < 0) leftTrigger = 0f
                if (rightTrigger < 0) rightTrigger = 0f

                // Enviar datos actualizados
                sendGamepadData()
            }
        }
    }

    /**
     * Procesa un evento de teclado (KeyEvent) del gamepad.
     * Maneja los botones digitales.
     */
    fun onKeyEvent(event: KeyEvent): Boolean {
        val keyCode = event.keyCode
        val isPressed = event.action == KeyEvent.ACTION_DOWN

        when (keyCode) {
            // Botones PS4
            KeyEvent.KEYCODE_BUTTON_A -> updateButton(PS4_CROSS, isPressed)      // Cross
            KeyEvent.KEYCODE_BUTTON_B -> updateButton(PS4_CIRCLE, isPressed)     // Circle
            KeyEvent.KEYCODE_BUTTON_X -> updateButton(PS4_SQUARE, isPressed)     // Square
            KeyEvent.KEYCODE_BUTTON_Y -> updateButton(PS4_TRIANGLE, isPressed)   // Triangle

            // Triggers digitales
            KeyEvent.KEYCODE_BUTTON_L1 -> updateButton(PS4_L1, isPressed)
            KeyEvent.KEYCODE_BUTTON_R1 -> updateButton(PS4_R1, isPressed)

            // Menu buttons
            KeyEvent.KEYCODE_BUTTON_START -> updateButton(PS4_OPTIONS, isPressed)
            KeyEvent.KEYCODE_BUTTON_SELECT -> updateButton(PS4_SHARE, isPressed)

            // PS button
            KeyEvent.KEYCODE_BUTTON_MODE -> updateButton(PS4_PS, isPressed)

            // Sticks (click)
            KeyEvent.KEYCODE_BUTTON_THUMBL -> updateButton(PS4_L3, isPressed)
            KeyEvent.KEYCODE_BUTTON_THUMBR -> updateButton(PS4_R3, isPressed)

            // Touchpad
            KeyEvent.KEYCODE_BUTTON_START -> updateButton(PS4_TOUCHPAD, isPressed)

            else -> return false
        }

        return true
    }

    /**
     * Actualiza el estado de un botón y envía el evento.
     */
    private fun updateButton(mask: Int, pressed: Boolean) {
        if (pressed) {
            buttonState = buttonState or mask
        } else {
            buttonState = buttonState and mask.inv()
        }

        sendGamepadData()
    }

    /**
     * Envía el estado actual del gamepad por la red.
     */
    private fun sendGamepadData() {
        val client = networkClient ?: return

        // Usar el stick izquierdo para el trigger promedio
        val avgTrigger = (leftTrigger + rightTrigger) / 2f

        client.sendGamepadEvent(
            buttons = buttonState,
            xAxis = leftStickX,
            yAxis = leftStickY,
            trigger = avgTrigger
        )

        onGamepadStateChanged?.invoke(buttonState, leftStickX, leftStickY, avgTrigger)
    }

    /**
     * Limpia el estado del gamepad.
     */
    fun reset() {
        buttonState = 0
        leftStickX = 0f
        leftStickY = 0f
        rightStickX = 0f
        rightStickY = 0f
        leftTrigger = 0f
        rightTrigger = 0f
    }

    /**
     * Retorna el estado actual formateado para debugging.
     */
    fun getStateDebug(): String {
        return buildString {
            append("Buttons: 0x${buttonState.toString(16).uppercase()}")
            append(" | LStick: (${String.format("%.2f", leftStickX)}, ${String.format("%.2f", leftStickY)})")
            append(" | RStick: (${String.format("%.2f", rightStickX)}, ${String.format("%.2f", rightStickY)})")
            append(" | L2: ${String.format("%.2f", leftTrigger)}")
            append(" | R2: ${String.format("%.2f", rightTrigger)}")
        }
    }
}
