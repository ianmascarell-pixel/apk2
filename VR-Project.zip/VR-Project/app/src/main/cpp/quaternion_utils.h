#ifndef VR_QUATERNION_UTILS_H
#define VR_QUATERNION_UTILS_H

#include <cmath>
#include <cstring>

/**
 * Utilidades de cuaternion para procesamiento de orientación VR.
 * Incluye conversión, interpolación y operaciones de rotación.
 */

struct Quaternion {
    float w, x, y, z;

    Quaternion() : w(1.0f), x(0.0f), y(0.0f), z(0.0f) {}
    Quaternion(float w, float x, float y, float z) : w(w), x(x), y(y), z(z) {}

    // Normalizar el cuaternion
    Quaternion normalized() const {
        float len = std::sqrt(w * w + x * x + y * y + z * z);
        if (len < 0.0001f) return Quaternion();
        return Quaternion(w / len, x / len, y / len, z / len);
    }

    // Conjugado (inverso para cuaterniones unitarios)
    Quaternion conjugate() const {
        return Quaternion(w, -x, -y, -z);
    }

    // Multiplicación de cuaterniones
    Quaternion operator*(const Quaternion& q) const {
        return Quaternion(
            w * q.w - x * q.x - y * q.y - z * q.z,
            w * q.x + x * q.w + y * q.z - z * q.y,
            w * q.y - x * q.z + y * q.w + z * q.x,
            w * q.z + x * q.y - y * q.x + z * q.w
        );
    }

    // Convertir a ángulos de Euler (grados)
    void toEuler(float& roll, float& pitch, float& yaw) const {
        // Roll (X)
        float sinr_cosp = 2.0f * (w * x + y * z);
        float cosr_cosp = 1.0f - 2.0f * (x * x + y * y);
        roll = std::atan2(sinr_cosp, cosr_cosp) * 180.0f / M_PI;

        // Pitch (Y)
        float sinp = 2.0f * (w * y - z * x);
        if (std::abs(sinp) >= 1.0f) {
            pitch = std::copysign(90.0f, sinp);
        } else {
            pitch = std::asin(sinp) * 180.0f / M_PI;
        }

        // Yaw (Z)
        float siny_cosp = 2.0f * (w * z + x * y);
        float cosy_cosp = 1.0f - 2.0f * (y * y + z * z);
        yaw = std::atan2(siny_cosp, cosy_cosp) * 180.0f / M_PI;
    }

    // Interpolación lineal (LERP)
    static Quaternion lerp(const Quaternion& a, const Quaternion& b, float t) {
        Quaternion result;
        result.w = a.w + (b.w - a.w) * t;
        result.x = a.x + (b.x - a.x) * t;
        result.y = a.y + (b.y - a.y) * t;
        result.z = a.z + (b.z - a.z) * t;
        return result.normalized();
    }

    // Spherical Linear Interpolation (SLERP) - más suave que LERP
    static Quaternion slerp(const Quaternion& a, const Quaternion& b, float t) {
        float dot = a.w * b.w + a.x * b.x + a.y * b.y + a.z * b.z;

        Quaternion b_adj = b;
        if (dot < 0.0f) {
            dot = -dot;
            b_adj = Quaternion(-b.w, -b.x, -b.y, -b.z);
        }

        if (dot > 0.9995f) {
            return lerp(a, b_adj, t);
        }

        float theta = std::acos(dot);
        float sinTheta = std::sin(theta);
        float wa = std::sin((1.0f - t) * theta) / sinTheta;
        float wb = std::sin(t * theta) / sinTheta;

        return Quaternion(
            a.w * wa + b_adj.w * wb,
            a.x * wa + b_adj.x * wb,
            a.y * wa + b_adj.y * wb,
            a.z * wa + b_adj.z * wb
        );
    }

    // Convertir desde arrays de float (para JNI)
    static Quaternion fromFloatArray(const float* arr) {
        return Quaternion(arr[0], arr[1], arr[2], arr[3]);
    }

    // Convertir a array de float (para enviar por red)
    void toFloatArray(float* arr) const {
        arr[0] = w;
        arr[1] = x;
        arr[2] = y;
        arr[3] = z;
    }
};

/**
 * Filtrado complementario para combinar giroscopio y acelerómetro.
 * El giroscopio es preciso a corto plazo pero derive.
 * El acelerómetro es estable a largo plazo pero ruidoso.
 */
class ComplementaryFilter {
public:
    ComplementaryFilter(float alpha = 0.98f) : alpha_(alpha), initialized_(false) {}

    Quaternion update(float gx, float gy, float gz, float ax, float ay, float az, float dt) {
        if (!initialized_) {
            // Primera lectura: inicializar con el acelerómetro
            float roll = std::atan2(ay, az);
            float pitch = std::atan2(-ax, std::sqrt(ay * ay + az * az));

            current_ = Quaternion(
                std::cos(roll / 2) * std::cos(pitch / 2),
                std::sin(roll / 2) * std::cos(pitch / 2),
                std::cos(roll / 2) * std::sin(pitch / 2),
                -std::sin(roll / 2) * std::sin(pitch / 2)
            );
            initialized_ = true;
            return current_;
        }

        // Integración del giroscopio
        Quaternion gyroQ(
            1.0f,
            gx * dt * 0.5f,
            gy * dt * 0.5f,
            gz * dt * 0.5f
        );
        Quaternion gyroIntegrated = current_ * gyroQ;

        // Orientación estimada por el acelerómetro
        float roll = std::atan2(ay, az);
        float pitch = std::atan2(-ax, std::sqrt(ay * ay + az * az));
        Quaternion accelEstimate(
            std::cos(roll / 2) * std::cos(pitch / 2),
            std::sin(roll / 2) * std::cos(pitch / 2),
            std::cos(roll / 2) * std::sin(pitch / 2),
            -std::sin(roll / 2) * std::sin(pitch / 2)
        );

        // Mezclar ambas estimaciones (filtro complementario)
        current_ = Quaternion::slerp(gyroIntegrated, accelEstimate, 1.0f - alpha_);

        return current_.normalized();
    }

private:
    float alpha_;
    bool initialized_;
    Quaternion current_;
};

#endif // VR_QUATERNION_UTILS_H
