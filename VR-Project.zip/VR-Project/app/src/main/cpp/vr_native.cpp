#include <jni.h>
#include <android/log.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <GLES2/gl2.h>

#include "quaternion_utils.h"
#include "network_udp.h"

#define LOG_TAG "VRNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

/**
 * Punto de entrada JNI para el código nativo del visor VR.
 *
 * Proporciona acceso nativo para:
 * - Procesamiento de cuaterniones con filtro complementario
 * - Red UDP de baja latencia
 * - Renderizado OpenGL ES de bajo nivel
 */

static NetworkUDP g_network;
static ComplementaryFilter g_filter(0.98f);
static Quaternion g_currentOrientation;

// Variables de callback JNI
static JavaVM* g_jvm = nullptr;
static jobject g_callback_obj = nullptr;
static jmethodID g_on_orientation_method = nullptr;
static jmethodID g_on_connected_method = nullptr;

// ==================== INICIALIZACIÓN ====================

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    g_jvm = vm;
    LOGI("VR Native library loaded");
    return JNI_VERSION_1_6;
}

extern "C" JNIEXPORT void JNICALL
Java_com_vrstream_client_VrActivity_nativeInit(
    JNIEnv* env,
    jobject thiz) {
    LOGI("Initializing VR native subsystem");
}

// ==================== CUATERNIONES ====================

extern "C" JNIEXPORT void JNICALL
Java_com_vrstream_client_sensor_SensorController_nativeUpdateOrientation(
    JNIEnv* env,
    jobject thiz,
    jfloat w, jfloat x, jfloat y, jfloat z) {
    g_currentOrientation = Quaternion(w, x, y, z);
}

extern "C" JNIEXPORT void JNICALL
Java_com_vrstream_client_sensor_SensorController_nativeUpdateGyro(
    JNIEnv* env,
    jobject thiz,
    jfloat gx, jfloat gy, jfloat gz,
    jfloat ax, jfloat ay, jfloat az,
    jfloat dt) {
    // Aplicar filtro complementario
    g_currentOrientation = g_filter.update(gx, gy, gz, ax, ay, az, dt);
}

extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_vrstream_client_sensor_SensorController_nativeGetQuaternion(
    JNIEnv* env,
    jobject thiz) {
    jfloatArray result = env->NewFloatArray(4);
    float quat[4];
    g_currentOrientation.toFloatArray(quat);
    env->SetFloatArrayRegion(result, 0, 4, quat);
    return result;
}

extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_vrstream_client_sensor_SensorController_nativeGetEuler(
    JNIEnv* env,
    jobject thiz) {
    float roll, pitch, yaw;
    g_currentOrientation.toEuler(roll, pitch, yaw);

    jfloatArray result = env->NewFloatArray(3);
    float euler[3] = { roll, pitch, yaw };
    env->SetFloatArrayRegion(result, 0, 3, euler);
    return result;
}

extern "C" JNIEXPORT void JNICALL
Java_com_vrstream_client_sensor_SensorController_nativeSetFilterAlpha(
    JNIEnv* env,
    jobject thiz,
    jfloat alpha) {
    g_filter = ComplementaryFilter(alpha);
    LOGI("Filter alpha set to %.2f", alpha);
}

// ==================== RED UDP ====================

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vrstream_client_network_NetworkClient_nativeConnect(
    JNIEnv* env,
    jobject thiz,
    jstring ip,
    jint port) {
    const char* ipStr = env->GetStringUTFChars(ip, nullptr);
    bool result = g_network.connect(ipStr, port);
    env->ReleaseStringUTFChars(ip, ipStr);

    LOGI("Connecting to %s:%d - %s", ipStr, port, result ? "OK" : "FAILED");
    return result ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_vrstream_client_network_NetworkClient_nativeDisconnect(
    JNIEnv* env,
    jobject thiz) {
    g_network.disconnect();
    LOGI("Disconnected");
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vrstream_client_network_NetworkClient_nativeSendOrientation(
    JNIEnv* env,
    jobject thiz,
    jfloatArray quaternion) {
    jfloat* quat = env->GetFloatArrayElements(quaternion, nullptr);
    bool result = g_network.sendOrientation(quat[0], quat[1], quat[2], quat[3]);
    env->ReleaseFloatArrayElements(quaternion, quat, JNI_ABORT);
    return result ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vrstream_client_network_NetworkClient_nativeSendHandData(
    JNIEnv* env,
    jobject thiz,
    jboolean isPinching,
    jfloat pinchStrength,
    jfloatArray handCenter,
    jfloatArray rayDirection) {
    jfloat* center = env->GetFloatArrayElements(handCenter, nullptr);
    jfloat* ray = env->GetFloatArrayElements(rayDirection, nullptr);

    bool result = g_network.sendHandData(
        isPinching == JNI_TRUE,
        pinchStrength,
        center[0], center[1], center[2],
        ray[0], ray[1], ray[2]
    );

    env->ReleaseFloatArrayElements(handCenter, center, JNI_ABORT);
    env->ReleaseFloatArrayElements(rayDirection, ray, JNI_ABORT);

    return result ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vrstream_client_network_NetworkClient_nativeSendGamepad(
    JNIEnv* env,
    jobject thiz,
    jint buttons,
    jfloat xAxis,
    jfloat yAxis,
    jfloat trigger) {
    return g_network.sendGamepad(buttons, xAxis, yAxis, trigger) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vrstream_client_network_NetworkClient_nativeIsConnected(
    JNIEnv* env,
    jobject thiz) {
    return g_network.isConnected() ? JNI_TRUE : JNI_FALSE;
}

// ==================== RENDERizado OpenGL ====================

extern "C" JNIEXPORT void JNICALL
Java_com_vrstream_client_ui_VrRenderer_nativeRenderFrame(
    JNIEnv* env,
    jobject thiz,
    jfloatArray viewMatrix,
    jfloatArray projMatrix) {
    // Placeholder para renderizado nativo de bajo nivel
    // El renderizado principal se hace en Kotlin/Java con GLSurfaceView
}

extern "C" JNIEXPORT void JNICALL
Java_com_vrstream_client_ui_VrRenderer_nativeSetViewports(
    JNIEnv* env,
    jobject thiz,
    jint leftX, jint leftY, jint leftW, jint leftH,
    jint rightX, jint rightY, jint rightW, jint rightH) {
    // Configurar viewports para modo SBS
    glViewport(leftX, leftY, leftW, leftH);
}
