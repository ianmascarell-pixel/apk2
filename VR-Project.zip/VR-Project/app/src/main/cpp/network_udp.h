#ifndef VR_NETWORK_UDP_H
#define VR_NETWORK_UDP_H

#include <cstring>
#include <cstdint>
#include <atomic>

#ifdef __ANDROID__
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#else
// Windows/SteamVR driver
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")
#endif

/**
 * Cliente UDP de baja latencia para comunicación con el driver de SteamVR.
 * Optimizado para minimal overhead en cada paquete.
 */

// Protocolo de mensajes
enum MessageType : uint8_t {
    MSG_ORIENTATION = 0x01,
    MSG_HAND_DATA   = 0x02,
    MSG_GAMEPAD     = 0x03,
    MSG_PING        = 0x04,
    MSG_PONG        = 0x05,
    MSG_CONNECT     = 0x10,
    MSG_DISCONNECT  = 0x11,
};

struct NetworkPacket {
    uint8_t type;
    uint8_t data[1020];
    int length;
};

class NetworkUDP {
public:
    NetworkUDP() : socket_(-1), connected_(false) {}

    ~NetworkUDP() {
        disconnect();
    }

    /**
     * Inicializa el socket UDP y se conecta al servidor.
     */
    bool connect(const char* ip, uint16_t port) {
#ifdef __ANDROID__
        socket_ = socket(AF_INET, SOCK_DGRAM, 0);
        if (socket_ < 0) return false;

        // Configurar timeout no bloqueante
        struct timeval tv;
        tv.tv_sec = 0;
        tv.tv_usec = 100000; // 100ms
        setsockopt(socket_, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
#else
        WSADATA wsaData;
        if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) return false;

        socket_ = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (socket_ == INVALID_SOCKET) return false;
#endif

        memset(&server_addr_, 0, sizeof(server_addr_));
        server_addr_.sin_family = AF_INET;
        server_addr_.sin_port = htons(port);

        if (inet_pton(AF_INET, ip, &server_addr_.sin_addr) <= 0) {
            disconnect();
            return false;
        }

        // Enviar mensaje de conexión
        uint8_t connectMsg[] = { MSG_CONNECT, 0x00 };
        sendRaw(connectMsg, 2);

        connected_ = true;
        return true;
    }

    /**
     * Desconecta el socket.
     */
    void disconnect() {
        if (connected_) {
            uint8_t disconnectMsg[] = { MSG_DISCONNECT, 0x00 };
            sendRaw(disconnectMsg, 2);
        }

#ifdef __ANDROID__
        if (socket_ >= 0) {
            close(socket_);
            socket_ = -1;
        }
#else
        if (socket_ != INVALID_SOCKET) {
            closesocket(socket_);
            socket_ = INVALID_SOCKET;
        }
        WSACleanup();
#endif

        connected_ = false;
    }

    /**
     * Envía un paquete UDP al servidor.
     */
    bool sendRaw(const uint8_t* data, int length) {
        if (!connected_) return false;

        ssize_t sent = sendto(
            socket_,
            reinterpret_cast<const char*>(data),
            length,
            0,
            reinterpret_cast<struct sockaddr*>(&server_addr_),
            sizeof(server_addr_)
        );

        return sent == length;
    }

    /**
     * Envía orientación (cuaternion) al servidor.
     */
    bool sendOrientation(float w, float x, float y, float z) {
        uint8_t packet[17]; // 1 (type) + 16 (4 floats)
        packet[0] = MSG_ORIENTATION;

        memcpy(packet + 1, &w, 4);
        memcpy(packet + 5, &x, 4);
        memcpy(packet + 9, &y, 4);
        memcpy(packet + 13, &z, 4);

        return sendRaw(packet, 17);
    }

    /**
     * Envía datos de hand tracking al servidor.
     */
    bool sendHandData(bool isPinching, float pinchStrength,
                      float handCenterX, float handCenterY, float handCenterZ,
                      float rayDirX, float rayDirY, float rayDirZ) {
        uint8_t packet[29]; // 1 (type) + 1 + 4 + 9 + 9
        int offset = 0;

        packet[offset++] = MSG_HAND_DATA;
        packet[offset++] = isPinching ? 1 : 0;

        memcpy(packet + offset, &pinchStrength, 4); offset += 4;
        memcpy(packet + offset, &handCenterX, 4); offset += 4;
        memcpy(packet + offset, &handCenterY, 4); offset += 4;
        memcpy(packet + offset, &handCenterZ, 4); offset += 4;
        memcpy(packet + offset, &rayDirX, 4); offset += 4;
        memcpy(packet + offset, &rayDirY, 4); offset += 4;
        memcpy(packet + offset, &rayDirZ, 4); offset += 4;

        return sendRaw(packet, offset);
    }

    /**
     * Envía eventos de gamepad al servidor.
     */
    bool sendGamepad(int32_t buttons, float xAxis, float yAxis, float trigger) {
        uint8_t packet[17]; // 1 (type) + 4 + 4 + 4 + 4
        int offset = 0;

        packet[offset++] = MSG_GAMEPAD;
        memcpy(packet + offset, &buttons, 4); offset += 4;
        memcpy(packet + offset, &xAxis, 4); offset += 4;
        memcpy(packet + offset, &yAxis, 4); offset += 4;
        memcpy(packet + offset, &trigger, 4); offset += 4;

        return sendRaw(packet, offset);
    }

    /**
     * Recibe un paquete del servidor (con timeout).
     * Retorna el número de bytes recibidos o -1 si hay error/timeout.
     */
    int receive(NetworkPacket& packet) {
        if (!connected_) return -1;

        uint8_t buffer[1024];
        struct sockaddr_in from;
        socklen_t fromLen = sizeof(from);

        ssize_t received = recvfrom(
            socket_,
            reinterpret_cast<char*>(buffer),
            sizeof(buffer),
            0,
            reinterpret_cast<struct sockaddr*>(&from),
            &fromLen
        );

        if (received <= 0) return -1;

        packet.type = buffer[0];
        packet.length = received - 1;
        if (packet.length > 0) {
            memcpy(packet.data, buffer + 1, packet.length);
        }

        return received;
    }

    bool isConnected() const { return connected_; }

private:
#ifdef __ANDROID__
    int socket_;
#else
    SOCKET socket_;
#endif

    struct sockaddr_in server_addr_;
    std::atomic<bool> connected_;
};

#endif // VR_NETWORK_UDP_H
