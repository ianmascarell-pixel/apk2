#ifndef VRSTREAM_NETWORK_RECEIVER_H
#define VRSTREAM_NETWORK_RECEIVER_H

#include "driver_main.h"
#include <thread>
#include <atomic>
#include <mutex>
#include <cstring>

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")
#endif

/**
 * Receptor UDP de alta frecuencia para el driver de SteamVR.
 *
 * Escucha en un puerto UDP y procesa mensajes del teléfono Android:
 * - MSG_ORIENTATION: Cuaterniones de orientación (3DOF)
 * - MSG_HAND_DATA: Datos de hand tracking
 * - MSG_GAMEPAD: Eventos de gamepad PS4
 * - MSG_PING/MSG_PONG: Latencia
 *
 * Usa doble buffer para evitar race conditions entre el hilo
 * de red y el hilo principal de SteamVR (RunFrame).
 */
class NetworkReceiver {
public:
    NetworkReceiver(uint16_t port)
        : port_(port),
          socket_(INVALID_SOCKET),
          isRunning_(false),
          latestOrientation_({1.0f, 0.0f, 0.0f, 0.0f, 0}),
          latestHandLeft_({false, 0.0f, {0,0,0}, {0,0,-1}, false, 0}),
          latestHandRight_({false, 0.0f, {0,0,0}, {0,0,-1}, false, 0}),
          latestGamepad_({0, 0, 0, 0, 0}),
          packetCount_(0),
          lastPacketTime_(0) {
    }

    ~NetworkReceiver() {
        stop();
    }

    /**
     * Inicia el socket UDP y el hilo de recepción.
     */
    bool start() {
        // Inicializar Winsock
        WSADATA wsaData;
        if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
            DriverLog("Failed to initialize Winsock");
            return false;
        }

        // Crear socket UDP
        socket_ = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (socket_ == INVALID_SOCKET) {
            DriverLog("Failed to create UDP socket");
            WSACleanup();
            return false;
        }

        // Configurar socket no bloqueante
        u_long mode = 1;
        ioctlsocket(socket_, FIONBIO, &mode);

        // Bind al puerto
        struct sockaddr_in serverAddr;
        memset(&serverAddr, 0, sizeof(serverAddr));
        serverAddr.sin_family = AF_INET;
        serverAddr.sin_addr.s_addr = INADDR_ANY;
        serverAddr.sin_port = htons(port_);

        if (bind(socket_, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
            DriverLog("Failed to bind UDP socket");
            closesocket(socket_);
            WSACleanup();
            return false;
        }

        // Iniciar hilo de recepción
        isRunning_ = true;
        receiveThread_ = std::thread(&NetworkReceiver::receiveLoop, this);

        char logMsg[128];
        snprintf(logMsg, sizeof(logMsg), "Network receiver started on port %d", port_);
        DriverLog(logMsg);

        return true;
    }

    /**
     * Detiene el receptor y libera recursos.
     */
    void stop() {
        isRunning_ = false;

        if (receiveThread_.joinable()) {
            receiveThread_.join();
        }

        if (socket_ != INVALID_SOCKET) {
            closesocket(socket_);
            socket_ = INVALID_SOCKET;
        }

        WSACleanup();
    }

    /**
     * Obtiene la orientación más reciente (thread-safe).
     */
    bool getLatestOrientation(SharedOrientation& out) {
        std::lock_guard<std::mutex> lock(orientationMutex_);
        if (lastOrientationTime_ == 0) return false;
        out = latestOrientation_;
        return true;
    }

    /**
     * Obtiene los datos de ambas manos (thread-safe).
     */
    void getLatestHandData(SharedHandData& left, SharedHandData& right) {
        std::lock_guard<std::mutex> lock(handMutex_);
        left = latestHandLeft_;
        right = latestHandRight_;
    }

    /**
     * Obtiene los datos del gamepad (thread-safe).
     */
    bool getLatestGamepad(SharedGamepadData& out) {
        std::lock_guard<std::mutex> lock(gamepadMutex_);
        if (lastGamepadTime_ == 0) return false;
        out = latestGamepad_;
        return true;
    }

    /**
     * Retorna el número total de paquetes recibidos.
     */
    uint64_t getPacketCount() const { return packetCount_; }

private:
    uint16_t port_;
    SOCKET socket_;
    std::atomic<bool> isRunning_;
    std::thread receiveThread_;

    // Buffer de orientación (doble buffer con mutex)
    SharedOrientation latestOrientation_;
    uint64_t lastOrientationTime_ = 0;
    std::mutex orientationMutex_;

    // Buffer de manos
    SharedHandData latestHandLeft_;
    SharedHandData latestHandRight_;
    std::mutex handMutex_;

    // Buffer de gamepad
    SharedGamepadData latestGamepad_;
    uint64_t lastGamepadTime_ = 0;
    std::mutex gamepadMutex_;

    // Estadísticas
    std::atomic<uint64_t> packetCount_;
    uint64_t lastPacketTime_;

    /**
     * Hilo principal de recepción de paquetes UDP.
     * Procesa mensajes en tiempo real con mínimo overhead.
     */
    void receiveLoop() {
        uint8_t buffer[1024];
        struct sockaddr_in clientAddr;
        int clientAddrLen = sizeof(clientAddr);

        while (isRunning_) {
            int received = recvfrom(
                socket_,
                reinterpret_cast<char*>(buffer),
                sizeof(buffer),
                0,
                (struct sockaddr*)&clientAddr,
                &clientAddrLen
            );

            if (received <= 0) {
                // Timeout o error, continuar
                if (WSAGetLastError() == WSAEWOULDBLOCK) {
                    std::this_thread::sleep_for(std::chrono::microseconds(100));
                    continue;
                }
                continue;
            }

            packetCount_++;
            processPacket(buffer, received);
        }
    }

    /**
     * Procesa un paquete recibido según su tipo de mensaje.
     */
    void processPacket(const uint8_t* data, int length) {
        if (length < 1) return;

        uint8_t messageType = data[0];

        switch (messageType) {
            case MSG_ORIENTATION:
                processOrientation(data + 1, length - 1);
                break;

            case MSG_HAND_DATA:
                processHandData(data + 1, length - 1);
                break;

            case MSG_GAMEPAD:
                processGamepad(data + 1, length - 1);
                break;

            case MSG_PING:
                processPing(data + 1, length - 1);
                break;

            case MSG_CONNECT:
                DriverLog("Client connected");
                break;

            case MSG_DISCONNECT:
                DriverLog("Client disconnected");
                break;

            default:
                break;
        }
    }

    /**
     * Procesa un paquete de orientación (cuaternion).
     * Formato: [w(4bytes), x(4bytes), y(4bytes), z(4bytes)]
     */
    void processOrientation(const uint8_t* data, int length) {
        if (length < 16) return;  // 4 floats * 4 bytes

        SharedOrientation orientation;
        memcpy(&orientation.w, data, 4);
        memcpy(&orientation.x, data + 4, 4);
        memcpy(&orientation.y, data + 8, 4);
        memcpy(&orientation.z, data + 12, 4);
        orientation.timestamp_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::steady_clock::now().time_since_epoch()
        ).count();

        // Normalizar el cuaternion para evitar issues
        float len = sqrt(orientation.w * orientation.w +
                        orientation.x * orientation.x +
                        orientation.y * orientation.y +
                        orientation.z * orientation.z);

        if (len > 0.0001f) {
            orientation.w /= len;
            orientation.x /= len;
            orientation.y /= len;
            orientation.z /= len;
        }

        std::lock_guard<std::mutex> lock(orientationMutex_);
        latestOrientation_ = orientation;
        lastOrientationTime_ = orientation.timestamp_ns;
    }

    /**
     * Procesa un paquete de hand tracking.
     * Formato: [isPinching(1), pinchStrength(4), handCenter(12), rayDirection(12)]
     */
    void processHandData(const uint8_t* data, int length) {
        if (length < 29) return;  // 1 + 4 + 12 + 12

        SharedHandData handData;
        int offset = 0;

        handData.isPinching = data[offset++] != 0;
        memcpy(&handData.pinchStrength, data + offset, 4); offset += 4;
        memcpy(handData.handCenter, data + offset, 12); offset += 12;
        memcpy(handData.rayDirection, data + offset, 12); offset += 12;

        handData.isActive = true;
        handData.timestamp_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::steady_clock::now().time_since_epoch()
        ).count();

        std::lock_guard<std::mutex> lock(handMutex_);
        latestHandLeft_ = handData;  // Por simplificación, asignar a ambas manos
        latestHandRight_ = handData;
    }

    /**
     * Procesa un paquete de gamepad.
     * Formato: [buttons(4), xAxis(4), yAxis(4), trigger(4)]
     */
    void processGamepad(const uint8_t* data, int length) {
        if (length < 16) return;  // 4 * 4 bytes

        SharedGamepadData gamepad;
        int offset = 0;

        memcpy(&gamepad.buttons, data + offset, 4); offset += 4;
        memcpy(&gamepad.xAxis, data + offset, 4); offset += 4;
        memcpy(&gamepad.yAxis, data + offset, 4); offset += 4;
        memcpy(&gamepad.trigger, data + offset, 4); offset += 4;

        gamepad.timestamp_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::steady_clock::now().time_since_epoch()
        ).count();

        std::lock_guard<std::mutex> lock(gamepadMutex_);
        latestGamepad_ = gamepad;
        lastGamepadTime_ = gamepad.timestamp_ns;
    }

    /**
     * Procesa un ping y responde con pong.
     */
    void processPing(const uint8_t* data, int length) {
        if (length < 8) return;

        // Responder con el mismo timestamp (PONG)
        uint8_t pong[9];
        pong[0] = MSG_PONG;
        memcpy(pong + 1, data, 8);

        sendto(socket_,
               reinterpret_cast<const char*>(pong),
               sizeof(pong),
               0,
               nullptr,
               0);
    }
};

#endif // VRSTREAM_NETWORK_RECEIVER_H
