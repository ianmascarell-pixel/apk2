#ifndef VRSTREAM_DRIVER_MAIN_H
#define VRSTREAM_DRIVER_MAIN_H

#include <openvr/openvr_driver.h>
#include <string>
#include <atomic>
#include <thread>
#include <mutex>
#include <queue>

/**
 * VR Stream - Driver de SteamVR
 *
 * Este driver de OpenVR registra un HMD virtual y dos controladores virtuales.
 * Recibe datos del teléfono Android por UDP y los traduce a OpenVR.
 *
 * Flujo de datos:
 * 1. El teléfono envía cuaterniones de orientación (3DOF) por UDP
 * 2. El driver los recibe en el hilo de red
 * 3. Los procesa y actualiza el estado del HMD virtual
 * 4. SteamVR consulta el estado y lo refleja en la composición
 */

// ==================== PROTOCOLO ====================

enum DriverMessageType : uint8_t {
    MSG_ORIENTATION = 0x01,
    MSG_HAND_DATA   = 0x02,
    MSG_GAMEPAD     = 0x03,
    MSG_PING        = 0x04,
    MSG_PONG        = 0x05,
    MSG_CONNECT     = 0x10,
    MSG_DISCONNECT  = 0x11,
};

// ==================== DATOS COMPARTIDOS ====================

struct SharedOrientation {
    float w = 1.0f;
    float x = 0.0f;
    float y = 0.0f;
    float z = 0.0f;
    uint64_t timestamp_ns = 0;
};

struct SharedHandData {
    bool isPinching = false;
    float pinchStrength = 0.0f;
    float handCenter[3] = { 0.0f, 0.0f, 0.0f };
    float rayDirection[3] = { 0.0f, 0.0f, -1.0f };
    bool isActive = false;
    uint64_t timestamp_ns = 0;
};

struct SharedGamepadData {
    int32_t buttons = 0;
    float xAxis = 0.0f;
    float yAxis = 0.0f;
    float trigger = 0.0f;
    uint64_t timestamp_ns = 0;
};

struct DriverSettings {
    uint16_t listenPort = 9999;
    float ipd = 0.063f;  // 63mm default
    int refreshRate = 90;
    bool useHandTracking = true;
};

// ==================== DECLARACIONES ====================

class VRStreamProvider;
class VRStreamHmd;
class VRStreamController;

// Exportar providers
extern "C" __declspec(dllexport)
void* HmdDriverFactory(const char* interfaceName, int* returnCode);

#endif // VRSTREAM_DRIVER_MAIN_H
