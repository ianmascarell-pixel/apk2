#ifndef VRSTREAM_HMD_DEVICE_H
#define VRSTREAM_HMD_DEVICE_H

#include "driver_main.h"
#include <openvr/openvr_driver.h>
#include <string>
#include <cmath>

/**
 * HMD Virtual - Implementa un visor VR fictivo que recibe
 * la orientación del teléfono Android.
 *
 * Registra ante SteamVR como un HMD genérico 3DOF
 * y actualiza su rotación en tiempo real.
 */
class VRStreamHmd : public vr::ITrackedDeviceServerDriver {
public:
    VRStreamHmd(const DriverSettings& settings)
        : settings_(settings),
          deviceIndex_(vr::k_unTrackedDeviceIndexInvalid),
          isConnected_(false) {
        memset(&orientation_, 0, sizeof(orientation_));
        orientation_.w = 1.0f;

        memset(&pose_, 0, sizeof(pose_));
        pose_.bDeviceIsConnected = false;
        pose_.bPoseIsValid = false;
        pose_.result = vr::TrackingResult_Uninitialized;

        // Identificador único del dispositivo
        snprintf(serialNumber_, sizeof(serialNumber_), "VRStreamHMD_%d", GetCurrentProcessId());
    }

    virtual ~VRStreamHmd() = default;

    // ==================== ITrackedDeviceServerDriver ====================

    virtual vr::EVRInitError Activate(uint32_t objectID) override {
        deviceIndex_ = objectID;

        vr::PropertyContainerHandle_t container =
            vr::VRProperties()->TrackedDeviceToPropertyContainer(deviceIndex_);

        // Propiedades básicas del HMD
        vr::VRProperties()->SetStringProperty(container,
            vr::Prop_SerialNumber_String, serialNumber_);
        vr::VRProperties()->SetStringProperty(container,
            vr::Prop_ModelNumber_String, "VR Stream Virtual HMD");
        vr::VRProperties()->SetStringProperty(container,
            vr::Prop_ManufacturerName_String, "VR Stream");
        vr::VRProperties()->SetStringProperty(container,
            vr::Prop_TrackingSystemName_String, "VRStream");
        vr::VRProperties()->SetStringProperty(container,
            vr::Prop_AllwirelessSurveyData_WirelessSurveyData, "VRStream");

        // Clase del dispositivo
        vr::VRProperties()->SetInt32Property(container,
            vr::Prop_DeviceClass_Int32,
            vr::TrackedDeviceClass_HMD);

        // Capabilidades: 3DOF (solo rotación, sin posición)
        vr::VRProperties()->SetUint64Property(container,
            vr::Prop_DeviceCaps_Int64,
            0);  // Sin caps especiales por ahora

        // Soporte de pantalla
        vr::VRProperties()->SetStringProperty(container,
            vr::Prop_DisplayDeviceType_String, "VirtualDisplay");

        // Configurar sistema de tracking
        vr::VRProperties()->SetInt32Property(container,
            vr::Prop_ControllerRoleHint_Int32,
            vr::TrackedControllerRole_Invalid);

        DriverLog("VRStream HMD activated");
        return vr::VRInitError_None;
    }

    virtual void Deactivate() override {
        deviceIndex_ = vr::k_unTrackedDeviceIndexInvalid;
        DriverLog("VRStream HMD deactivated");
    }

    virtual void EnterStandby() override {}

    virtual void* GetComponent(const char* componentAndVersion) override {
        return nullptr;
    }

    virtual void DebugRequest(const char* request, char* responseBuffer,
                              uint32_t responseBufferSize) override {
        if (responseBufferSize > 0) {
            responseBuffer[0] = '\0';
        }
    }

    /**
     * Retorna el pose actual del HMD.
     * SteamVR llama a esta función periódicamente para obtener
     * la posición y orientación del visor.
     */
    virtual vr::TrackedDevicePose_t GetPose() override {
        return pose_;
    }

    // ==================== ACTUALIZACIÓN ====================

    /**
     * Actualiza la orientación del HMD con datos del teléfono.
     * Convierte el cuaternion recibido a matrix de rotación de OpenVR.
     */
    void updateOrientation(const SharedOrientation& orientation) {
        orientation_ = orientation;

        // Convertir cuaternion a matrix de rotación
        float q[4] = { orientation.x, orientation.y, orientation.z, orientation.w };
        quaternionToMatrix(q, pose_.mDeviceToAbsoluteTracking.m);

        // Marcar pose como válida
        pose_.bPoseIsValid = true;
        pose_.bDeviceIsConnected = true;
        pose_.result = vr::TrackingResult_Running_OK;

        // Actualizar timestamp
        pose_.ulTimeStamp = orientation.timestamp_ns;
        pose_.ulFrameNumber = frameCount_++;
    }

    /**
     * Marca el dispositivo como conectado/desconectado.
     */
    void setConnected(bool connected) {
        isConnected_ = connected;
        pose_.bDeviceIsConnected = connected;
    }

    const char* getSerialNumber() const { return serialNumber_; }

private:
    DriverSettings settings_;
    uint32_t deviceIndex_;
    char serialNumber_[64];
    bool isConnected_;

    SharedOrientation orientation_;
    vr::TrackedDevicePose_t pose_;
    uint64_t frameCount_ = 0;

    /**
     * Convierte un cuaternion a matrix 3x4 de rotación.
     *
     * Esta conversión es CRÍTICA para que la orientación se muestre
     * correctamente en SteamVR. Un error aquí causa que la vista
     * esté rotada o inclinada incorrectamente.
     */
    void quaternionToMatrix(const float q[4], float matrix[3][4]) {
        float x = q[0], y = q[1], z = q[2], w = q[3];

        float x2 = x * x;
        float y2 = y * y;
        float z2 = z * z;
        float xy = x * y;
        float xz = x * z;
        float yz = y * z;
        float wx = w * x;
        float wy = w * y;
        float wz = w * z;

        matrix[0][0] = 1.0f - 2.0f * (y2 + z2);
        matrix[0][1] = 2.0f * (xy - wz);
        matrix[0][2] = 2.0f * (xz + wy);
        matrix[0][3] = 0.0f;

        matrix[1][0] = 2.0f * (xy + wz);
        matrix[1][1] = 1.0f - 2.0f * (x2 + z2);
        matrix[1][2] = 2.0f * (yz - wx);
        matrix[1][3] = 0.0f;

        matrix[2][0] = 2.0f * (xz - wy);
        matrix[2][1] = 2.0f * (yz + wx);
        matrix[2][2] = 1.0f - 2.0f * (x2 + y2);
        matrix[2][3] = 0.0f;
    }
};

#endif // VRSTREAM_HMD_DEVICE_H
