#ifndef VRSTREAM_CONTROLLER_DEVICE_H
#define VRSTREAM_CONTROLLER_DEVICE_H

#include "driver_main.h"
#include <openvr/openvr_driver.h>
#include <string>
#include <cstring>

/**
 * Controlador Virtual - Simula controladores de mano (izquierda/derecha)
 * usando datos de hand tracking del teléfono o eventos de gamepad.
 *
 * Soporta dos modos de operación:
 * 1. Hand Tracking: Los landmarks de MediaPipe se mapean a la posición
 *    y orientación del controlador virtual.
 * 2. Gamepad: Los botones y sticks del mando PS4 se mapean a los
 *    botones estándar de SteamVR.
 */
class VRStreamController : public vr::ITrackedDeviceServerDriver {
public:
    VRStreamController(const std::string& deviceId,
                       const std::string& displayName,
                       const std::string& deviceClass)
        : deviceId_(deviceId),
          displayName_(displayName),
          deviceClass_(deviceClass),
          deviceIndex_(vr::k_unTrackedDeviceIndexInvalid),
          isActive_(false) {
        memset(&pose_, 0, sizeof(pose_));
        pose_.bDeviceIsConnected = false;
        pose_.bPoseIsValid = false;
        pose_.result = vr::TrackingResult_Uninitialized;
    }

    virtual ~VRStreamController() = default;

    // ==================== ITrackedDeviceServerDriver ====================

    virtual vr::EVRInitError Activate(uint32_t objectID) override {
        deviceIndex_ = objectID;

        vr::PropertyContainerHandle_t container =
            vr::VRProperties()->TrackedDeviceToPropertyContainer(deviceIndex_);

        // Propiedades básicas
        vr::VRProperties()->SetStringProperty(container,
            vr::Prop_SerialNumber_String, deviceId_.c_str());
        vr::VRProperties()->SetStringProperty(container,
            vr::Prop_ModelNumber_String, "VR Stream Controller");
        vr::VRProperties()->SetStringProperty(container,
            vr::Prop_ManufacturerName_String, "VR Stream");
        vr::VRProperties()->SetStringProperty(container,
            vr::Prop_TrackingSystemName_String, "VRStream");

        // Rol del controlador (izquierda/derecha)
        bool isLeft = deviceId_.find("Left") != std::string::npos;
        vr::VRProperties()->SetInt32Property(container,
            vr::Prop_ControllerRoleHint_Int32,
            isLeft ? vr::TrackedControllerRole_LeftHand
                   : vr::TrackedControllerRole_RightHand);

        // Clase del dispositivo
        vr::VRProperties()->SetInt32Property(container,
            vr::Prop_DeviceClass_Int32,
            vr::TrackedDeviceClass_Controller);

        // Iconos de botones (placeholder)
        vr::VRProperties()->SetStringProperty(container,
            vr::Prop_NamedIconPathDeviceOff_String,
            "controllers/vrstream_controller_off.png");
        vr::VRProperties()->SetStringProperty(container,
            vr::Prop_NamedIconPathDeviceSearching_String,
            "controllers/vrstream_controller_searching.png");
        vr::VRProperties()->SetStringProperty(container,
            vr::Prop_NamedIconPathDeviceSearchingAlert_String,
            "controllers/vrstream_controller_searching_alert.png");
        vr::VRProperties()->SetStringProperty(container,
            vr::Prop_NamedIconPathDeviceReady_String,
            "controllers/vrstream_controller_ready.png");
        vr::VRProperties()->SetStringProperty(container,
            vr::Prop_NamedIconPathDeviceReadyAlert_String,
            "controllers/vrstream_controller_ready_alert.png");
        vr::VRProperties()->SetStringProperty(container,
            vr::Prop_NamedIconPathDeviceNotReady_String,
            "controllers/vrstream_controller_off.png");
        vr::VRProperties()->SetStringProperty(container,
            vr::Prop_NamedIconPathDeviceStandby_String,
            "controllers/vrstream_controller_off.png");
        vr::VRProperties()->SetStringProperty(container,
            vr::Prop_NamedIconPathDeviceAlertLow_String,
            "controllers/vrstream_controller_alert_low.png");

        // Componentes del controlador
        vr::VRProperties()->SetStringProperty(container,
            vr::Prop_InputProfilePath_String,
            "{vrstream}/input/profile_vrstream.json");

        // Componente de trigger
        vr::VRInputComponentHandle_t triggerComponent;
        vr::VRDriverInput()->CreateComponent(
            deviceIndex_,
            "/input/trigger/value",
            vr::VRScalarType_Absolute,
            vr::VRScalarUnits_NormalizedTwoSided,
            &triggerComponent);

        // Componente de grip
        vr::VRInputComponentHandle_t gripComponent;
        vr::VRDriverInput()->CreateComponent(
            deviceIndex_,
            "/input/grip/value",
            vr::VRScalarType_Absolute,
            vr::VRScalarUnits_NormalizedTwoSided,
            &gripComponent);

        // Componente de trackpad/touchpad
        vr::VRInputComponentHandle_t trackpadComponent;
        vr::VRDriverInput()->CreateComponent(
            deviceIndex_,
            "/input/trackpad/x",
            vr::VRScalarType_Absolute,
            vr::VRScalarUnits_NormalizedTwoSided,
            &trackpadComponent);

        vr::VRInputComponentHandle_t trackpadYComponent;
        vr::VRDriverInput()->CreateComponent(
            deviceIndex_,
            "/input/trackpad/y",
            vr::VRScalarType_Absolute,
            vr::VRScalarUnits_NormalizedTwoSided,
            &trackpadYComponent);

        vr::VRInputComponentHandle_t trackpadTouchComponent;
        vr::VRDriverInput()->CreateComponent(
            deviceIndex_,
            "/input/trackpad/touch",
            vr::VRBooleanType_Standard,
            &trackpadTouchComponent);

        // Botones del gamepad
        const char* buttonPaths[] = {
            "/input/button/a",
            "/input/button/b",
            "/input/button/x",
            "/input/button/y",
            "/input/button/menu",
            "/input/button/system",
            "/input/button/trackpad",
        };

        for (const auto& path : buttonPaths) {
            vr::VRInputComponentHandle_t buttonComponent;
            vr::VRDriverInput()->CreateComponent(
                deviceIndex_,
                path,
                vr::VRBooleanType_Standard,
                &buttonComponent);
            buttonComponents_.push_back(buttonComponent);
        }

        DriverLog(("VRStream Controller activated: " + deviceId_).c_str());
        return vr::VRInitError_None;
    }

    virtual void Deactivate() override {
        deviceIndex_ = vr::k_unTrackedDeviceIndexInvalid;
        DriverLog(("VRStream Controller deactivated: " + deviceId_).c_str());
    }

    virtual void EnterStandby() override {}

    virtual void* GetComponent(const char* componentAndVersion) override {
        return nullptr;
    }

    virtual void DebugRequest(const char* request, char* responseBuffer,
                              uint32_t responseBufferSize) override {
        if (responseBufferSize > 0) {
            responseBuffer[0] = '\0';
        }
    }

    virtual vr::TrackedDevicePose_t GetPose() override {
        return pose_;
    }

    // ==================== ACTUALIZACIÓN ====================

    /**
     * Actualiza el controlador con datos de hand tracking.
     *
     * Mapeo de MediaPipe a SteamVR:
     * - Centro de la mano -> Posición del controlador
     * - Dirección del rayo (muñeca -> dedo índice) -> Rotación del controlador
     * - Distancia pulgar-índice -> Trigger presionado
     * - Fuerza del pellizco -> Valor del trigger (0-1)
     */
    void updateFromHandData(const SharedHandData& handData, bool useHandTracking) {
        if (!useHandData) return;

        isActive_ = true;

        // Posición del controlador (centro de la mano)
        // Escalar de [0,1] a [-1,1] y luego a unidades de SteamVR
        pose_.mDeviceToAbsoluteTracking.m[0][3] =
            (handData.handCenter[0] - 0.5f) * 2.0f;  // X
        pose_.mDeviceToAbsoluteTracking.m[1][3] =
            (handData.handCenter[1] - 0.5f) * 2.0f;  // Y
        pose_.mDeviceToAbsoluteTracking.m[2][3] =
            handData.handCenter[2] * -1.0f;           // Z (invertido para profundidad)

        // Rotación del controlador basada en la dirección del rayo
        // Crear matriz de rotación que apunte en la dirección del rayo
        float rx = handData.rayDirection[0];
        float ry = handData.rayDirection[1];
        float rz = handData.rayDirection[2];

        // Construir matriz de rotación desde la dirección del rayo
        // Usando un vector "arriba" de referencia
        float up[3] = { 0.0f, 1.0f, 0.0f };
        float right[3];

        // Cross product (right = forward x up)
        right[0] = ry * up[2] - rz * up[1];
        right[1] = rz * up[0] - rx * up[2];
        right[2] = rx * up[1] - ry * up[0];

        // Normalizar right
        float rightLen = sqrt(right[0]*right[0] + right[1]*right[1] + right[2]*right[2]);
        if (rightLen > 0.0001f) {
            right[0] /= rightLen;
            right[1] /= rightLen;
            right[2] /= rightLen;
        }

        // Recalcular up (up = right x forward)
        up[0] = right[1] * rz - right[2] * ry;
        up[1] = right[2] * rx - right[0] * rz;
        up[2] = right[0] * ry - right[1] * rx;

        // Llenar la matriz de rotación
        pose_.mDeviceToAbsoluteTracking.m[0][0] = right[0];
        pose_.mDeviceToAbsoluteTracking.m[0][1] = right[1];
        pose_.mDeviceToAbsoluteTracking.m[0][2] = right[2];

        pose_.mDeviceToAbsoluteTracking.m[1][0] = up[0];
        pose_.mDeviceToAbsoluteTracking.m[1][1] = up[1];
        pose_.mDeviceToAbsoluteTracking.m[1][2] = up[2];

        pose_.mDeviceToAbsoluteTracking.m[2][0] = rx;
        pose_.mDeviceToAbsoluteTracking.m[2][1] = ry;
        pose_.mDeviceToAbsoluteTracking.m[2][2] = rz;

        // Actualizar estado del trigger (pellizco)
        if (!buttonComponents_.empty()) {
            vr::VRDriverInput()->UpdateScalarComponent(
                buttonComponents_[0],  // trigger
                handData.pinchStrength);
        }

        // Marcar pose como válida
        pose_.bPoseIsValid = true;
        pose_.bDeviceIsConnected = true;
        pose_.result = vr::TrackingResult_Running_OK;
        pose_.ulTimeStamp = handData.timestamp_ns;
    }

    /**
     * Actualiza el controlador con datos de gamepad PS4.
     *
     * Mapeo de botones PS4 a SteamVR:
     * - Cross (X) -> Button A
     * - Circle -> Button B
     * - Square -> Button X
     * - Triangle -> Button Y
     * - L1/R1 -> Grip izquierdo/derecho
     * - L2/R2 -> Trigger izquierdo/derecho
     * - Left Stick -> Trackpad/Joystick
     */
    void updateFromGamepad(const SharedGamepadData& gamepad) {
        isActive_ = true;

        // Actualizar sticks
        if (!buttonComponents_.empty()) {
            vr::VRDriverInput()->UpdateScalarComponent(
                buttonComponents_[7],  // trackpad x
                gamepad.xAxis);

            vr::VRDriverInput()->UpdateScalarComponent(
                buttonComponents_[8],  // trackpad y
                gamepad.yAxis);
        }

        // Actualizar trigger
        if (!buttonComponents_.empty()) {
            vr::VRDriverInput()->UpdateScalarComponent(
                buttonComponents_[0],  // trigger
                gamepad.trigger);
        }

        // Actualizar botones
        // Mascaras de bits para botones PS4
        static const int PS4_CROSS   = 0x0001;
        static const int PS4_CIRCLE  = 0x0002;
        static const int PS4_SQUARE  = 0x0004;
        static const int PS4_TRIANGLE = 0x0008;
        static const int PS4_L1      = 0x0010;
        static const int PS4_R1      = 0x0020;
        static const int PS4_L2      = 0x0040;
        static const int PS4_R2      = 0x0080;
        static const int PS4_OPTIONS = 0x0100;
        static const int PS4_SHARE   = 0x0200;
        static const int PS4_L3      = 0x0400;
        static const int PS4_R3      = 0x0800;
        static const int PS4_PS      = 0x1000;
        static const int PS4_TOUCHPAD = 0x2000;

        if (!buttonComponents_.empty()) {
            vr::VRDriverInput()->UpdateBooleanComponent(
                buttonComponents_[0],  // X -> A
                (gamepad.buttons & PS4_CROSS) != 0);
            vr::VRDriverInput()->UpdateBooleanComponent(
                buttonComponents_[1],  // Circle -> B
                (gamepad.buttons & PS4_CIRCLE) != 0);
            vr::VRDriverInput()->UpdateBooleanComponent(
                buttonComponents_[2],  // Square -> X
                (gamepad.buttons & PS4_SQUARE) != 0);
            vr::VRDriverInput()->UpdateBooleanComponent(
                buttonComponents_[3],  // Triangle -> Y
                (gamepad.buttons & PS4_TRIANGLE) != 0);
            vr::VRDriverInput()->UpdateBooleanComponent(
                buttonComponents_[4],  // Options -> Menu
                (gamepad.buttons & PS4_OPTIONS) != 0);
            vr::VRDriverInput()->UpdateBooleanComponent(
                buttonComponents_[5],  // PS -> System
                (gamepad.buttons & PS4_PS) != 0);
            vr::VRDriverInput()->UpdateBooleanComponent(
                buttonComponents_[6],  // Touchpad -> Trackpad
                (gamepad.buttons & PS4_TOUCHPAD) != 0);
        }

        pose_.bPoseIsValid = true;
        pose_.bDeviceIsConnected = true;
        pose_.result = vr::TrackingResult_Running_OK;
        pose_.ulTimeStamp = gamepad.timestamp_ns;
    }

    bool isActive() const { return isActive_; }
    const std::string& getDeviceId() const { return deviceId_; }

private:
    std::string deviceId_;
    std::string displayName_;
    std::string deviceClass_;
    uint32_t deviceIndex_;
    bool isActive_;

    vr::TrackedDevicePose_t pose_;
    std::vector<vr::VRInputComponentHandle_t> buttonComponents_;
};

#endif // VRSTREAM_CONTROLLER_DEVICE_H
