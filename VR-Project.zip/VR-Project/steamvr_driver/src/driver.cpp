#include "driver_main.h"
#include "hmd_device.h"
#include "controller_device.h"
#include "network_receiver.h"

#include <openvr/openvr_driver.h>
#include <windows.h>
#include <thread>
#include <chrono>

#define DRIVER_LOG_FILE "C:\\VRStream\\driver_log.txt"

/**
 * Log simple a archivo para debugging del driver.
 */
static void DriverLog(const char* msg) {
    FILE* f = fopen(DRIVER_LOG_FILE, "a");
    if (f) {
        fprintf(f, "[%s] %s\n", __TIME__, msg);
        fclose(f);
    }
}

/**
 * Driver provider principal.
 * Gestiona el ciclo de vida del HMD y controladores virtuales.
 */
class VRStreamProvider : public vr::IServerTrackedDeviceProvider {
public:
    virtual vr::EVRInitError Init(vr::IVRDriverContext* driverContext) override {
        VR_INIT_SERVER_DRIVER_CONTEXT(driverContext);
        DriverLog("VRStream Provider initializing...");

        // Cargar configuración
        settings_.listenPort = 9999;
        settings_.ipd = 0.063f;
        settings_.refreshRate = 90;

        // Crear receptor de red
        networkReceiver_ = std::make_unique<NetworkReceiver>(settings_.listenPort);
        if (!networkReceiver_->start()) {
            DriverLog("ERROR: Failed to start network receiver");
            return vr::VRInitError_Init_InterfaceNotFound;
        }

        // Crear HMD virtual
        hmdDevice_ = std::make_unique<VRStreamHmd>(settings_);

        // Crear controladores virtuales (manos izquierda y derecha)
        controllerLeft_ = std::make_unique<VRStreamController>(
            "VRStreamControllerLeft",
            "VR Stream Left",
            "TrackedDeviceClass_Controller"
        );
        controllerRight_ = std::make_unique<VRStreamController>(
            "VRStreamControllerRight",
            "VR Stream Right",
            "TrackedDeviceClass_Controller"
        );

        DriverLog("VRStream Provider initialized successfully");
        return vr::VRInitError_None;
    }

    virtual void Cleanup() override {
        DriverLog("VRStream Provider cleaning up");

        networkReceiver_->stop();
        hmdDevice_.reset();
        controllerLeft_.reset();
        controllerRight_.reset();

        VR_CLEANUP_SERVER_DRIVER_CONTEXT();
    }

    virtual const char* const* GetInterfaceVersions() override {
        return vr::k_InterfaceVersions;
    }

    virtual bool ShouldBlockStandbyMode() override { return false; }
    virtual void EnterStandby() override {}
    virtual void LeaveStandby() override {}

    /**
     * Ejecuta frame tick periódico.
     * Actualiza el HMD y controladores con los datos más recientes de la red.
     */
    virtual void RunFrame() override {
        // Obtener datos de orientación más recientes
        SharedOrientation orientation;
        if (networkReceiver_->getLatestOrientation(orientation)) {
            hmdDevice_->updateOrientation(orientation);
        }

        // Obtener datos de hand tracking
        SharedHandData leftHand, rightHand;
        networkReceiver_->getLatestHandData(leftHand, rightHand);

        if (leftHand.isActive) {
            controllerLeft_->updateFromHandData(leftHand, settings_.useHandTracking);
        }
        if (rightHand.isActive) {
            controllerRight_->updateFromHandData(rightHand, settings_.useHandTracking);
        }

        // Obtener datos de gamepad
        SharedGamepadData gamepad;
        if (networkReceiver_->getLatestGamepad(gamepad)) {
            controllerLeft_->updateFromGamepad(gamepad);
        }
    }

private:
    DriverSettings settings_;
    std::unique_ptr<NetworkReceiver> networkReceiver_;
    std::unique_ptr<VRStreamHmd> hmdDevice_;
    std::unique_ptr<VRStreamController> controllerLeft_;
    std::unique_ptr<VRStreamController> controllerRight_;
};

static VRStreamProvider* g_provider = nullptr;

/**
 * Punto de entrada del driver de SteamVR.
 * SteamVR llama a esta función para obtener los providers del driver.
 */
void* HmdDriverFactory(const char* interfaceName, int* returnCode) {
    DriverLog("HmdDriverFactory called");

    if (strcmp(interfaceName, vr::IServerTrackedDeviceProvider_Version) == 0) {
        if (!g_provider) {
            g_provider = new VRStreamProvider();
        }
        return g_provider;
    }

    if (returnCode) {
        *returnCode = vr::VRInitError_Init_InterfaceNotFound;
    }

    DriverLog("Interface not found");
    return nullptr;
}
