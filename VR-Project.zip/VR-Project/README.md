# VR Stream - Visor VR para Android + Driver SteamVR

Sistema completo de realidad virtual que convierte tu teléfono Android en un visor VR para PC usando SteamVR.

## Estructura del Proyecto

```
VR-Project/
├── app/                          # Aplicación Android
│   ├── src/main/
│   │   ├── java/com/vrstream/client/
│   │   │   ├── VrActivity.kt           # Actividad principal
│   │   │   ├── sensor/
│   │   │   │   └── SensorController.kt # Giroscopio con fallback
│   │   │   ├── tracking/
│   │   │   │   └── HandTrackingModule.kt # MediaPipe Hand Tracking
│   │   │   ├── network/
│   │   │   │   └── NetworkClient.kt    # Cliente UDP/TCP
│   │   │   └── ui/
│   │   │       ├── VrRenderer.kt       # Renderer OpenGL ES
│   │   │       └── SettingsActivity.kt # Configuración
│   │   ├── cpp/                         # Código nativo C++
│   │   │   ├── CMakeLists.txt
│   │   │   ├── vr_native.cpp           # JNI bindings
│   │   │   ├── quaternion_utils.h      # Cuaterniones y filtros
│   │   │   └── network_udp.h           # Red UDP nativa
│   │   └── res/                         # Recursos Android
│   └── build.gradle.kts
│
├── steamvr_driver/               # Driver de SteamVR (C++)
│   ├── src/
│   │   ├── driver.cpp            # Entry point del driver
│   │   ├── driver_main.h         # Header principal
│   │   ├── hmd_device.h          # HMD virtual
│   │   ├── controller_device.h   # Controladores virtuales
│   │   └── network_receiver.h    # Receptor UDP
│   ├── CMakeLists.txt
│   └── driver.vrdrivermanifest
│
├── .github/workflows/
│   └── build.yml                 # GitHub Actions para APK
│
├── settings.gradle.kts
├── build.gradle.kts
└── gradle.properties
```

## Compilación

### Android APK (GitHub Actions)

1. Sube el código a un repositorio GitHub
2. Ve a la pestaña "Actions"
3. El workflow se ejecutará automáticamente
4. Descarga el APK de "Artifacts"

### Android APK (Local)

```bash
# Requisitos: Android Studio, JDK 17, NDK 26.x
cd VR-Project
./gradlew assembleDebug
```

### Driver de SteamVR (Windows)

```bash
# Requisitos: CMake, Visual Studio 2019+, OpenVR SDK
cd steamvr_driver
mkdir build && cd build
cmake .. -DOPENVR_INCLUDE_DIR="C:/openvr/headers" -DOPENVR_LIBRARY_DIR="C:/openvr/lib/win64"
cmake --build . --config Release
```

## Instalación del Driver

1. Compilar el driver (ver arriba)
2. Copiar la carpeta `bin/` a `C:\Program Files\Steam\steamapps\common\SteamVR\drivers\vrstream\`
3. Copiar el archivo `driver.vrdrivermanifest` a la misma carpeta
4. Reiniciar SteamVR

## Configuración

### En el teléfono Android:
1. Abrir VR Stream
2. Ir a Configuración
3. Ingresar IP del PC y puerto (default: 9999)
4. Seleccionar modo de control (Hand Tracking o Gamepad)
5. Ajustar IPD para lentes Cardboard
6. Seleccionar tasa de refresco (60/90/120/144 Hz)

### Para conexión USB (ADB Forward):
```bash
adb forward tcp:9999 udp:9999
```

## Compatibilidad

### Teléfonos soportados:
- **Xiaomi 13T** (MediaTek Dimensity 8200-Ultra) - Optimizado
- **Genéricos** con Android 9+ (API 28+)
- Requiere giroscopio y cámara frontal

### Lentes Cardboard:
- Asegúrese de que los lentes tengan abertura frontal para la cámara
- Sin abertura, el Hand Tracking no funcionará

## Características

### Modo Standalone (3DOF):
- Interfaz 3D con menú flotante
- Ventanas virtuales arrastrables
- Hand Tracking con MediaPipe
- Gesto de pellizco para clicks
- Raycasting desde la mano

### Modo VR SBS (Side-by-Side):
- División de pantalla para lentes Cardboard
- Streaming de orientación al PC
- Soporte de gamepad PS4/DualShock 4
- Conexión por Wi-Fi o USB

## Solución de Problemas

### Crashes al iniciar (MediaTek):
El código implementa automáticamente un fallback de `SENSOR_DELAY_FASTEST` a `SENSOR_DELAY_GAME` cuando el dispositivo no soporta la frecuencia alta de forma estable.

### Hand Tracking no funciona:
- Verificar que la cámara frontal esté desbloqueada
- Buena iluminación en la habitación
- Mantener las manos dentro del campo de visión de la cámara

### Latencia alta:
- Usar conexión USB (ADB forward) en lugar de Wi-Fi
- Asegurar que el PC y teléfono estén en la misma red
- Reducir la tasa de refresco si es necesario
