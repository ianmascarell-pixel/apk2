package com.phonevr.vr

import android.opengl.GLES20
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

class GridShader {

    private var program = 0
    private var vertexBuffer: FloatBuffer? = null

    private val vertexShaderCode = """
        attribute vec4 aPosition;
        uniform mat4 uMVPMatrix;
        varying vec3 vPosition;
        void main() {
            gl_Position = uMVPMatrix * aPosition;
            vPosition = aPosition.xyz;
        }
    """.trimIndent()

    private val fragmentShaderCode = """
        precision mediump float;
        varying vec3 vPosition;
        void main() {
            float gridX = abs(fract(vPosition.x * 5.0) - 0.5);
            float gridY = abs(fract(vPosition.y * 5.0) - 0.5);
            float grid = min(gridX, gridY);
            float line = 1.0 - smoothstep(0.0, 0.02, grid);
            vec3 color = mix(vec3(0.1, 0.1, 0.15), vec3(0.2, 0.3, 0.4), line);
            float dist = length(vPosition.xy);
            float fade = 1.0 - smoothstep(0.5, 2.0, dist);
            gl_FragColor = vec4(color * fade, fade * 0.5);
        }
    """.trimIndent()

    private val gridVertices = floatArrayOf(
        -3f, -2f, -3f,
         3f, -2f, -3f,
         3f, -2f,  3f,
        -3f, -2f,  3f
    )

    fun init() {
        val vertexShader = compileShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode)
        val fragmentShader = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode)

        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vertexShader)
        GLES20.glAttachShader(program, fragmentShader)
        GLES20.glLinkProgram(program)

        vertexBuffer = ByteBuffer.allocateDirect(gridVertices.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .put(gridVertices)
        vertexBuffer?.position(0)
    }

    fun draw(mvpMatrix: FloatArray) {
        GLES20.glUseProgram(program)

        val positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
        GLES20.glEnableVertexAttribArray(positionHandle)
        GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 0, vertexBuffer)

        val mvpMatrixHandle = GLES20.glGetUniformLocation(program, "uMVPMatrix")
        GLES20.glUniformMatrix4fv(mvpMatrixHandle, 1, false, mvpMatrix, 0)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, 4)

        GLES20.glDisableVertexAttribArray(positionHandle)
    }

    private fun compileShader(type: Int, shaderCode: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, shaderCode)
        GLES20.glCompileShader(shader)
        return shader
    }
}
