package com.phonevr.vr

class LensDistortion {

    private var distortionK1 = 0.34f
    private var distortionK2 = 0.55f
    private var interpupillaryDistance = 0.063f
    private var screenToLensDistance = 0.042f
    private var lensSeparationDistance = 0.063f

    fun setDistortion(k1: Float, k2: Float) {
        distortionK1 = k1
        distortionK2 = k2
    }

    fun setIPD(ipd: Float) {
        interpupillaryDistance = ipd
    }

    fun getDistortion(x: Float, y: Float): Float {
        val r2 = x * x + y * y
        return 1f + distortionK1 * r2 + distortionK2 * r2 * r2
    }

    fun getInverseDistortion(x: Float, y: Float, iterations: Int = 10): Float {
        var r = 1f
        val r2 = x * x + y * y
        for (i in 0 until iterations) {
            val r4 = r * r
            val r6 = r4 * r * r
            r = r2 / (1f + distortionK1 * r4 + distortionK2 * r6)
        }
        return r
    }

    fun getProjectionMatrix(isRightEye: Boolean): FloatArray {
        val matrix = FloatArray(16)
        val offset = if (isRightEye) interpupillaryDistance / 2f else -interpupillaryDistance / 2f

        android.opengl.Matrix.setIdentityM(matrix, 0)
        android.opengl.Matrix.translateM(matrix, 0, offset, 0f, 0f)

        return matrix
    }

    fun getLensOffset(isRightEye: Boolean): Float {
        return if (isRightEye) lensSeparationDistance / 2f else -lensSeparationDistance / 2f
    }

    fun getScreenToLensDistance() = screenToLensDistance

    fun saveConfig(): String {
        return """
            distortion_k1=$distortionK1
            distortion_k2=$distortionK2
            ipd=$interpupillaryDistance
            screen_to_lens=$screenToLensDistance
            lens_separation=$lensSeparationDistance
        """.trimIndent()
    }

    fun loadConfig(config: String) {
        config.lines().forEach { line ->
            val parts = line.split("=")
            if (parts.size == 2) {
                when (parts[0].trim()) {
                    "distortion_k1" -> distortionK1 = parts[1].trim().toFloatOrNull() ?: distortionK1
                    "distortion_k2" -> distortionK2 = parts[1].trim().toFloatOrNull() ?: distortionK2
                    "ipd" -> interpupillaryDistance = parts[1].trim().toFloatOrNull() ?: interpupillaryDistance
                    "screen_to_lens" -> screenToLensDistance = parts[1].trim().toFloatOrNull() ?: screenToLensDistance
                    "lens_separation" -> lensSeparationDistance = parts[1].trim().toFloatOrNull() ?: lensSeparationDistance
                }
            }
        }
    }
}
