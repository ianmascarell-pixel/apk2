package com.phonevr.network

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Log
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.MulticastSocket
import kotlin.concurrent.thread

class LANDiscovery(private val context: Context) {

    companion object {
        private const val TAG = "LANDiscovery"
        private const val DISCOVERY_PORT = 9552
        private const val BROADCAST_PORT = 9553
        private const val MAGIC = "PHONEVR_DISCOVER"
        private const val RESPONSE = "PHONEVR_PC_HERE"
    }

    private var isRunning = false
    private var discoveryThread: Thread? = null
    private var listener: ((String) -> Unit)? = null

    fun setOnDeviceFoundListener(listener: (String) -> Unit) {
        this.listener = listener
    }

    fun startDiscovery() {
        if (isRunning) return
        isRunning = true

        discoveryThread = thread {
            try {
                val socket = DatagramSocket(DISCOVERY_PORT)
                socket.broadcast = true
                socket.soTimeout = 2000

                while (isRunning) {
                    try {
                        val receiveData = ByteArray(1024)
                        val receivePacket = DatagramPacket(receiveData, receiveData.size)
                        socket.receive(receivePacket)

                        val message = String(receivePacket.data, 0, receivePacket.length)
                        if (message.startsWith(MAGIC)) {
                            val pcIp = receivePacket.address.hostAddress
                            Log.d(TAG, "PC found at: $pcIp")
                            listener?.invoke(pcIp)
                        }
                    } catch (e: Exception) {
                        if (isRunning) {
                            broadcastDiscovery()
                        }
                    }
                }
                socket.close()
            } catch (e: Exception) {
                Log.e(TAG, "Discovery error", e)
            }
        }
    }

    private fun broadcastDiscovery() {
        try {
            val socket = DatagramSocket()
            socket.broadcast = true

            val data = MAGIC.toByteArray()
            val broadcastAddress = getBroadcastAddress()
            val packet = DatagramPacket(
                data,
                data.size,
                broadcastAddress,
                BROADCAST_PORT
            )
            socket.send(packet)
            socket.close()
        } catch (e: Exception) {
            Log.e(TAG, "Broadcast error", e)
        }
    }

    private fun getBroadcastAddress(): InetAddress {
        val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ip = wifiManager.connectionInfo.ipAddress
        val broadcast = (ip and 0xff) or (0xff shl 8) or (0xff shl 16) or (0xff shl 24)
        val bytes = byteArrayOf(
            (broadcast and 0xff).toByte(),
            (broadcast shr 8 and 0xff).toByte(),
            (broadcast shr 16 and 0xff).toByte(),
            (broadcast shr 24 and 0xff).toByte()
        )
        return InetAddress.getByAddress(bytes)
    }

    fun stop() {
        isRunning = false
        discoveryThread?.join(1000)
    }
}
