package com.phonevr

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.phonevr.network.UDPClient
import com.phonevr.network.LANDiscovery
import com.phonevr.vr.SensorTracker
import com.phonevr.vr.VRRenderer
import com.phonevr.handtracking.HandTracker
import com.phonevr.controller.PS4Controller

class MainActivity : Activity() {

    private lateinit var glSurfaceView: GLSurfaceView
    private lateinit var vrRenderer: VRRenderer
    private lateinit var sensorTracker: SensorTracker
    private lateinit var udpClient: UDPClient
    private lateinit var landiscovery: LANDiscovery
    private lateinit var handTracker: HandTracker
    private lateinit var ps4Controller: PS4Controller
    private lateinit var statusText: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var pcIp: String? = null

    companion object {
        private const val CAMERA_PERMISSION = 100
        private const val BLUETOOTH_PERMISSION = 101
        private const val UDP_PORT = 9551
        private const val UPDATE_RATE_MS = 16L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        )

        setContentView(R.layout.activity_main)
        statusText = findViewById(R.id.status_text)

        requestPermissions()

        glSurfaceView = findViewById(R.id.gl_surface)
        glSurfaceView.setEGLContextClientVersion(2)
        glSurfaceView.preserveEGLContextOnPause = true

        vrRenderer = VRRenderer(this)
        glSurfaceView.setRenderer(vrRenderer)
        glSurfaceView.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY

        sensorTracker = SensorTracker(this)
        udpClient = UDPClient()
        landiscovery = LANDiscovery(this)
        handTracker = HandTracker(this)
        ps4Controller = PS4Controller(this)

        startTracking()

        statusText.postDelayed({
            statusText.visibility = View.GONE
        }, 3000)
    }

    private fun requestPermissions() {
        val permissions = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.CAMERA)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        if (permissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissions.toTypedArray(), CAMERA_PERMISSION)
        }
    }

    private fun startTracking() {
        sensorTracker.start()

        landiscovery.setOnDeviceFoundListener { ip ->
            pcIp = ip
            udpClient.connect(ip, UDP_PORT)
            handler.post {
                statusText.text = "Conectado a: $ip"
                statusText.visibility = View.VISIBLE
                handler.postDelayed({ statusText.visibility = View.GONE }, 2000)
            }
        }
        landiscovery.startDiscovery()

        handTracker.setOnHandDataListener { leftHand, rightHand ->
            vrRenderer.updateHands(leftHand, rightHand)
        }
        handTracker.start()

        ps4Controller.setOnButtonListener { button, pressed ->
            vrRenderer.updateControllerButton(button, pressed)
        }
        ps4Controller.start()

        handler.post(object : Runnable {
            override fun run() {
                sendTrackingData()
                handler.postDelayed(this, UPDATE_RATE_MS)
            }
        })
    }

    private fun sendTrackingData() {
        val sensorData = sensorTracker.getData()
        val handData = vrRenderer.getHandData()
        val controllerData = ps4Controller.getData()

        val packet = buildPacket(sensorData, handData, controllerData)
        udpClient.send(packet)
    }

    private fun buildPacket(
        sensor: SensorTracker.SensorData,
        hands: VRRenderer.HandRenderData,
        controller: PS4Controller.ControllerData
    ): ByteArray {
        val sb = StringBuilder()
        sb.append("PHON")
        sb.append(sensor.quaternion.joinToString(",") { "%.6f".format(it) })
        sb.append("|")
        sb.append(controller.triggerPressed)
        sb.append(":")
        sb.append(controller.gripPressed)
        return sb.toString().toByteArray()
    }

    override fun onResume() {
        super.onResume()
        glSurfaceView.onResume()
        sensorTracker.start()
        handTracker.start()
        ps4Controller.start()
    }

    override fun onPause() {
        super.onPause()
        glSurfaceView.onPause()
        sensorTracker.stop()
        handTracker.stop()
        ps4Controller.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        udpClient.disconnect()
        landiscovery.stop()
        handTracker.close()
        ps4Controller.close()
    }
}
