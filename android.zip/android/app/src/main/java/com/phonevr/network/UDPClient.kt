package com.phonevr.network

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketException
import java.net.UnknownHostException
import kotlin.concurrent.thread

class UDPClient {

    private var socket: DatagramSocket? = null
    private var serverAddress: InetAddress? = null
    private var isRunning = false
    private var sendThread: Thread? = null

    private val sendQueue = mutableListOf<ByteArray>()
    private val lock = Any()

    fun connect(ip: String, port: Int) {
        try {
            serverAddress = InetAddress.getByName(ip)
            socket?.close()
            socket = DatagramSocket()
            socket?.soTimeout = 100
            isRunning = true
            startSendLoop()
        } catch (e: UnknownHostException) {
            e.printStackTrace()
        } catch (e: SocketException) {
            e.printStackTrace()
        }
    }

    fun disconnect() {
        isRunning = false
        sendThread?.join(1000)
        socket?.close()
        socket = null
        serverAddress = null
    }

    fun send(data: ByteArray) {
        synchronized(lock) {
            if (sendQueue.size < 30) {
                sendQueue.add(data)
            }
        }
    }

    private fun startSendLoop() {
        sendThread = thread {
            while (isRunning) {
                val dataToSend: ByteArray?
                synchronized(lock) {
                    dataToSend = if (sendQueue.isNotEmpty()) sendQueue.removeAt(0) else null
                }

                if (dataToSend != null && serverAddress != null) {
                    try {
                        val packet = DatagramPacket(
                            dataToSend,
                            dataToSend.size,
                            serverAddress,
                            9551
                        )
                        socket?.send(packet)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                } else {
                    Thread.sleep(1)
                }
            }
        }
    }

    fun isConnected(): Boolean {
        return socket != null && serverAddress != null && isRunning
    }
}
