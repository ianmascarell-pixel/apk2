package com.phonevr.controller

import android.content.Context
import android.view.KeyEvent
import android.view.MotionEvent

class PS4Controller(private val context: Context) {

    data class ControllerData(
        val triggerPressed: Boolean = false,
        val gripPressed: Boolean = false,
        val buttonX: Boolean = false,
        val buttonO: Boolean = false,
        val buttonTriangle: Boolean = false,
        val buttonSquare: Boolean = false,
        val dpadUp: Boolean = false,
        val dpadDown: Boolean = false,
        val dpadLeft: Boolean = false,
        val dpadRight: Boolean = false,
        val leftStickX: Float = 0f,
        val leftStickY: Float = 0f,
        val rightStickX: Float = 0f,
        val rightStickY: Float = 0f
    )

    private var listener: ((String, Boolean) -> Unit)? = null
    private var isRunning = false
    private var currentData = ControllerData()

    fun setOnButtonListener(listener: (String, Boolean) -> Unit) {
        this.listener = listener
    }

    fun start() {
        isRunning = true
    }

    fun stop() {
        isRunning = false
    }

    fun getData(): ControllerData = currentData

    // Procesa pulsaciones de botones (R2, L2, X, O, Triángulo, Cuadrado, D-Pad)
    fun onKeyEvent(event: KeyEvent): Boolean {
        if (!isRunning) return false

        val pressed = event.action == KeyEvent.ACTION_DOWN
        when (event.keyCode) {
            KeyEvent.KEYCODE_BUTTON_R2 -> {
                currentData = currentData.copy(triggerPressed = pressed)
                listener?.invoke("trigger", pressed)
            }
            KeyEvent.KEYCODE_BUTTON_L2 -> {
                currentData = currentData.copy(gripPressed = pressed)
                listener?.invoke("grip", pressed)
            }
            KeyEvent.KEYCODE_BUTTON_A -> {
                currentData = currentData.copy(buttonX = pressed)
                listener?.invoke("x", pressed)
            }
            KeyEvent.KEYCODE_BUTTON_B -> {
                currentData = currentData.copy(buttonO = pressed)
                listener?.invoke("o", pressed)
            }
            KeyEvent.KEYCODE_BUTTON_Y -> {
                currentData = currentData.copy(buttonTriangle = pressed)
                listener?.invoke("triangle", pressed)
            }
            KeyEvent.KEYCODE_BUTTON_X -> {
                currentData = currentData.copy(buttonSquare = pressed)
                listener?.invoke("square", pressed)
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                currentData = currentData.copy(dpadUp = pressed)
                listener?.invoke("dpad_up", pressed)
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                currentData = currentData.copy(dpadDown = pressed)
                listener?.invoke("dpad_down", pressed)
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                currentData = currentData.copy(dpadLeft = pressed)
                listener?.invoke("dpad_left", pressed)
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                currentData = currentData.copy(dpadRight = pressed)
                listener?.invoke("dpad_right", pressed)
            }
        }
        return true
    }

    // Procesa el movimiento de los Joysticks analógicos
    fun onMotionEvent(event: MotionEvent): Boolean {
        if (!isRunning) return false

        if (event.actionMasked == MotionEvent.ACTION_MOVE) {
            val leftX = event.getAxisValue(MotionEvent.AXIS_X)
            val leftY = event.getAxisValue(MotionEvent.AXIS_Y)
            val rightX = event.getAxisValue(MotionEvent.AXIS_Z)
            val rightY = event.getAxisValue(MotionEvent.AXIS_RZ)

            currentData = currentData.copy(
                leftStickX = leftX,
                leftStickY = leftY,
                rightStickX = rightX,
                rightStickY = rightY
            )
        }
        return true
    }

    fun close() {
        stop()
    }
}