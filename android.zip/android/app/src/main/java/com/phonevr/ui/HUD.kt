package com.phonevr.ui

import android.opengl.GLES20
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

class HUD {

    private var program = 0
    private var vertexBuffer: FloatBuffer? = null

    private val vertexShaderCode = """
        attribute vec4 aPosition;
        uniform mat4 uMVPMatrix;
        uniform vec2 uOffset;
        void main() {
            gl_Position = uMVPMatrix * vec4(aPosition.xy + uOffset, aPosition.zw);
        }
    """.trimIndent()

    private val fragmentShaderCode = """
        precision mediump float;
        uniform vec4 uColor;
        void main() {
            gl_FragColor = uColor;
        }
    """.trimIndent()

    private val quadVertices = floatArrayOf(
        -0.02f,  0.005f, 0f, 1f,
         0.02f,  0.005f, 0f, 1f,
         0.02f, -0.005f, 0f, 1f,
        -0.02f, -0.005f, 0f, 1f
    )

    private var isConnected = false
    private var connectionAlpha = 1f

    fun init() {
        val vertexShader = compileShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode)
        val fragmentShader = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode)

        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vertexShader)
        GLES20.glAttachShader(program, fragmentShader)
        GLES20.glLinkProgram(program)

        vertexBuffer = ByteBuffer.allocateDirect(quadVertices.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .put(quadVertices)
    }

    fun setConnected(connected: Boolean) {
        isConnected = connected
    }

    fun draw(mvpMatrix: FloatArray) {
        GLES20.glUseProgram(program)

        val positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
        GLES20.glEnableVertexAttribArray(positionHandle)
        GLES20.glVertexAttribPointer(positionHandle, 4, GLES20.GL_FLOAT, false, 0, vertexBuffer)

        val mvpMatrixHandle = GLES20.glGetUniformLocation(program, "uMVPMatrix")
        GLES20.glUniformMatrix4fv(mvpMatrixHandle, 1, false, mvpMatrix, 0)

        val offsetHandle = GLES20.glGetUniformLocation(program, "uOffset")
        GLES20.glUniform2f(offsetHandle, -0.9f, 0.9f)

        val colorHandle = GLES20.glGetUniformLocation(program, "uColor")
        if (isConnected) {
            GLES20.glUniform4f(colorHandle, 0f, 1f, 0f, connectionAlpha)
        } else {
            connectionAlpha = (connectionAlpha - 0.02f).coerceAtLeast(0.3f)
            GLES20.glUniform4f(colorHandle, 1f, 0f, 0f, connectionAlpha)
        }

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, 4)

        GLES20.glDisableVertexAttribArray(positionHandle)
    }

    private fun compileShader(type: Int, shaderCode: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, shaderCode)
        GLES20.glCompileShader(shader)
        return shader
    }
}
