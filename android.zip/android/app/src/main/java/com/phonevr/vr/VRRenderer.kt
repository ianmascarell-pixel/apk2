package com.phonevr.vr

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import com.phonevr.handtracking.HandData
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class VRRenderer(private val context: Context) : GLSurfaceView.Renderer {

    data class HandRenderData(
        var leftPosition: FloatArray = FloatArray(3),
        var leftRotation: FloatArray = floatArrayOf(0f, 0f, 0f, 1f),
        var leftPinch: Boolean = false,
        var rightPosition: FloatArray = FloatArray(3),
        var rightRotation: FloatArray = floatArrayOf(0f, 0f, 0f, 1f),
        var rightPinch: Boolean = false,
        var leftLandmarks: Array<FloatArray> = Array(21) { FloatArray(3) },
        var rightLandmarks: Array<FloatArray> = Array(21) { FloatArray(3) }
    )

    private val projectionMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)

    private var leftEyeFramebuffer = 0
    private var rightEyeFramebuffer = 0
    private var leftEyeTexture = 0
    private var rightEyeTexture = 0
    private var depthBuffer = 0

    private var handRenderData = HandRenderData()
    private var screenWidth = 0
    private var screenHeight = 0

    private val lensDistortion = LensDistortion()

    private val handShader = HandShader()
    private val gridShader = GridShader()

    var headRotation = floatArrayOf(0f, 0f, 0f, 1f)
    var headPosition = floatArrayOf(0f, 0f, 0f)

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.05f, 0.05f, 0.1f, 1.0f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_CULL_FACE)

        handShader.init()
        gridShader.init()

        Matrix.setIdentityM(modelMatrix, 0)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        screenWidth = width
        screenHeight = height

        val eyeWidth = width / 2
        val eyeHeight = height

        createFramebuffers(eyeWidth, eyeHeight)

        val aspect = eyeWidth.toFloat() / eyeHeight.toFloat()
        Matrix.perspectiveM(projectionMatrix, 0, 90f, aspect, 0.1f, 100f)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        GLES20.glViewport(0, 0, screenWidth / 2, screenHeight)
        drawEye(false)

        GLES20.glViewport(screenWidth / 2, 0, screenWidth / 2, screenHeight)
        drawEye(true)
    }

    private fun drawEye(isRightEye: Boolean) {
        val eyeOffset = if (isRightEye) 0.032f else -0.032f

        Matrix.setLookAtM(viewMatrix, 0,
            eyeOffset, 0f, 0f,
            eyeOffset, 0f, -1f,
            0f, 1f, 0f
        )

        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, viewMatrix, 0)
        Matrix.multiplyMM(mvpMatrix, 0, mvpMatrix, 0, modelMatrix, 0)

        gridShader.draw(mvpMatrix)

        drawHand(handRenderData.leftPosition, handRenderData.leftRotation,
            handRenderData.leftLandmarks, handRenderData.leftPinch, mvpMatrix)

        drawHand(handRenderData.rightPosition, handRenderData.rightRotation,
            handRenderData.rightLandmarks, handRenderData.rightPinch, mvpMatrix)
    }

    private fun drawHand(
        position: FloatArray,
        rotation: FloatArray,
        landmarks: Array<FloatArray>,
        isPinching: Boolean,
        mvp: FloatArray
    ) {
        if (landmarks.all { it.all { v -> v == 0f } }) return

        val tempMatrix = FloatArray(16)
        Matrix.setIdentityM(tempMatrix, 0)
        Matrix.translateM(tempMatrix, 0, position[0], position[1], position[2] - 2f)

        val handMvp = FloatArray(16)
        Matrix.multiplyMM(handMvp, 0, mvp, 0, tempMatrix, 0)

        val pinchColor = if (isPinching) floatArrayOf(1f, 1f, 0f, 1f) else floatArrayOf(0.2f, 0.8f, 0.2f, 1f)
        handShader.draw(handMvp, landmarks, pinchColor)
    }

    private fun createFramebuffers(width: Int, height: Int) {
        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        leftEyeTexture = textures[0]

        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, leftEyeTexture)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, width, height, 0,
            GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)

        GLES20.glGenTextures(1, textures, 0)
        rightEyeTexture = textures[0]

        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, rightEyeTexture)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, width, height, 0,
            GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)

        val renderbuffers = IntArray(1)
        GLES20.glGenRenderbuffers(1, renderbuffers, 0)
        depthBuffer = renderbuffers[0]

        GLES20.glBindRenderbuffer(GLES20.GL_RENDERBUFFER, depthBuffer)
        GLES20.glRenderbufferStorage(GLES20.GL_RENDERBUFFER, GLES20.GL_DEPTH_COMPONENT16, width, height)

        val framebuffers = IntArray(2)
        GLES20.glGenFramebuffers(2, framebuffers, 0)
        leftEyeFramebuffer = framebuffers[0]
        rightEyeFramebuffer = framebuffers[1]

        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, leftEyeFramebuffer)
        GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0,
            GLES20.GL_TEXTURE_2D, leftEyeTexture, 0)
        GLES20.glFramebufferRenderbuffer(GLES20.GL_FRAMEBUFFER, GLES20.GL_DEPTH_ATTACHMENT,
            GLES20.GL_RENDERBUFFER, depthBuffer)

        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, rightEyeFramebuffer)
        GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0,
            GLES20.GL_TEXTURE_2D, rightEyeTexture, 0)
        GLES20.glFramebufferRenderbuffer(GLES20.GL_FRAMEBUFFER, GLES20.GL_DEPTH_ATTACHMENT,
            GLES20.GL_RENDERBUFFER, depthBuffer)

        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
    }

    fun updateHands(leftHand: HandData?, rightHand: HandData?) {
        leftHand?.let {
            handRenderData.leftPosition = it.position.clone()
            handRenderData.leftRotation = it.rotation.clone()
            handRenderData.leftPinch = it.pinch
            handRenderData.leftLandmarks = it.landmarks.clone()
        }
        rightHand?.let {
            handRenderData.rightPosition = it.position.clone()
            handRenderData.rightRotation = it.rotation.clone()
            handRenderData.rightPinch = it.pinch
            handRenderData.rightLandmarks = it.landmarks.clone()
        }
    }

    fun updateControllerButton(button: String, pressed: Boolean) {
    }

    fun getHandData() = handRenderData

    fun updateHeadTracking(rotation: FloatArray, position: FloatArray) {
        headRotation = rotation.clone()
        headPosition = position.clone()
    }
}