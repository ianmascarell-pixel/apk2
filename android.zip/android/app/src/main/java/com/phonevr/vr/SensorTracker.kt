package com.phonevr.vr

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.sqrt

class SensorTracker(private val context: Context) : SensorEventListener {

    data class SensorData(
        val quaternion: FloatArray = floatArrayOf(0f, 0f, 0f, 1f),
        val acceleration: FloatArray = FloatArray(3),
        val angularVelocity: FloatArray = FloatArray(3)
    )

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    private val rotationVector = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

    private val rotationMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)
    private val quaternion = floatArrayOf(0f, 0f, 0f, 1f)

    private val accelData = FloatArray(3)
    private val gyroData = FloatArray(3)

    private val gravity = FloatArray(3)
    private val linearAcceleration = FloatArray(3)

    private var lastTimestamp = 0L
    private var isRunning = false

    private val smoothingFactor = 0.85f
    private val smoothedQuaternion = floatArrayOf(0f, 0f, 0f, 1f)

    fun start() {
        if (isRunning) return
        isRunning = true

        rotationVector?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_FASTEST)
        }
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_FASTEST)
        }
        gyroscope?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_FASTEST)
        }
    }

    fun stop() {
        isRunning = false
        sensorManager.unregisterListener(this)
    }

    fun getData(): SensorData {
        return SensorData(
            quaternion = smoothedQuaternion.clone(),
            acceleration = linearAcceleration.clone(),
            angularVelocity = gyroData.clone()
        )
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_ROTATION_VECTOR -> {
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                val remappedMatrix = FloatArray(9)
                SensorManager.remapCoordinateSystem(rotationMatrix,
                    SensorManager.AXIS_X, SensorManager.AXIS_Z, remappedMatrix)
                SensorManager.getQuaternionFromVector(quaternion, remappedMatrix)

                for (i in 0..3) {
                    smoothedQuaternion[i] = smoothedQuaternion[i] * smoothingFactor +
                            quaternion[i] * (1f - smoothingFactor)
                }
                val norm = sqrt(smoothedQuaternion.map { it * it }.sum())
                if (norm > 0) {
                    for (i in 0..3) smoothedQuaternion[i] /= norm
                }
            }

            Sensor.TYPE_ACCELEROMETER -> {
                val alpha = 0.8f
                gravity[0] = alpha * gravity[0] + (1 - alpha) * event.values[0]
                gravity[1] = alpha * gravity[1] + (1 - alpha) * event.values[1]
                gravity[2] = alpha * gravity[2] + (1 - alpha) * event.values[2]

                linearAcceleration[0] = event.values[0] - gravity[0]
                linearAcceleration[1] = event.values[1] - gravity[1]
                linearAcceleration[2] = event.values[2] - gravity[2]

                accelData[0] = event.values[0]
                accelData[1] = event.values[1]
                accelData[2] = event.values[2]
            }

            Sensor.TYPE_GYROSCOPE -> {
                gyroData[0] = event.values[0]
                gyroData[1] = event.values[1]
                gyroData[2] = event.values[2]
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
