package com.phonevr.handtracking

data class HandData(
    val position: FloatArray = FloatArray(3),
    val rotation: FloatArray = floatArrayOf(0f, 0f, 0f, 1f),
    val landmarks: Array<FloatArray> = Array(21) { FloatArray(3) },
    val pinch: Boolean = false,
    val grab: Boolean = false,
    val pinchDistance: Float = 1f,
    val isTracked: Boolean = false
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is HandData) return false
        return position.contentEquals(other.position) &&
                rotation.contentEquals(other.rotation) &&
                pinch == other.pinch &&
                grab == other.grab
    }

    override fun hashCode(): Int {
        var result = position.contentHashCode()
        result = 31 * result + rotation.contentHashCode()
        result = 31 * result + pinch.hashCode()
        result = 31 * result + grab.hashCode()
        return result
    }
}
