package com.phonevr.vr

import android.opengl.GLES20
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

class HandShader {

    private var program = 0
    private var vertexBuffer: FloatBuffer? = null
    private var colorBuffer: FloatBuffer? = null

    private val vertexShaderCode = """
        attribute vec4 aPosition;
        attribute vec4 aColor;
        varying vec4 vColor;
        uniform mat4 uMVPMatrix;
        void main() {
            gl_Position = uMVPMatrix * aPosition;
            vColor = aColor;
            gl_PointSize = 8.0;
        }
    """.trimIndent()

    private val fragmentShaderCode = """
        precision mediump float;
        varying vec4 vColor;
        void main() {
            gl_FragColor = vColor;
        }
    """.trimIndent()

    private val connectionIndices = intArrayOf(
        0, 1, 1, 2, 2, 3, 3, 4,
        0, 5, 5, 6, 6, 7, 7, 8,
        0, 9, 9, 10, 10, 11, 11, 12,
        0, 13, 13, 14, 14, 15, 15, 16,
        0, 17, 17, 18, 18, 19, 19, 20,
        5, 9, 9, 13, 13, 17
    )

    fun init() {
        val vertexShader = compileShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode)
        val fragmentShader = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode)

        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vertexShader)
        GLES20.glAttachShader(program, fragmentShader)
        GLES20.glLinkProgram(program)
    }

    fun draw(mvpMatrix: FloatArray, landmarks: Array<FloatArray>, color: FloatArray) {
        if (landmarks.all { it.all { v -> v == 0f } }) return

        val vertices = FloatArray(21 * 3)
        val colors = FloatArray(21 * 4)

        for (i in 0..20) {
            vertices[i * 3] = landmarks[i][0] * 2f - 1f
            vertices[i * 3 + 1] = -(landmarks[i][1] * 2f - 1f)
            vertices[i * 3 + 2] = -landmarks[i][2]

            colors[i * 4] = color[0]
            colors[i * 4 + 1] = color[1]
            colors[i * 4 + 2] = color[2]
            colors[i * 4 + 3] = color[3]
        }

        vertexBuffer = createFloatBuffer(vertices)
        colorBuffer = createFloatBuffer(colors)

        GLES20.glUseProgram(program)

        val positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
        GLES20.glEnableVertexAttribArray(positionHandle)
        GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 0, vertexBuffer)

        val colorHandle = GLES20.glGetAttribLocation(program, "aColor")
        GLES20.glEnableVertexAttribArray(colorHandle)
        GLES20.glVertexAttribPointer(colorHandle, 4, GLES20.GL_FLOAT, false, 0, colorBuffer)

        val mvpMatrixHandle = GLES20.glGetUniformLocation(program, "uMVPMatrix")
        GLES20.glUniformMatrix4fv(mvpMatrixHandle, 1, false, mvpMatrix, 0)

        GLES20.glDrawArrays(GLES20.GL_POINTS, 0, 21)

        drawConnections(landmarks, color, mvpMatrix)

        GLES20.glDisableVertexAttribArray(positionHandle)
        GLES20.glDisableVertexAttribArray(colorHandle)
    }

    private fun drawConnections(landmarks: Array<FloatArray>, color: FloatArray, mvpMatrix: FloatArray) {
        for (i in connectionIndices.indices step 2) {
            val from = connectionIndices[i]
            val to = connectionIndices[i + 1]

            val lineVertices = floatArrayOf(
                landmarks[from][0] * 2f - 1f, -(landmarks[from][1] * 2f - 1f), -landmarks[from][2],
                landmarks[to][0] * 2f - 1f, -(landmarks[to][1] * 2f - 1f), -landmarks[to][2]
            )

            val lineColors = floatArrayOf(
                color[0], color[1], color[2], color[3],
                color[0], color[1], color[2], color[3]
            )

            val lineVertexBuffer = createFloatBuffer(lineVertices)
            val lineColorBuffer = createFloatBuffer(lineColors)

            val positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
            GLES20.glEnableVertexAttribArray(positionHandle)
            GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 0, lineVertexBuffer)

            val colorHandle = GLES20.glGetAttribLocation(program, "aColor")
            GLES20.glEnableVertexAttribArray(colorHandle)
            GLES20.glVertexAttribPointer(colorHandle, 4, GLES20.GL_FLOAT, false, 0, lineColorBuffer)

            GLES20.glDrawArrays(GLES20.GL_LINES, 0, 2)

            GLES20.glDisableVertexAttribArray(positionHandle)
            GLES20.glDisableVertexAttribArray(colorHandle)
        }
    }

    private fun createFloatBuffer(data: FloatArray): FloatBuffer {
        val buffer = ByteBuffer.allocateDirect(data.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .put(data)
        buffer.position(0)
        return buffer
    }

    private fun compileShader(type: Int, shaderCode: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, shaderCode)
        GLES20.glCompileShader(shader)
        return shader
    }
}
