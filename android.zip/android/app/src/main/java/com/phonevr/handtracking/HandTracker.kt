package com.phonevr.handtracking

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import android.util.Log
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.io.ByteArrayOutputStream
import kotlin.math.sqrt

class HandTracker(private val context: Context) {

    companion object {
        private const val TAG = "HandTracker"
        private const val MODEL_FILE = "hand_landmarker.task"
        private const val PINCH_THRESHOLD = 0.07f
        private const val GRAB_THRESHOLD = 0.12f
    }

    private var handLandmarker: HandLandmarker? = null
    private var isRunning = false
    private var listener: ((HandData?, HandData?) -> Unit)? = null

    private val smoothedLeft = Array(21) { FloatArray(3) }
    private val smoothedRight = Array(21) { FloatArray(3) }
    private val smoothingFactor = 0.6f

    fun setOnHandDataListener(listener: (HandData?, HandData?) -> Unit) {
        this.listener = listener
    }

    fun start() {
        if (isRunning) return
        isRunning = true

        try {
            val baseOptions = BaseOptions.builder()
                .setModelAssetPath(MODEL_FILE)
                .build()

            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(2)
                .setMinHandDetectionConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setResultListener { result: HandLandmarkerResult, mpImage ->
                    processResult(result)
                }
                .build()

            handLandmarker = HandLandmarker.createFromOptions(context, options)
            Log.d(TAG, "HandLandmarker initialized")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize HandLandmarker", e)
        }
    }

    fun processImage(imageProxy: ImageProxy) {
        if (!isRunning || handLandmarker == null) {
            imageProxy.close()
            return
        }

        try {
            val bitmap = imageProxyToBitmap(imageProxy)
            val rotatedBitmap = rotateBitmap(bitmap, imageProxy.imageInfo.rotationDegrees)

            val mpImage = BitmapImageBuilder(rotatedBitmap).build()
            val timestamp = System.currentTimeMillis()

            handLandmarker?.detectAsync(mpImage, timestamp)

            rotatedBitmap.recycle()
            bitmap.recycle()
        } catch (e: Exception) {
            Log.e(TAG, "Error processing image", e)
        } finally {
            imageProxy.close()
        }
    }

    private fun processResult(result: HandLandmarkerResult) {
        var leftHand: HandData? = null
        var rightHand: HandData? = null

        result.landmarks()?.forEachIndexed { index, landmarks ->
            val handData = processLandmarks(landmarks, index == 0)
            if (index == 0) {
                leftHand = handData
            } else {
                rightHand = handData
            }
        }

        listener?.invoke(leftHand, rightHand)
    }

    private fun processLandmarks(landmarks: List<NormalizedLandmark>, isLeft: Boolean): HandData {
        val rawLandmarks = Array(21) { FloatArray(3) }
        landmarks.forEachIndexed { index, landmark ->
            rawLandmarks[index][0] = landmark.x()
            rawLandmarks[index][1] = landmark.y()
            rawLandmarks[index][2] = landmark.z()
        }

        val smoothed = if (isLeft) smoothedLeft else smoothedRight
        for (i in 0..20) {
            for (j in 0..2) {
                smoothed[i][j] = smoothed[i][j] * smoothingFactor +
                        rawLandmarks[i][j] * (1f - smoothingFactor)
            }
        }

        val wrist = smoothed[0]
        val middleMcp = smoothed[9]
        val indexMcp = smoothed[5]

        val direction = floatArrayOf(
            middleMcp[0] - wrist[0],
            middleMcp[1] - wrist[1],
            middleMcp[2] - wrist[2]
        )
        val dirNorm = sqrt(direction.map { it * it }.sum())
        if (dirNorm > 0) {
            for (i in 0..2) direction[i] /= dirNorm
        }

        val side = floatArrayOf(
            indexMcp[0] - wrist[0],
            indexMcp[1] - wrist[1],
            indexMcp[2] - wrist[2]
        )
        val sideNorm = sqrt(side.map { it * it }.sum())
        if (sideNorm > 0) {
            for (i in 0..2) side[i] /= sideNorm
        }

        val up = floatArrayOf(
            direction[1] * side[2] - direction[2] * side[1],
            direction[2] * side[0] - direction[0] * side[2],
            direction[0] * side[1] - direction[1] * side[0]
        )
        val upNorm = sqrt(up.map { it * it }.sum())
        if (upNorm > 0) {
            for (i in 0..2) up[i] /= upNorm
        }

        val rotation = floatArrayOf(direction[0], side[1], up[2], 1f)

        val thumbTip = smoothed[4]
        val indexTip = smoothed[8]
        val pinchDist = sqrt(
            (thumbTip[0] - indexTip[0]).let { it * it } +
            (thumbTip[1] - indexTip[1]).let { it * it } +
            (thumbTip[2] - indexTip[2]).let { it * it }
        )
        val isPinching = pinchDist < PINCH_THRESHOLD

        val middleTip = smoothed[12]
        val ringTip = smoothed[16]
        val pinkyTip = smoothed[20]

        val fingerAvg = floatArrayOf(
            (indexTip[0] + middleTip[0] + ringTip[0] + pinkyTip[0]) / 4f,
            (indexTip[1] + middleTip[1] + ringTip[1] + pinkyTip[1]) / 4f,
            (indexTip[2] + middleTip[2] + ringTip[2] + pinkyTip[2]) / 4f
        )
        val grabDist = sqrt(
            (fingerAvg[0] - wrist[0]).let { it * it } +
            (fingerAvg[1] - wrist[1]).let { it * it } +
            (fingerAvg[2] - wrist[2]).let { it * it }
        )
        val isGrabbing = grabDist < GRAB_THRESHOLD

        return HandData(
            position = wrist.clone(),
            rotation = rotation,
            landmarks = smoothed.map { it.clone() }.toTypedArray(),
            pinch = isPinching,
            grab = isGrabbing,
            pinchDistance = pinchDist,
            isTracked = true
        )
    }

    private fun imageProxyToBitmap(imageProxy: ImageProxy): Bitmap {
        val yBuffer = imageProxy.planes[0].buffer
        val uBuffer = imageProxy.planes[1].buffer
        val vBuffer = imageProxy.planes[2].buffer

        val ySize = yBuffer.remaining()
        val uSize = uBuffer.remaining()
        val vSize = vBuffer.remaining()

        val nv21 = ByteArray(ySize + uSize + vSize)
        yBuffer.get(nv21, 0, ySize)
        vBuffer.get(nv21, ySize, vSize)
        uBuffer.get(nv21, ySize + vSize, uSize)

        val yuvImage = YuvImage(nv21, ImageFormat.NV21, imageProxy.width, imageProxy.height, null)
        val out = ByteArrayOutputStream()
        yuvImage.compressToJpeg(Rect(0, 0, imageProxy.width, imageProxy.height), 90, out)
        val bytes = out.toByteArray()
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    private fun rotateBitmap(bitmap: Bitmap, rotation: Int): Bitmap {
        if (rotation == 0) return bitmap
        val matrix = Matrix()
        matrix.postRotate(rotation.toFloat())
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    fun stop() {
        isRunning = false
    }

    fun close() {
        stop()
        handLandmarker?.close()
        handLandmarker = null
    }
}