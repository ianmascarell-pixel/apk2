# Add project specific ProGuard rules here.
# By default, the flags in this file are appended to flags specified
# in the SDK tools proguard-defaults.txt.

# Keep Gson serialization
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.phonevr.** { *; }
